﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CharacterGenerator.Data;
using CharacterGenerator.UI;
using CharacterGenerator.ViewModels;
using PC = CharacterGenerator.Data.PlayerCharacter;

namespace CharacterGenerator
{
    public partial class MainForm : Form
    {
        // data
        private static string controlValue;
        private static string allegianceValue;
        private SpellViewModel spellVM;

        // initialization
        public MainForm()
        {
            InitializeComponent();
            var tab = new TabPadding(tabControl);
            spellVM = new SpellViewModel();
            setBindings();
        }

        private void setBindings()
        {
            textBoxSpellDescription.DataBindings.Add("Text", spellVM, "Spell.Description");
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            buttonResetTraits_Click(this, new EventArgs());
            PC.ResetAll();

            labelPlayerName.Text = "";
            labelPlayerPact.Text = "";
            labelPlayerFaction.Text = "";
            labelPlayerPaths.Text = "";
            labelMasteryValue.Text
                    = PC.MASTERY_DOTS[PC.MasteryLevels];
            textBoxSetName.Text = string.Empty;

            populateComboBoxPact(comboBoxPact);
            comboBoxPact.SelectedIndex = 0;
            checkBoxIsJoyfulMaiden.Checked = false;

            populateComboBoxFaction(comboBoxFaction);
            comboBoxFaction.SelectedIndex = 0;

            populateListBoxAvailableTraits(listBoxAvailableTraits);
            populateListBoxAvailableSpells(listBoxAvailableSpells);
            populateListBoxCommonSpells(listBoxCommonSpells);
            populateTextBoxSignatureSpell(textBoxSignatureSpell);

            buttonResetMasteries_Click(this, new EventArgs());
            buttonResetPaths_Click(this, new EventArgs());

            buttonSecondPath.Enabled = false;
            listBoxMasteries.Items.Clear();

            radioButtonMight.Checked = true;
        }

        // custom methods
        private void updateListBoxMasteries(ListBox listBox)
        {
            listBox.Items.Clear();

            switch (PC.EarthMastery)
            {
                case 1:
                    listBox.Items.Add("Earth Novice ◆");
                    break;
                case 2:
                    listBox.Items.Remove("Earth Novice ◆");
                    listBox.Items.Add("Earth Adept ◆◆");
                    break;
                case 3:
                    listBox.Items.Remove("Earth Adept ◆◆");
                    listBox.Items.Add("Earth Scholar ◆◆◆");
                    break;
                case 4:
                    listBox.Items.Remove("Earth Scholar ◆◆◆");
                    listBox.Items.Add("Earth Prodigy ◆◆◆◆");
                    break;
            }

            switch (PC.AirMastery)
            {
                case 1:
                    listBox.Items.Add("Air Novice ◆");
                    break;
                case 2:
                    listBox.Items.Remove("Air Novice ◆");
                    listBox.Items.Add("Air Adept ◆◆");
                    break;
                case 3:
                    listBox.Items.Remove("Air Adept ◆◆");
                    listBox.Items.Add("Air Scholar ◆◆◆");
                    break;
                case 4:
                    listBox.Items.Remove("Air Scholar ◆◆◆");
                    listBox.Items.Add("Air Prodigy ◆◆◆◆");
                    break;
            }

            switch (PC.FireMastery)
            {
                case 1:
                    listBox.Items.Add("Fire Novice ◆");
                    break;
                case 2:
                    listBox.Items.Remove("Fire Novice ◆");
                    listBox.Items.Add("Fire Adept ◆◆");
                    break;
                case 3:
                    listBox.Items.Remove("Fire Adept ◆◆");
                    listBox.Items.Add("Fire Scholar ◆◆◆");
                    break;
                case 4:
                    listBox.Items.Remove("Fire Scholar ◆◆◆");
                    listBox.Items.Add("Fire Prodigy ◆◆◆◆");
                    break;
            }

            switch (PC.WaterMastery)
            {
                case 1:
                    listBox.Items.Add("Water Novice ◆");
                    break;
                case 2:
                    listBox.Items.Remove("Water Novice ◆");
                    listBox.Items.Add("Water Adept ◆◆");
                    break;
                case 3:
                    listBox.Items.Remove("Water Adept ◆◆");
                    listBox.Items.Add("Water Scholar ◆◆◆");
                    break;
                case 4:
                    listBox.Items.Remove("Water Scholar ◆◆◆");
                    listBox.Items.Add("Water Prodigy ◆◆◆◆");
                    break;
            }

            switch (PC.CelestialMastery)
            {
                case 1:
                    listBox.Items.Add("Celestial Novice ◆");
                    break;
                case 2:
                    listBox.Items.Remove("Celestial Novice ◆");
                    listBox.Items.Add("Celestial Adept ◆◆");
                    break;
                case 3:
                    listBox.Items.Remove("Celestial Adept ◆◆");
                    listBox.Items.Add("Celestial Scholar ◆◆◆");
                    break;
                case 4:
                    listBox.Items.Remove("Celestial Scholar ◆◆◆");
                    listBox.Items.Add("Celestial Prodigy ◆◆◆◆");
                    break;
            }

            switch (PC.ShadowMastery)
            {
                case 1:
                    listBox.Items.Add("Shadow Novice ◆");
                    break;
                case 2:
                    listBox.Items.Remove("Shadow Novice ◆");
                    listBox.Items.Add("Shadow Adept ◆◆");
                    break;
                case 3:
                    listBox.Items.Remove("Shadow Adept ◆◆");
                    listBox.Items.Add("Shadow Scholar ◆◆◆");
                    break;
                case 4:
                    listBox.Items.Remove("Shadow Scholar ◆◆◆");
                    listBox.Items.Add("Shadow Prodigy ◆◆◆◆");
                    break;
            }
        }

        private void populateComboBoxPact(ComboBox comboBox)
        {
            comboBox.Items.Clear();
            comboBox.Items.Add(Pact.Type.Domination);
            comboBox.Items.Add(Pact.Type.Inspiration);
            comboBox.Items.Add(Pact.Type.Corruption);
            comboBox.Items.Add(Pact.Type.Retribution);
            comboBox.Items.Add(Pact.Type.Seduction);
            comboBox.Items.Add(Pact.Type.Possession);
        }

        private void populateComboBoxFaction(ComboBox comboBox)
        {
            comboBox.Items.Clear();
            comboBox.Items.Add(PC.Faction.Ministry);
            comboBox.Items.Add(PC.Faction.Church);
            comboBox.Items.Add(PC.Faction.Guild);
            comboBox.Items.Add(PC.Faction.Harem);
            comboBox.Items.Add(PC.Faction.Cult);
        }

        private void populateListBoxAvailableTraits(ListBox listBox)
        {
            listBox.Items.Clear();
            foreach (Trait trait in PC.TraitList)
            {
                listBox.Items.Add(trait);
            }
        }

        private void populateTextBoxSignatureSpell(TextBox textbox)
        {
            textbox.Clear();
            textbox.Text = PC.SignatureSpell.Title;
        }

        private void populateListBoxPlayerTraits(ListBox listBox)
        {
            listBox.Items.Clear();
            foreach (Trait trait in PC.PlayerTraits)
            {
                listBox.Items.Add(trait);
            }
        }

        private void populateListBoxAvailableSpells(ListBox listBox)
        {
            listBox.Items.Clear();
            foreach (Spell spell in PC.SpellList)
            {
                listBox.Items.Add(spell);
            }
        }

        private void populateListBoxKnownSpells(ListBox listBox)
        {
            listBox.Items.Clear();
            foreach (Spell spell in PC.PlayerSpells)
            {
                if (spell.Mastery > 0)
                {
                    listBox.Items.Add(spell);
                }
            }
            listBox.DisplayMember = "Title";
        }

        private void populateListBoxCommonSpells(ListBox listBox)
        {
            listBox.Items.Clear();
            foreach (Spell spell in PC.PlayerSpells)
            {
                if (spell.Mastery == 0)
                {
                    listBox.Items.Add(spell);
                }
            }
            listBox.DisplayMember = "Title";
        }

        private void updateDisplay()
        {
            displayErrors();

            //penalty is the amount that exceeds the max negative trait bonus.
            int penalty = (PC.BonusTotal > PC.MAX_NEGATIVE_TRAIT_BONUS)
                        ? (PC.BonusTotal - PC.MAX_NEGATIVE_TRAIT_BONUS) : 0;

            //checks for Pact of Corruption, Arcane Talent/Prodigy
            string potential;

            if (PC.PlayerTraits.IsTalent && !PC.PlayerTraits.IsProdigy && PC.PlayerPact.PactType == Pact.Type.Corruption)
            {
                potential = "Potential: " + (PC.Potential - penalty + PC.CORRUPTION_POTENTIAL_BONUS_TALENT);
            }
            else if (!PC.PlayerTraits.IsTalent && PC.PlayerTraits.IsProdigy && PC.PlayerPact.PactType == Pact.Type.Corruption)
            {
                potential = "Potential: " + (PC.Potential - penalty + PC.CORRUPTION_POTENTIAL_BONUS_PRODIGY);
            }
            
            //check for Path of Possession, Ties That Bind
            else if (PC.PlayerTraits.IsTiesThatBind && PC.PlayerPact.PactType == Pact.Type.Possession)
            {
                potential = "Potential: " + (PC.Potential - penalty + PC.POSSESSION_POTENTIAL_BONUS_TIES);
            }
            else
            {
                potential = "Potential: " + (PC.Potential - penalty);
            }

            labelPlayerName.Text = PC.PlayerName;
            labelPlayerPact.Text = PC.PlayerPact.PactName;
            toolStripStatusLabelAllegiance.Text = "Allegiance: " + allegianceValue;
            toolStripStatusLabelControl.Text = "Control: " + controlValue;
            toolStripStatusLabelPotential.Text = potential;

            if (PC.PlayerFaction != null)
            {
                switch (PC.PlayerFaction)
                {
                    case PC.Faction.Ministry:
                        labelPlayerFaction.Text = PC.IsJoyfulMaiden ?
                               "Joyful Maiden (Ministry)" : "Ministry of Harmony";
                        break;

                    case PC.Faction.Church:
                        labelPlayerFaction.Text = PC.IsJoyfulMaiden ?
                                "Joyful Maiden (Chruch)" : "Church of the Sun";
                        break;

                    case PC.Faction.Guild:
                        labelPlayerFaction.Text = PC.IsJoyfulMaiden ?
                                "Joyful Maiden (Guild)" : "Alchemist Guild";
                        break;

                    case PC.Faction.Harem:
                        labelPlayerFaction.Text = PC.IsJoyfulMaiden ?
                                "Joyful Maiden (Harem)" : "Imperial Harem";
                        break;

                    case PC.Faction.Cult:
                        labelPlayerFaction.Text = PC.IsJoyfulMaiden ?
                                "Joyful Maiden (Cult)" : "Cult of Pleasure";
                        break;

                    default:
                        break;
                }
            }

            labelMasteryValue.Text
                    = PC.MASTERY_DOTS[PC.MasteryLevels];

            string playerTitle;
            string playerRank;

            if (PC.IsJoyfulMaiden)
            {
                playerTitle = "Fettered";
            }
            else
            {
                switch (PC.PlayerFaction)
                {
                    case PC.Faction.Ministry:
                        playerTitle = "Learned";
                        break;
                    case PC.Faction.Church:
                        playerTitle = "Blessed";
                        break;
                    case PC.Faction.Guild:
                        playerTitle = "Inspired";
                        break;
                    case PC.Faction.Harem:
                        playerTitle = "Gifted";
                        break;
                    case PC.Faction.Cult:
                        playerTitle = "Depraved";
                        break;
                    default:
                        playerTitle = "";
                        break;
                }
            }
            
            if (PC.PlayerTraits.IsNovice && !PC.PlayerTraits.IsTalent && !PC.PlayerTraits.IsProdigy)
            {
                playerRank = "Novice,";
            }
            else if (!PC.PlayerTraits.IsNovice && PC.PlayerTraits.IsTalent && !PC.PlayerTraits.IsProdigy)
            {
                playerRank = "Talent,";
            }
            else if (!PC.PlayerTraits.IsNovice && !PC.PlayerTraits.IsTalent && PC.PlayerTraits.IsProdigy)
            {
                playerRank = "Prodigy,";
            }
            else if (!PC.PlayerTraits.IsNovice && !PC.PlayerTraits.IsTalent && !PC.PlayerTraits.IsProdigy)
            {
                playerRank = "Sorceress,";
            }
            else
            {
                playerRank = "???";
            }

            toolStripStatusLabelLeadership.Text = playerTitle + " " + playerRank;

            if (PC.PathOfPleasure != null)
            {
                int i = (int)PC.PathOfPleasure;
                labelPlayerPaths.Text = PC.PATH_CHARS[i].ToString();
            }

            else if (PC.PathOfPleasure == null)
            {
                labelPlayerPaths.Text = string.Empty;
            }

            if (PC.PathOfPleasure2 != null)
            {
                int i = (int)PC.PathOfPleasure2;
                labelPlayerPaths.Text += PC.PATH_CHARS[i].ToString();
            }

            if (PC.IsLustWitch)
            {
                listBoxMasteries.Items.Remove("Lust Witch");
                listBoxMasteries.Items.Add("Lust Witch");
            }
            else if (!PC.IsLustWitch)
            {
                listBoxMasteries.Items.Remove("Lust Witch");
            }

            //repopulate displays
            populateListBoxPlayerTraits(listBoxPlayerTraits);
            populateListBoxKnownSpells(listBoxKnownSpells);
            populateListBoxCommonSpells(listBoxCommonSpells);
            populateTextBoxSignatureSpell(textBoxSignatureSpell);

            //checkbox
            int might = radioButtonMight.Checked 
                    ? PC.MightTotal + PC.AnyTotal : PC.MightTotal;
            int intrigue = radioButtonIntrigue.Checked
                    ? PC.IntrigueTotal + PC.AnyTotal : PC.IntrigueTotal;
            int lust = radioButtonLust.Checked
                    ? PC.LustTotal + PC.AnyTotal : PC.LustTotal;

            toolStripStatusLabelAptitudes.Text
                    = $"Might: {might}  Intrigue: {intrigue}  Lust: {lust}  Any: (+{PC.AnyTotal})";
        }

        private void togglePathButtons(string inputString)
        {
            if (inputString == "off")
            {
                buttonSetPathSun.Enabled = false;
                buttonSetPathMoon.Enabled = false;
                buttonSetPathStars.Enabled = false;
                buttonSetPathVoid.Enabled = false;
                buttonSetPathLost.Enabled = false;
                buttonSetPathBound.Enabled = false;
                buttonSetPathUnveiled.Enabled = false;
                buttonSetPathMany.Enabled = false;

                if (PC.PathOfPleasure2 == null)
                {
                    buttonSecondPath.Enabled = true;
                }
                else
                {
                    buttonSecondPath.Enabled = false;
                }
            }

            else if (inputString == "add")
            {
                buttonSetPathSun.Enabled = true;
                buttonSetPathMoon.Enabled = true;
                buttonSetPathStars.Enabled = true;
                buttonSetPathVoid.Enabled = true;
                buttonSetPathLost.Enabled = true;
                buttonSetPathBound.Enabled = true;
                buttonSetPathUnveiled.Enabled = true;
                buttonSetPathMany.Enabled = true;
                buttonSecondPath.Enabled = false;

                switch (PC.PathOfPleasure)
                {
                    case PC.Path.Sun:
                        buttonSetPathSun.Enabled = false;
                        break;
                    case PC.Path.Moon:
                        buttonSetPathMoon.Enabled = false;
                        break;
                    case PC.Path.Stars:
                        buttonSetPathStars.Enabled = false;
                        break;
                    case PC.Path.Void:
                        buttonSetPathVoid.Enabled = false;
                        break;
                    case PC.Path.Lost:
                        buttonSetPathVoid.Enabled = false;
                        break;
                    case PC.Path.Bound:
                        buttonSetPathVoid.Enabled = false;
                        break;
                    case PC.Path.Unveiled:
                        buttonSetPathVoid.Enabled = false;
                        break;
                    case PC.Path.Many:
                        buttonSetPathVoid.Enabled = false;
                        break;
                    default:
                        break;
                }
            }

            else if (inputString == "reset")
            {
                buttonSetPathSun.Enabled = true;
                buttonSetPathMoon.Enabled = true;
                buttonSetPathStars.Enabled = true;
                buttonSetPathVoid.Enabled = true;
                buttonSetPathLost.Enabled = true;
                buttonSetPathBound.Enabled = true;
                buttonSetPathUnveiled.Enabled = true;
                buttonSetPathMany.Enabled = true;
            }
        }

        private void toggleMasteryButtons(string inputString)
        {
            if (inputString == "check")
            {
                if (PC.MasteryLevels == 0)
                {
                    toggleMasteryButtons("disableElements");
                }
                else
                {
                    toggleMasteryButtons("enableElements");
                }

                if (PC.EarthMastery == PC.SCHOLAR_RANK)
                {
                    buttonAddEarth.Enabled = false;
                }
                if (PC.AirMastery == PC.SCHOLAR_RANK)
                {
                    buttonAddAir.Enabled = false;
                }
                if (PC.FireMastery == PC.SCHOLAR_RANK)
                {
                    buttonAddFire.Enabled = false;
                }
                if (PC.WaterMastery == PC.SCHOLAR_RANK)
                {
                    buttonAddWater.Enabled = false;
                }
                if (PC.CelestialMastery == PC.SCHOLAR_RANK)
                {
                    buttonAddCelestial.Enabled = false;
                }
                if (PC.ShadowMastery == PC.SCHOLAR_RANK)
                {
                    buttonAddShadow.Enabled = false;
                }
            }

            if (inputString == "disableElements")
            {
                buttonAddEarth.Enabled = false;
                buttonAddAir.Enabled = false;
                buttonAddFire.Enabled = false;
                buttonAddWater.Enabled = false;
                buttonAddCelestial.Enabled = false;
                buttonAddShadow.Enabled = false;
            }

            if (inputString == "enableElements")
            {
                buttonAddEarth.Enabled = true;
                buttonAddAir.Enabled = true;
                buttonAddFire.Enabled = true;
                buttonAddWater.Enabled = true;
                buttonAddCelestial.Enabled = true;
                buttonAddShadow.Enabled = true;
            }

            if (inputString == "reset")
            {
                buttonAddTalent.Enabled = true;
                buttonAddProdigy.Enabled = true;
                toggleMasteryButtons("enableElements");
            }
        }

        private void displayErrors()
        {
            List<string> errorList = new List<string>();

            if (PC.PlayerTraits.BonusTotal > PC.MAX_NEGATIVE_TRAIT_BONUS)
            {
                errorList.Add("Negative traits exceed 3 Potential.");
            }
            else
            {
                errorList.Remove("Negative traits exceed 3 Potential.");
            }

            if (PC.PlayerTraits.IsTalent && PC.PlayerTraits.IsProdigy)
            {
                errorList.Add("Cannot be both an Arcane Talent and Prodigy.");
            }
            else
            {
                errorList.Remove("Cannot be both an Arcane Talent and Prodigy.");
            }

            if (PC.PlayerTraits.IsNovice && (PC.PlayerTraits.IsTalent || PC.PlayerTraits.IsProdigy))
            {
                errorList.Add("Cannot be a Novice with Arcane Talent/Prodigy.");
            }
            else
            {
                errorList.Remove("Cannot be a Novice with Arcane Talent/Prodigy.");
            }

            if (errorList.Any())
            {
                string errors = string.Join("\r\n", errorList);
                errorProvider.SetError(labelTraitsPrompt, errors);
            }
            else
            {
                errorProvider.SetError(labelTraitsPrompt, string.Empty);
            }

            if ((PC.TotalMastery > PC.ADEPT_RANK && PC.PlayerTraits.IsNovice)
                    || PC.TotalMastery > PC.SCHOLAR_RANK && !(PC.PlayerTraits.IsTalent || PC.PlayerTraits.IsProdigy)
                    || PC.HighestMastery > PC.SCHOLAR_RANK && !PC.PlayerTraits.IsProdigy)
            {
                errorProvider.SetError(labelMasteriesPrompt, "You have too many Mastery ranks.");
            }
            else if ((PC.TotalMastery > PC.HighestMastery || PC.HighestMastery != PC.PRODIGY_RANK)
                    && PC.PlayerTraits.IsProdigy)
            {
                errorProvider.SetError(labelMasteriesPrompt, "A Prodigy has 4 ranks in a single element.");
            }
            else
            {
                errorProvider.SetError(labelMasteriesPrompt, string.Empty);
            }

            if(PC.PathOfPleasure2 != null && !PC.IsLover)
            {
                errorProvider.SetError(labelPathsPrompt, "You have too many Paths.");                
            }
            else if(PC.PathOfPleasure2 == null && PC.IsLover)
            {
                errorProvider.SetError(labelPathsPrompt, "You can learn more Paths.");
            }
            else
            {
                errorProvider.SetError(labelPathsPrompt, string.Empty);
            }

            //*toolstrip
            if (PC.PlayerPact.PactType == Pact.Type.Seduction && PC.Allegiance != 0)
            {
                controlValue = (PC.Control + PC.Allegiance).ToString();
                allegianceValue = "0";
            }
            else
            {
                controlValue = PC.Control.ToString();
                allegianceValue = PC.Allegiance.ToString();
            }
        }

        //event handlers
        private void buttonResetAll_Click(object sender, EventArgs e)
        {
            MainForm_Load(this, new EventArgs());
        }

        private void buttonSetName_Click(object sender, EventArgs e)
        {
            if(textBoxSetName.Text != string.Empty)
            {
                PC.PlayerName = textBoxSetName.Text;
                textBoxSetName.Text = string.Empty;
                updateDisplay();
            }
        }

        private void textBoxSetName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                buttonSetName_Click(this, new EventArgs());
            }
        }

        private void buttonSetPact_Click(object sender, EventArgs e)
        {
            Pact oldPact = PC.PlayerPact;
            PC.RemovePactBonus(oldPact);
            PC.PlayerPact 
                    = new Pact((Pact.Type)comboBoxPact.SelectedItem);
            PC.ApplyPactBonus(PC.PlayerPact);
            updateDisplay();
        }

        private void buttonSetFaction_Click(object sender, EventArgs e)
        {
            PC.PlayerFaction = comboBoxFaction.SelectedItem as PC.Faction?;
            if (checkBoxIsJoyfulMaiden.Checked)
            {
                PC.IsJoyfulMaiden = true;
            }
            else if (!checkBoxIsJoyfulMaiden.Checked)
            {
                PC.IsJoyfulMaiden = false;
            }
            updateDisplay();
        }

        private void buttonAddEarth_Click(object sender, EventArgs e)
        {
            if (PC.IsProdigy)
            {
                buttonAddTalent.Enabled = false;
                PC.SetMasteriesForProdigy("Earth");
                toggleMasteryButtons("disableElements");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
            else
            {
                buttonAddProdigy.Enabled = false;
                PC.MasteryLevels -= 1;
                PC.EarthMastery += 1;
                toggleMasteryButtons("check");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
        }

        private void buttonAddAir_Click(object sender, EventArgs e)
        {
            if (PC.IsProdigy)
            {
                buttonAddTalent.Enabled = false;
                PC.SetMasteriesForProdigy("Air");
                toggleMasteryButtons("disableElements");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
            else
            {
                buttonAddProdigy.Enabled = false;
                PC.MasteryLevels -= 1;
                PC.AirMastery += 1;
                toggleMasteryButtons("check");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
        }

        private void buttonAddFire_Click(object sender, EventArgs e)
        {
            if (PC.IsProdigy)
            {
                buttonAddTalent.Enabled = false;
                PC.SetMasteriesForProdigy("Fire");
                toggleMasteryButtons("disableElements");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
            else
            {
                buttonAddProdigy.Enabled = false;
                PC.MasteryLevels -= 1;
                PC.FireMastery += 1;
                toggleMasteryButtons("check");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
        }

        private void buttonAddWater_Click(object sender, EventArgs e)
        {
            if (PC.IsProdigy)
            {
                buttonAddTalent.Enabled = false;
                PC.SetMasteriesForProdigy("Water");
                toggleMasteryButtons("disableElements");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
            else
            {
                buttonAddProdigy.Enabled = false;
                PC.MasteryLevels -= 1;
                PC.WaterMastery += 1;
                toggleMasteryButtons("check");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
        }

        private void buttonAddCelestial_Click(object sender, EventArgs e)
        {
            if (PC.IsProdigy)
            {
                buttonAddTalent.Enabled = false;
                PC.SetMasteriesForProdigy("Celestial");
                toggleMasteryButtons("disableElements");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
            else
            {
                buttonAddProdigy.Enabled = false;
                PC.MasteryLevels -= 1;
                PC.CelestialMastery += 1;
                toggleMasteryButtons("check");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
        }

        private void buttonAddShadow_Click(object sender, EventArgs e)
        {
            if (PC.IsProdigy)
            {
                buttonAddTalent.Enabled = false;
                PC.SetMasteriesForProdigy("Shadow");
                toggleMasteryButtons("disableElements");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
            else
            {
                buttonAddProdigy.Enabled = false;
                PC.MasteryLevels -= 1;
                PC.ShadowMastery += 1;
                toggleMasteryButtons("check");
                updateListBoxMasteries(listBoxMasteries);
                updateDisplay();
            }
        }

        private void buttonAddTalent_Click(object sender, EventArgs e)
        {
            buttonAddProdigy.Enabled = false;
            buttonAddTalent.Enabled = false;
            PC.IsTalent = true;
            PC.MasteryLevels += 1;
            toggleMasteryButtons("check");
            updateDisplay();
        }

        private void buttonAddProdigy_Click(object sender, EventArgs e)
        {
            buttonAddProdigy.Enabled = false;
            buttonAddTalent.Enabled = false;
            PC.IsProdigy = true;
            PC.MasteryLevels += 1;
            updateDisplay();
        }

        private void buttonResetMasteries_Click(object sender, EventArgs e)
        {
            PC.MasteryLevels = PC.STARTING_MASTERY_LEVELS;
            PC.EarthMastery = 0;
            PC.AirMastery = 0;
            PC.FireMastery = 0;
            PC.WaterMastery = 0;
            PC.CelestialMastery = 0;
            PC.ShadowMastery = 0;
            PC.IsNovice = false;
            PC.IsTalent = false;
            PC.IsProdigy = false;
            listBoxMasteries.Items.Clear();
            toggleMasteryButtons("reset");
            updateDisplay();
        }

        private void buttonSetPathSun_Click(object sender, EventArgs e)
        {
            if (PC.PathOfPleasure == null)
            {
                PC.PathOfPleasure = PC.Path.Sun;
            }
            else if (PC.PathOfPleasure != null)
            {
                PC.PathOfPleasure2 = PC.Path.Sun;
            }
            togglePathButtons("off");
            updateDisplay();
        }

        private void buttonSetPathMoon_Click(object sender, EventArgs e)
        {
            if (PC.PathOfPleasure == null)
            {
                PC.PathOfPleasure = PC.Path.Moon;
            }
            else if (PC.PathOfPleasure != null)
            {
                PC.PathOfPleasure2 = PC.Path.Moon;
            }
            togglePathButtons("off");
            updateDisplay();
        }

        private void buttonSetPathStars_Click(object sender, EventArgs e)
        {
            if (PC.PathOfPleasure == null)
            {
                PC.PathOfPleasure = PC.Path.Stars;
            }
            else if (PC.PathOfPleasure != null)
            {
                PC.PathOfPleasure2 = PC.Path.Stars;
            }
            togglePathButtons("off");
            updateDisplay();
        }

        private void buttonSetPathVoid_Click(object sender, EventArgs e)
        {
            if (PC.PathOfPleasure == null)
            {
                PC.PathOfPleasure = PC.Path.Void;
            }
            else if (PC.PathOfPleasure != null)
            {
                PC.PathOfPleasure2 = PC.Path.Void;
            }
            togglePathButtons("off");
            updateDisplay();
        }

        private void buttonSetPathLost_Click(object sender, EventArgs e)
        {
            if (PC.PathOfPleasure == null)
            {
                PC.PathOfPleasure = PC.Path.Lost;
            }
            else if (PC.PathOfPleasure != null)
            {
                PC.PathOfPleasure2 = PC.Path.Lost;
            }
            togglePathButtons("off");
            updateDisplay();
        }

        private void buttonSetPathBound_Click(object sender, EventArgs e)
        {
            if (PC.PathOfPleasure == null)
            {
                PC.PathOfPleasure = PC.Path.Bound;
            }
            else if (PC.PathOfPleasure != null)
            {
                PC.PathOfPleasure2 = PC.Path.Bound;
            }
            togglePathButtons("off");
            updateDisplay();
        }

        private void buttonSetPathUnveiled_Click(object sender, EventArgs e)
        {
            if (PC.PathOfPleasure == null)
            {
                PC.PathOfPleasure = PC.Path.Unveiled;
            }
            else if (PC.PathOfPleasure != null)
            {
                PC.PathOfPleasure2 = PC.Path.Unveiled;
            }
            togglePathButtons("off");
            updateDisplay();
        }

        private void buttonSetPathMany_Click(object sender, EventArgs e)
        {
            if (PC.PathOfPleasure == null)
            {
                PC.PathOfPleasure = PC.Path.Many;
            }
            else if (PC.PathOfPleasure != null)
            {
                PC.PathOfPleasure2 = PC.Path.Many;
            }
            togglePathButtons("off");
            updateDisplay();
        }

        private void buttonAddPath_Click(object sender, EventArgs e)
        {
            togglePathButtons("add");
            updateDisplay();
        }

        private void buttonResetPaths_Click(object sender, EventArgs e)
        {
            PC.PathOfPleasure = null;
            PC.PathOfPleasure2 = null;
            togglePathButtons("reset");
            updateDisplay();
        }

        private void buttonAddTrait_Click(object sender, EventArgs e)
        {
            Trait trait = listBoxAvailableTraits.SelectedItem as Trait;
            if (trait == null)
            {
                return;
            }
            if (!PC.PlayerTraits.Contains(trait))
            {
                PC.ApplyTraitBonus(trait);
                PC.PlayerTraits.Add(trait);
                PC.Potential -= trait.Cost;
            }
            updateDisplay();
        }

        private void buttonRemoveTrait_Click(object sender, EventArgs e)
        {
            Trait trait = listBoxAvailableTraits.SelectedItem as Trait;
            if (PC.PlayerTraits.Contains(trait))
            {
                PC.RemoveTraitBonus(trait);
                PC.PlayerTraits.Remove(trait);
                PC.Potential += trait.Cost;
            }
            updateDisplay();
        }

        private void buttonResetTraits_Click(object sender, EventArgs e)
        {
            foreach (Trait trait in PC.PlayerTraits)
            {
                PC.RemoveTraitBonus(trait);
                PC.Potential += trait.Cost;
            }
            PC.PlayerTraits.Clear();
            updateDisplay();
        }

        private void radioButtonMight_CheckedChanged(object sender, EventArgs e)
        {
            updateDisplay();
        }

        private void radioButtonIntrigue_CheckedChanged(object sender, EventArgs e)
        {
            updateDisplay();
        }

        private void radioButtonLust_CheckedChanged(object sender, EventArgs e)
        {
            updateDisplay();
        }

        //Spell tab
        private void listBoxAvailableSpells_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = Math.Max(0, listBoxAvailableSpells.SelectedIndex);
            Spell spell = spellVM.Spells[selectedIndex];
            spellVM.SetDisplaySpell(spell);
        }

        private void buttonAddSpell_Click(object sender, EventArgs e)
        {
            Spell spell = listBoxAvailableSpells.SelectedItem as Spell;
            if (spell == null)
            {
                return;
            }
            //do not add list breaks with mastery 5
            if (!PC.PlayerSpells.Contains(spell) && spell.Mastery != PC.INVALID_SPELL_MASTERY && !spell.IsKnownToAll)
            {
                PC.PlayerSpells.Add(spell);
            }
            updateDisplay();
        }

        private void buttonRemoveSpell_Click(object sender, EventArgs e)
        {
            Spell spell = listBoxAvailableSpells.SelectedItem as Spell;
            if (PC.PlayerSpells.Contains(spell) && !spell.IsKnownToAll)
            {
                PC.PlayerSpells.Remove(spell);
            }
            updateDisplay();
        }

        private void buttonResetSpells_Click(object sender, EventArgs e)
        {
            PC.SignatureSpell = new Spell();
            PC.PlayerSpells.Clear();
            foreach (Spell spell in PC.SpellList)
            {
                if (spell.IsKnownToAll)
                {
                    PC.PlayerSpells.Add(spell);
                }
            }
            updateDisplay();
        }

        private void buttonSignatureSpell_Click(object sender, EventArgs e)
        {
            Spell spell = listBoxAvailableSpells.SelectedItem as Spell;

            if (spell == null)
            {
                return;
            }

            if (spell.Mastery != PC.INVALID_SPELL_MASTERY && PC.SignatureSpell != spell)
            {
                PC.SignatureSpell = spell;
            }
            else if (PC.SignatureSpell == spell)
            {
                PC.SignatureSpell = new Spell();
            }
            updateDisplay();
        }

        private void buttonInfo_Click(object sender, EventArgs e)
        {
            string info = "The spell selector is a bookkeeping tool and does not check for your Masteries or ability to learn Lust Magic.\r\n\r\nTo clear your Signature Spell, select the same spell and click the 'Set Signature Spell' button again. Spell description Masteries do not take your Signature Spell into account.";
            MessageBox.Show(info);
        }
    }
}