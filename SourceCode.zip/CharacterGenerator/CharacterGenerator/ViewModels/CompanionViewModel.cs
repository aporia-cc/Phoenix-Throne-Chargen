﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CharacterGenerator.Data;
using PC = CharacterGenerator.Data.PlayerCharacter;

namespace CharacterGenerator.ViewModels
{
    class CompanionViewModel : INotifyPropertyChanged
    {
        //data
        private Companion companion;
        public CompanionCollection Companions { get; set; }

        public Companion Companion
        {
            get { return companion; }
            set
            {
                companion = value;
                OnPropertyChanged("Companion");
            }
        }

        //constructors
        public CompanionViewModel()
        {
            Companions = PC.CompanionList;
            Companion = new Companion();
        }

        //methods
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void SetDisplayCompanion(Companion companion)
        {
            Companion = new Companion
            {
                Name = companion.Name,
                DevotionLevel = companion.DevotionLevel,
                ArcanePower = companion.ArcanePower,
                CompanionFaction = companion.CompanionFaction,
                CompanionSubfaction = companion.CompanionSubfaction,
                GuildAllegiance = companion.GuildAllegiance,
                MightAptitude = companion.MightAptitude,
                IntrigueAptitude = companion.IntrigueAptitude,
                LustAptitude = companion.LustAptitude,

                ModifiedControlCost = companion.ModifiedControlCost,
                IsCostModifiedByPlayer = companion.IsCostModifiedByPlayer,
                IsLustWitch = companion.IsLustWitch,
                IsUnaligned = companion.IsUnaligned,
                IsJoyfulMaiden = companion.IsJoyfulMaiden,
                IsPlayerCreated = companion.IsPlayerCreated,
                IsLoverWithAllegiance = companion.IsLoverWithAllegiance,
                IsDiscountedSlaveManual = companion.IsDiscountedSlaveManual,
                IsDivider = companion.IsDivider,

                Notes = companion.Notes,
            };
        }

        ////not sure what's wrong but doesn't work when used to set companion to delete
        //public Companion GetDisplayCompanion()
        //{
        //    OnPropertyChanged("Companion");
        //    return Companion;
        //}
    }
}
