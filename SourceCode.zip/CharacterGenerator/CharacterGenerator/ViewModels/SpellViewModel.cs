﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CharacterGenerator.Data;
using PC = CharacterGenerator.Data.PlayerCharacter;

namespace CharacterGenerator.ViewModels
{
    class SpellViewModel : INotifyPropertyChanged
    {
        //data
        private Spell spell;
        public SpellCollection Spells { get; set; }

        public Spell Spell
        {
            get { return spell; }
            set
            {
                spell = value;
                OnPropertyChanged("Spell");
            }
        }

        //constructors
        public SpellViewModel()
        {
            Spells = PC.SpellList;
            Spell = new Spell();
        }

        //methods
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void SetDisplaySpell(Spell spell)
        {
            Spell = new Spell
            {
                Name = spell.Name,
                Element = spell.Element,
                Mastery = spell.Mastery,
                Description = spell.Description,
                IsLustMagic = spell.IsLustMagic,
                IsKnownToAll = spell.IsKnownToAll,
            };
        }

        public Spell GetDisplaySpell()
        {
            OnPropertyChanged("Spell");
            return Spell;
        }
    }
}
