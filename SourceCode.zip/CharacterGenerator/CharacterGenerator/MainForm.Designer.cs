﻿namespace CharacterGenerator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.labelPlayerName = new System.Windows.Forms.Label();
            this.labelPlayerPact = new System.Windows.Forms.Label();
            this.labelPlayerFaction = new System.Windows.Forms.Label();
            this.labelPlayerPaths = new System.Windows.Forms.Label();
            this.textBoxSetName = new System.Windows.Forms.TextBox();
            this.buttonCharacterInfo = new System.Windows.Forms.Button();
            this.comboBoxPact = new System.Windows.Forms.ComboBox();
            this.buttonSetPathSun = new System.Windows.Forms.Button();
            this.buttonSetPathMoon = new System.Windows.Forms.Button();
            this.buttonSetPathStars = new System.Windows.Forms.Button();
            this.buttonSetPathVoid = new System.Windows.Forms.Button();
            this.listBoxPlayerTraits = new System.Windows.Forms.ListBox();
            this.labelMasteryValue = new System.Windows.Forms.Label();
            this.listBoxMasteries = new System.Windows.Forms.ListBox();
            this.labelTraitsPrompt = new System.Windows.Forms.Label();
            this.labelPathsPrompt = new System.Windows.Forms.Label();
            this.labelMasteriesPrompt = new System.Windows.Forms.Label();
            this.labelFactionPrompt = new System.Windows.Forms.Label();
            this.labelPactPrompt = new System.Windows.Forms.Label();
            this.labelNamePrompt = new System.Windows.Forms.Label();
            this.comboBoxFaction = new System.Windows.Forms.ComboBox();
            this.checkBoxIsJoyfulMaiden = new System.Windows.Forms.CheckBox();
            this.buttonSecondPath = new System.Windows.Forms.Button();
            this.buttonResetPaths = new System.Windows.Forms.Button();
            this.buttonAddEarth = new System.Windows.Forms.Button();
            this.buttonAddAir = new System.Windows.Forms.Button();
            this.buttonAddFire = new System.Windows.Forms.Button();
            this.buttonAddWater = new System.Windows.Forms.Button();
            this.buttonAddCelestial = new System.Windows.Forms.Button();
            this.buttonAddShadow = new System.Windows.Forms.Button();
            this.buttonAddProdigy = new System.Windows.Forms.Button();
            this.buttonAddTalent = new System.Windows.Forms.Button();
            this.buttonResetMasteries = new System.Windows.Forms.Button();
            this.buttonResetAll = new System.Windows.Forms.Button();
            this.listBoxAvailableTraits = new System.Windows.Forms.ListBox();
            this.buttonAddTrait = new System.Windows.Forms.Button();
            this.buttonRemoveTrait = new System.Windows.Forms.Button();
            this.buttonResetTraits = new System.Windows.Forms.Button();
            this.statusStripMain = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelLeadership = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelAllegiance = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelControl = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelPotential = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelAptitudes = new System.Windows.Forms.ToolStripStatusLabel();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.labelElementalSpells = new System.Windows.Forms.Label();
            this.labelCommonSpells = new System.Windows.Forms.Label();
            this.labelSignatureSpell = new System.Windows.Forms.Label();
            this.labelAllies = new System.Windows.Forms.Label();
            this.labelPactBound = new System.Windows.Forms.Label();
            this.labelCompanions = new System.Windows.Forms.Label();
            this.labelEsotericSpell = new System.Windows.Forms.Label();
            this.radioButtonMight = new System.Windows.Forms.RadioButton();
            this.radioButtonIntrigue = new System.Windows.Forms.RadioButton();
            this.radioButtonLust = new System.Windows.Forms.RadioButton();
            this.buttonSetPathOther = new System.Windows.Forms.Button();
            this.buttonSetPathSelf = new System.Windows.Forms.Button();
            this.buttonSetPathChain = new System.Windows.Forms.Button();
            this.buttonSetPathThorn = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.characterTab = new System.Windows.Forms.TabPage();
            this.buttonAddEsoteric = new System.Windows.Forms.Button();
            this.comboBoxEsoteric = new System.Windows.Forms.ComboBox();
            this.labelGuildSchism = new System.Windows.Forms.Label();
            this.labelGuildSupportPrompt = new System.Windows.Forms.Label();
            this.groupBoxGuildSupport = new System.Windows.Forms.GroupBox();
            this.radioButtonSupportNeither = new System.Windows.Forms.RadioButton();
            this.radioButtonSupportEternals = new System.Windows.Forms.RadioButton();
            this.radioButtonSupportVenerables = new System.Windows.Forms.RadioButton();
            this.checkBoxIsUnalignedPlayer = new System.Windows.Forms.CheckBox();
            this.spellTab = new System.Windows.Forms.TabPage();
            this.textBoxEsotericSpell = new System.Windows.Forms.TextBox();
            this.textBoxSignatureSpell = new System.Windows.Forms.TextBox();
            this.listBoxCommonSpells = new System.Windows.Forms.ListBox();
            this.listBoxKnownSpells = new System.Windows.Forms.ListBox();
            this.buttonInfo = new System.Windows.Forms.Button();
            this.buttonSignatureSpell = new System.Windows.Forms.Button();
            this.buttonResetSpells = new System.Windows.Forms.Button();
            this.buttonRemoveSpell = new System.Windows.Forms.Button();
            this.buttonAddSpell = new System.Windows.Forms.Button();
            this.textBoxSpellDescription = new System.Windows.Forms.TextBox();
            this.listBoxAvailableSpells = new System.Windows.Forms.ListBox();
            this.companionTab = new System.Windows.Forms.TabPage();
            this.buttonOverwriteCompanion = new System.Windows.Forms.Button();
            this.maskedTextBoxModifiedControlCost = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxControlCost = new System.Windows.Forms.MaskedTextBox();
            this.checkBoxIsLustWitch = new System.Windows.Forms.CheckBox();
            this.checkBoxIsJoyfulMaidenCompanion = new System.Windows.Forms.CheckBox();
            this.checkBoxIsUnaligned = new System.Windows.Forms.CheckBox();
            this.checkBoxUseModifiedCost = new System.Windows.Forms.CheckBox();
            this.comboBoxArcanePower = new System.Windows.Forms.ComboBox();
            this.checkBoxIsLoverWithAllegiance = new System.Windows.Forms.CheckBox();
            this.checkBoxIsDiscountedSlave = new System.Windows.Forms.CheckBox();
            this.checkBoxIsKeeper = new System.Windows.Forms.CheckBox();
            this.groupBoxLust = new System.Windows.Forms.GroupBox();
            this.radioButtonLustPlus = new System.Windows.Forms.RadioButton();
            this.radioButtonLustAverage = new System.Windows.Forms.RadioButton();
            this.radioButtonLustMinus = new System.Windows.Forms.RadioButton();
            this.groupBoxIntrigue = new System.Windows.Forms.GroupBox();
            this.radioButtonIntriguePlus = new System.Windows.Forms.RadioButton();
            this.radioButtonIntrigueAverage = new System.Windows.Forms.RadioButton();
            this.radioButtonIntrigueMinus = new System.Windows.Forms.RadioButton();
            this.groupBoxMight = new System.Windows.Forms.GroupBox();
            this.radioButtonMightPlus = new System.Windows.Forms.RadioButton();
            this.radioButtonMightAverage = new System.Windows.Forms.RadioButton();
            this.radioButtonMightMinus = new System.Windows.Forms.RadioButton();
            this.groupBoxLoyalty = new System.Windows.Forms.GroupBox();
            this.radioButtonNone = new System.Windows.Forms.RadioButton();
            this.radioButtonAlly = new System.Windows.Forms.RadioButton();
            this.radioButtonSlave = new System.Windows.Forms.RadioButton();
            this.radioButtonLover = new System.Windows.Forms.RadioButton();
            this.labelUseModifiedCost = new System.Windows.Forms.Label();
            this.comboBoxCompanionFaction = new System.Windows.Forms.ComboBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxNotes = new System.Windows.Forms.TextBox();
            this.labelNotesPrompt = new System.Windows.Forms.Label();
            this.labelSpecial = new System.Windows.Forms.Label();
            this.labelAptitude = new System.Windows.Forms.Label();
            this.labelFaction = new System.Windows.Forms.Label();
            this.labelDevotion = new System.Windows.Forms.Label();
            this.labelControlCost = new System.Windows.Forms.Label();
            this.labelMagic = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.listBoxAllies = new System.Windows.Forms.ListBox();
            this.listBoxLovers = new System.Windows.Forms.ListBox();
            this.buttonCreateCompanion = new System.Windows.Forms.Button();
            this.buttonDeleteCompanion = new System.Windows.Forms.Button();
            this.buttonClearData = new System.Windows.Forms.Button();
            this.listBoxCompanions = new System.Windows.Forms.ListBox();
            this.statusStripMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.tabControl.SuspendLayout();
            this.characterTab.SuspendLayout();
            this.groupBoxGuildSupport.SuspendLayout();
            this.spellTab.SuspendLayout();
            this.companionTab.SuspendLayout();
            this.groupBoxLust.SuspendLayout();
            this.groupBoxIntrigue.SuspendLayout();
            this.groupBoxMight.SuspendLayout();
            this.groupBoxLoyalty.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelPlayerName
            // 
            this.labelPlayerName.AutoSize = true;
            this.labelPlayerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPlayerName.Location = new System.Drawing.Point(198, 7);
            this.labelPlayerName.Name = "labelPlayerName";
            this.labelPlayerName.Size = new System.Drawing.Size(195, 31);
            this.labelPlayerName.TabIndex = 1;
            this.labelPlayerName.Text = "<PlayerName>";
            // 
            // labelPlayerPact
            // 
            this.labelPlayerPact.AutoSize = true;
            this.labelPlayerPact.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPlayerPact.Location = new System.Drawing.Point(198, 51);
            this.labelPlayerPact.Name = "labelPlayerPact";
            this.labelPlayerPact.Size = new System.Drawing.Size(178, 31);
            this.labelPlayerPact.TabIndex = 3;
            this.labelPlayerPact.Text = "<PlayerPact>";
            // 
            // labelPlayerFaction
            // 
            this.labelPlayerFaction.AutoSize = true;
            this.labelPlayerFaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPlayerFaction.Location = new System.Drawing.Point(198, 90);
            this.labelPlayerFaction.Name = "labelPlayerFaction";
            this.labelPlayerFaction.Size = new System.Drawing.Size(213, 31);
            this.labelPlayerFaction.TabIndex = 5;
            this.labelPlayerFaction.Text = "<PlayerFaction>";
            // 
            // labelPlayerPaths
            // 
            this.labelPlayerPaths.AutoSize = true;
            this.labelPlayerPaths.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8806F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPlayerPaths.Location = new System.Drawing.Point(198, 314);
            this.labelPlayerPaths.Name = "labelPlayerPaths";
            this.labelPlayerPaths.Size = new System.Drawing.Size(269, 44);
            this.labelPlayerPaths.TabIndex = 10;
            this.labelPlayerPaths.Text = "<PlayerPaths>";
            // 
            // textBoxSetName
            // 
            this.textBoxSetName.Location = new System.Drawing.Point(565, 9);
            this.textBoxSetName.MaxLength = 20;
            this.textBoxSetName.Name = "textBoxSetName";
            this.textBoxSetName.Size = new System.Drawing.Size(266, 22);
            this.textBoxSetName.TabIndex = 1;
            this.textBoxSetName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSetName_KeyDown);
            // 
            // buttonCharacterInfo
            // 
            this.buttonCharacterInfo.Location = new System.Drawing.Point(862, 36);
            this.buttonCharacterInfo.Name = "buttonCharacterInfo";
            this.buttonCharacterInfo.Size = new System.Drawing.Size(132, 31);
            this.buttonCharacterInfo.TabIndex = 2;
            this.buttonCharacterInfo.Text = "Info";
            this.buttonCharacterInfo.UseVisualStyleBackColor = true;
            this.buttonCharacterInfo.Click += new System.EventHandler(this.buttonCharacterInfo_Click);
            // 
            // comboBoxPact
            // 
            this.comboBoxPact.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPact.FormattingEnabled = true;
            this.comboBoxPact.Location = new System.Drawing.Point(565, 40);
            this.comboBoxPact.Name = "comboBoxPact";
            this.comboBoxPact.Size = new System.Drawing.Size(266, 24);
            this.comboBoxPact.TabIndex = 3;
            this.comboBoxPact.SelectedIndexChanged += new System.EventHandler(this.comboBoxPact_SelectedIndexChanged);
            // 
            // buttonSetPathSun
            // 
            this.buttonSetPathSun.Location = new System.Drawing.Point(565, 329);
            this.buttonSetPathSun.Name = "buttonSetPathSun";
            this.buttonSetPathSun.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathSun.TabIndex = 21;
            this.buttonSetPathSun.Text = "Sun";
            this.buttonSetPathSun.UseVisualStyleBackColor = true;
            this.buttonSetPathSun.Click += new System.EventHandler(this.buttonSetPathSun_Click);
            // 
            // buttonSetPathMoon
            // 
            this.buttonSetPathMoon.Location = new System.Drawing.Point(701, 329);
            this.buttonSetPathMoon.Name = "buttonSetPathMoon";
            this.buttonSetPathMoon.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathMoon.TabIndex = 22;
            this.buttonSetPathMoon.Text = "Moon";
            this.buttonSetPathMoon.UseVisualStyleBackColor = true;
            this.buttonSetPathMoon.Click += new System.EventHandler(this.buttonSetPathMoon_Click);
            // 
            // buttonSetPathStars
            // 
            this.buttonSetPathStars.Location = new System.Drawing.Point(565, 366);
            this.buttonSetPathStars.Name = "buttonSetPathStars";
            this.buttonSetPathStars.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathStars.TabIndex = 23;
            this.buttonSetPathStars.Text = "Stars";
            this.buttonSetPathStars.UseVisualStyleBackColor = true;
            this.buttonSetPathStars.Click += new System.EventHandler(this.buttonSetPathStars_Click);
            // 
            // buttonSetPathVoid
            // 
            this.buttonSetPathVoid.Location = new System.Drawing.Point(701, 366);
            this.buttonSetPathVoid.Name = "buttonSetPathVoid";
            this.buttonSetPathVoid.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathVoid.TabIndex = 24;
            this.buttonSetPathVoid.Text = "Void";
            this.buttonSetPathVoid.UseVisualStyleBackColor = true;
            this.buttonSetPathVoid.Click += new System.EventHandler(this.buttonSetPathVoid_Click);
            // 
            // listBoxPlayerTraits
            // 
            this.listBoxPlayerTraits.BackColor = System.Drawing.SystemColors.Control;
            this.listBoxPlayerTraits.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBoxPlayerTraits.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxPlayerTraits.FormattingEnabled = true;
            this.listBoxPlayerTraits.ItemHeight = 30;
            this.listBoxPlayerTraits.Location = new System.Drawing.Point(198, 365);
            this.listBoxPlayerTraits.Name = "listBoxPlayerTraits";
            this.listBoxPlayerTraits.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listBoxPlayerTraits.Size = new System.Drawing.Size(295, 240);
            this.listBoxPlayerTraits.TabIndex = 15;
            // 
            // labelMasteryValue
            // 
            this.labelMasteryValue.AutoSize = true;
            this.labelMasteryValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMasteryValue.Location = new System.Drawing.Point(19, 200);
            this.labelMasteryValue.Name = "labelMasteryValue";
            this.labelMasteryValue.Size = new System.Drawing.Size(219, 31);
            this.labelMasteryValue.TabIndex = 14;
            this.labelMasteryValue.Text = "<Mastery Value>";
            // 
            // listBoxMasteries
            // 
            this.listBoxMasteries.BackColor = System.Drawing.SystemColors.Control;
            this.listBoxMasteries.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBoxMasteries.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxMasteries.FormattingEnabled = true;
            this.listBoxMasteries.ItemHeight = 30;
            this.listBoxMasteries.Location = new System.Drawing.Point(200, 169);
            this.listBoxMasteries.Name = "listBoxMasteries";
            this.listBoxMasteries.Size = new System.Drawing.Size(291, 150);
            this.listBoxMasteries.TabIndex = 13;
            // 
            // labelTraitsPrompt
            // 
            this.labelTraitsPrompt.AutoSize = true;
            this.labelTraitsPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelTraitsPrompt, 3);
            this.labelTraitsPrompt.Location = new System.Drawing.Point(20, 365);
            this.labelTraitsPrompt.Name = "labelTraitsPrompt";
            this.labelTraitsPrompt.Size = new System.Drawing.Size(91, 31);
            this.labelTraitsPrompt.TabIndex = 12;
            this.labelTraitsPrompt.Text = "Traits:";
            // 
            // labelPathsPrompt
            // 
            this.labelPathsPrompt.AutoSize = true;
            this.labelPathsPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPathsPrompt.Location = new System.Drawing.Point(19, 322);
            this.labelPathsPrompt.Name = "labelPathsPrompt";
            this.labelPathsPrompt.Size = new System.Drawing.Size(92, 31);
            this.labelPathsPrompt.TabIndex = 9;
            this.labelPathsPrompt.Text = "Paths:";
            // 
            // labelMasteriesPrompt
            // 
            this.labelMasteriesPrompt.AutoSize = true;
            this.labelMasteriesPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelMasteriesPrompt, 3);
            this.labelMasteriesPrompt.Location = new System.Drawing.Point(19, 169);
            this.labelMasteriesPrompt.Name = "labelMasteriesPrompt";
            this.labelMasteriesPrompt.Size = new System.Drawing.Size(140, 31);
            this.labelMasteriesPrompt.TabIndex = 6;
            this.labelMasteriesPrompt.Text = "Masteries:";
            // 
            // labelFactionPrompt
            // 
            this.labelFactionPrompt.AutoSize = true;
            this.labelFactionPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFactionPrompt.Location = new System.Drawing.Point(19, 90);
            this.labelFactionPrompt.Name = "labelFactionPrompt";
            this.labelFactionPrompt.Size = new System.Drawing.Size(112, 31);
            this.labelFactionPrompt.TabIndex = 4;
            this.labelFactionPrompt.Text = "Faction:";
            // 
            // labelPactPrompt
            // 
            this.labelPactPrompt.AutoSize = true;
            this.labelPactPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPactPrompt.Location = new System.Drawing.Point(19, 51);
            this.labelPactPrompt.Name = "labelPactPrompt";
            this.labelPactPrompt.Size = new System.Drawing.Size(77, 31);
            this.labelPactPrompt.TabIndex = 2;
            this.labelPactPrompt.Text = "Pact:";
            // 
            // labelNamePrompt
            // 
            this.labelNamePrompt.AutoSize = true;
            this.labelNamePrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNamePrompt.Location = new System.Drawing.Point(19, 7);
            this.labelNamePrompt.Name = "labelNamePrompt";
            this.labelNamePrompt.Size = new System.Drawing.Size(94, 31);
            this.labelNamePrompt.TabIndex = 0;
            this.labelNamePrompt.Text = "Name:";
            // 
            // comboBoxFaction
            // 
            this.comboBoxFaction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFaction.FormattingEnabled = true;
            this.comboBoxFaction.Location = new System.Drawing.Point(565, 72);
            this.comboBoxFaction.Name = "comboBoxFaction";
            this.comboBoxFaction.Size = new System.Drawing.Size(266, 24);
            this.comboBoxFaction.TabIndex = 5;
            this.comboBoxFaction.SelectedIndexChanged += new System.EventHandler(this.comboBoxFaction_SelectedIndexChanged);
            // 
            // checkBoxIsJoyfulMaiden
            // 
            this.checkBoxIsJoyfulMaiden.AutoSize = true;
            this.checkBoxIsJoyfulMaiden.Location = new System.Drawing.Point(723, 105);
            this.checkBoxIsJoyfulMaiden.Name = "checkBoxIsJoyfulMaiden";
            this.checkBoxIsJoyfulMaiden.Size = new System.Drawing.Size(113, 20);
            this.checkBoxIsJoyfulMaiden.TabIndex = 8;
            this.checkBoxIsJoyfulMaiden.Text = "Joyful Maiden";
            this.checkBoxIsJoyfulMaiden.UseVisualStyleBackColor = true;
            this.checkBoxIsJoyfulMaiden.CheckedChanged += new System.EventHandler(this.checkBoxIsJoyfulMaiden_CheckedChanged);
            // 
            // buttonSecondPath
            // 
            this.buttonSecondPath.Location = new System.Drawing.Point(862, 328);
            this.buttonSecondPath.Name = "buttonSecondPath";
            this.buttonSecondPath.Size = new System.Drawing.Size(132, 31);
            this.buttonSecondPath.TabIndex = 29;
            this.buttonSecondPath.Text = "Second Path";
            this.buttonSecondPath.UseVisualStyleBackColor = true;
            this.buttonSecondPath.Click += new System.EventHandler(this.buttonAddPath_Click);
            // 
            // buttonResetPaths
            // 
            this.buttonResetPaths.Location = new System.Drawing.Point(862, 440);
            this.buttonResetPaths.Name = "buttonResetPaths";
            this.buttonResetPaths.Size = new System.Drawing.Size(132, 31);
            this.buttonResetPaths.TabIndex = 30;
            this.buttonResetPaths.Text = "Reset Paths";
            this.buttonResetPaths.UseVisualStyleBackColor = true;
            this.buttonResetPaths.Click += new System.EventHandler(this.buttonResetPaths_Click);
            // 
            // buttonAddEarth
            // 
            this.buttonAddEarth.Location = new System.Drawing.Point(565, 169);
            this.buttonAddEarth.Name = "buttonAddEarth";
            this.buttonAddEarth.Size = new System.Drawing.Size(130, 31);
            this.buttonAddEarth.TabIndex = 12;
            this.buttonAddEarth.Text = "Earth";
            this.buttonAddEarth.UseVisualStyleBackColor = true;
            this.buttonAddEarth.Click += new System.EventHandler(this.buttonAddEarth_Click);
            // 
            // buttonAddAir
            // 
            this.buttonAddAir.Location = new System.Drawing.Point(701, 169);
            this.buttonAddAir.Name = "buttonAddAir";
            this.buttonAddAir.Size = new System.Drawing.Size(130, 31);
            this.buttonAddAir.TabIndex = 13;
            this.buttonAddAir.Text = "Air";
            this.buttonAddAir.UseVisualStyleBackColor = true;
            this.buttonAddAir.Click += new System.EventHandler(this.buttonAddAir_Click);
            // 
            // buttonAddFire
            // 
            this.buttonAddFire.Location = new System.Drawing.Point(565, 206);
            this.buttonAddFire.Name = "buttonAddFire";
            this.buttonAddFire.Size = new System.Drawing.Size(130, 31);
            this.buttonAddFire.TabIndex = 14;
            this.buttonAddFire.Text = "Fire";
            this.buttonAddFire.UseVisualStyleBackColor = true;
            this.buttonAddFire.Click += new System.EventHandler(this.buttonAddFire_Click);
            // 
            // buttonAddWater
            // 
            this.buttonAddWater.Location = new System.Drawing.Point(701, 206);
            this.buttonAddWater.Name = "buttonAddWater";
            this.buttonAddWater.Size = new System.Drawing.Size(130, 31);
            this.buttonAddWater.TabIndex = 15;
            this.buttonAddWater.Text = "Water";
            this.buttonAddWater.UseVisualStyleBackColor = true;
            this.buttonAddWater.Click += new System.EventHandler(this.buttonAddWater_Click);
            // 
            // buttonAddCelestial
            // 
            this.buttonAddCelestial.Location = new System.Drawing.Point(565, 243);
            this.buttonAddCelestial.Name = "buttonAddCelestial";
            this.buttonAddCelestial.Size = new System.Drawing.Size(130, 31);
            this.buttonAddCelestial.TabIndex = 16;
            this.buttonAddCelestial.Text = "Celestial";
            this.buttonAddCelestial.UseVisualStyleBackColor = true;
            this.buttonAddCelestial.Click += new System.EventHandler(this.buttonAddCelestial_Click);
            // 
            // buttonAddShadow
            // 
            this.buttonAddShadow.Location = new System.Drawing.Point(701, 243);
            this.buttonAddShadow.Name = "buttonAddShadow";
            this.buttonAddShadow.Size = new System.Drawing.Size(130, 31);
            this.buttonAddShadow.TabIndex = 17;
            this.buttonAddShadow.Text = "Shadow";
            this.buttonAddShadow.UseVisualStyleBackColor = true;
            this.buttonAddShadow.Click += new System.EventHandler(this.buttonAddShadow_Click);
            // 
            // buttonAddProdigy
            // 
            this.buttonAddProdigy.Location = new System.Drawing.Point(862, 206);
            this.buttonAddProdigy.Name = "buttonAddProdigy";
            this.buttonAddProdigy.Size = new System.Drawing.Size(132, 31);
            this.buttonAddProdigy.TabIndex = 19;
            this.buttonAddProdigy.Text = "Arcane Prodigy";
            this.buttonAddProdigy.UseVisualStyleBackColor = true;
            this.buttonAddProdigy.Click += new System.EventHandler(this.buttonAddProdigy_Click);
            // 
            // buttonAddTalent
            // 
            this.buttonAddTalent.Location = new System.Drawing.Point(862, 169);
            this.buttonAddTalent.Name = "buttonAddTalent";
            this.buttonAddTalent.Size = new System.Drawing.Size(132, 31);
            this.buttonAddTalent.TabIndex = 18;
            this.buttonAddTalent.Text = "Arcane Talent";
            this.buttonAddTalent.UseVisualStyleBackColor = true;
            this.buttonAddTalent.Click += new System.EventHandler(this.buttonAddTalent_Click);
            // 
            // buttonResetMasteries
            // 
            this.buttonResetMasteries.Location = new System.Drawing.Point(861, 280);
            this.buttonResetMasteries.Name = "buttonResetMasteries";
            this.buttonResetMasteries.Size = new System.Drawing.Size(132, 31);
            this.buttonResetMasteries.TabIndex = 20;
            this.buttonResetMasteries.Text = "Reset Masteries";
            this.buttonResetMasteries.UseVisualStyleBackColor = true;
            this.buttonResetMasteries.Click += new System.EventHandler(this.buttonResetMasteries_Click);
            // 
            // buttonResetAll
            // 
            this.buttonResetAll.Location = new System.Drawing.Point(862, 611);
            this.buttonResetAll.Name = "buttonResetAll";
            this.buttonResetAll.Size = new System.Drawing.Size(132, 31);
            this.buttonResetAll.TabIndex = 39;
            this.buttonResetAll.Text = "Reset All";
            this.buttonResetAll.UseVisualStyleBackColor = true;
            this.buttonResetAll.Click += new System.EventHandler(this.buttonResetAll_Click);
            // 
            // listBoxAvailableTraits
            // 
            this.listBoxAvailableTraits.FormattingEnabled = true;
            this.listBoxAvailableTraits.ItemHeight = 16;
            this.listBoxAvailableTraits.Location = new System.Drawing.Point(565, 489);
            this.listBoxAvailableTraits.Name = "listBoxAvailableTraits";
            this.listBoxAvailableTraits.Size = new System.Drawing.Size(266, 116);
            this.listBoxAvailableTraits.TabIndex = 31;
            // 
            // buttonAddTrait
            // 
            this.buttonAddTrait.Location = new System.Drawing.Point(862, 489);
            this.buttonAddTrait.Name = "buttonAddTrait";
            this.buttonAddTrait.Size = new System.Drawing.Size(132, 31);
            this.buttonAddTrait.TabIndex = 32;
            this.buttonAddTrait.Text = "Add Trait";
            this.buttonAddTrait.UseVisualStyleBackColor = true;
            this.buttonAddTrait.Click += new System.EventHandler(this.buttonAddTrait_Click);
            // 
            // buttonRemoveTrait
            // 
            this.buttonRemoveTrait.Location = new System.Drawing.Point(861, 526);
            this.buttonRemoveTrait.Name = "buttonRemoveTrait";
            this.buttonRemoveTrait.Size = new System.Drawing.Size(132, 31);
            this.buttonRemoveTrait.TabIndex = 33;
            this.buttonRemoveTrait.Text = "Remove Trait";
            this.buttonRemoveTrait.UseVisualStyleBackColor = true;
            this.buttonRemoveTrait.Click += new System.EventHandler(this.buttonRemoveTrait_Click);
            // 
            // buttonResetTraits
            // 
            this.buttonResetTraits.Location = new System.Drawing.Point(862, 574);
            this.buttonResetTraits.Name = "buttonResetTraits";
            this.buttonResetTraits.Size = new System.Drawing.Size(132, 31);
            this.buttonResetTraits.TabIndex = 38;
            this.buttonResetTraits.Text = "Reset Traits";
            this.buttonResetTraits.UseVisualStyleBackColor = true;
            this.buttonResetTraits.Click += new System.EventHandler(this.buttonResetTraits_Click);
            // 
            // statusStripMain
            // 
            this.statusStripMain.ImageScalingSize = new System.Drawing.Size(22, 22);
            this.statusStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelLeadership,
            this.toolStripStatusLabelAllegiance,
            this.toolStripStatusLabelControl,
            this.toolStripStatusLabelPotential,
            this.toolStripStatusLabelAptitudes});
            this.statusStripMain.Location = new System.Drawing.Point(0, 677);
            this.statusStripMain.Name = "statusStripMain";
            this.statusStripMain.Size = new System.Drawing.Size(1116, 28);
            this.statusStripMain.TabIndex = 34;
            // 
            // toolStripStatusLabelLeadership
            // 
            this.toolStripStatusLabelLeadership.Name = "toolStripStatusLabelLeadership";
            this.toolStripStatusLabelLeadership.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.toolStripStatusLabelLeadership.Size = new System.Drawing.Size(128, 23);
            this.toolStripStatusLabelLeadership.Text = "<Leadership>";
            this.toolStripStatusLabelLeadership.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // toolStripStatusLabelAllegiance
            // 
            this.toolStripStatusLabelAllegiance.Name = "toolStripStatusLabelAllegiance";
            this.toolStripStatusLabelAllegiance.Size = new System.Drawing.Size(112, 23);
            this.toolStripStatusLabelAllegiance.Text = "<Allegiance>";
            this.toolStripStatusLabelAllegiance.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // toolStripStatusLabelControl
            // 
            this.toolStripStatusLabelControl.Name = "toolStripStatusLabelControl";
            this.toolStripStatusLabelControl.Size = new System.Drawing.Size(91, 23);
            this.toolStripStatusLabelControl.Text = "<Control>";
            this.toolStripStatusLabelControl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabelPotential
            // 
            this.toolStripStatusLabelPotential.Name = "toolStripStatusLabelPotential";
            this.toolStripStatusLabelPotential.Size = new System.Drawing.Size(101, 23);
            this.toolStripStatusLabelPotential.Text = "<Potential>";
            this.toolStripStatusLabelPotential.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabelAptitudes
            // 
            this.toolStripStatusLabelAptitudes.Name = "toolStripStatusLabelAptitudes";
            this.toolStripStatusLabelAptitudes.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.toolStripStatusLabelAptitudes.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStripStatusLabelAptitudes.Size = new System.Drawing.Size(127, 23);
            this.toolStripStatusLabelAptitudes.Text = "<Aptitudes>";
            this.toolStripStatusLabelAptitudes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // errorProvider
            // 
            this.errorProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider.ContainerControl = this;
            // 
            // labelElementalSpells
            // 
            this.labelElementalSpells.AutoSize = true;
            this.labelElementalSpells.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelElementalSpells, 3);
            this.labelElementalSpells.Location = new System.Drawing.Point(15, 14);
            this.labelElementalSpells.Name = "labelElementalSpells";
            this.labelElementalSpells.Size = new System.Drawing.Size(223, 31);
            this.labelElementalSpells.TabIndex = 0;
            this.labelElementalSpells.Text = "Elemental Spells:";
            // 
            // labelCommonSpells
            // 
            this.labelCommonSpells.AutoSize = true;
            this.labelCommonSpells.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelCommonSpells, 3);
            this.labelCommonSpells.Location = new System.Drawing.Point(324, 11);
            this.labelCommonSpells.Name = "labelCommonSpells";
            this.labelCommonSpells.Size = new System.Drawing.Size(212, 31);
            this.labelCommonSpells.TabIndex = 2;
            this.labelCommonSpells.Text = "Common Spells:";
            // 
            // labelSignatureSpell
            // 
            this.labelSignatureSpell.AutoSize = true;
            this.labelSignatureSpell.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelSignatureSpell, 3);
            this.labelSignatureSpell.Location = new System.Drawing.Point(15, 298);
            this.labelSignatureSpell.Name = "labelSignatureSpell";
            this.labelSignatureSpell.Size = new System.Drawing.Size(205, 31);
            this.labelSignatureSpell.TabIndex = 5;
            this.labelSignatureSpell.Text = "Signature Spell:";
            // 
            // labelAllies
            // 
            this.labelAllies.AutoSize = true;
            this.labelAllies.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelAllies, 3);
            this.labelAllies.Location = new System.Drawing.Point(15, 315);
            this.labelAllies.Name = "labelAllies";
            this.labelAllies.Size = new System.Drawing.Size(87, 31);
            this.labelAllies.TabIndex = 15;
            this.labelAllies.Text = "Allies:";
            // 
            // labelPactBound
            // 
            this.labelPactBound.AutoSize = true;
            this.labelPactBound.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelPactBound, 3);
            this.labelPactBound.Location = new System.Drawing.Point(15, 14);
            this.labelPactBound.Name = "labelPactBound";
            this.labelPactBound.Size = new System.Drawing.Size(162, 31);
            this.labelPactBound.TabIndex = 13;
            this.labelPactBound.Text = "Pact Bound:";
            // 
            // labelCompanions
            // 
            this.labelCompanions.AutoSize = true;
            this.labelCompanions.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelCompanions, 3);
            this.labelCompanions.Location = new System.Drawing.Point(338, 14);
            this.labelCompanions.Name = "labelCompanions";
            this.labelCompanions.Size = new System.Drawing.Size(174, 31);
            this.labelCompanions.TabIndex = 26;
            this.labelCompanions.Text = "Companions:";
            // 
            // labelEsotericSpell
            // 
            this.labelEsotericSpell.AutoSize = true;
            this.labelEsotericSpell.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelEsotericSpell, 3);
            this.labelEsotericSpell.Location = new System.Drawing.Point(324, 298);
            this.labelEsotericSpell.Name = "labelEsotericSpell";
            this.labelEsotericSpell.Size = new System.Drawing.Size(188, 31);
            this.labelEsotericSpell.TabIndex = 13;
            this.labelEsotericSpell.Text = "Esoteric Spell:";
            // 
            // radioButtonMight
            // 
            this.radioButtonMight.AutoSize = true;
            this.radioButtonMight.Location = new System.Drawing.Point(563, 616);
            this.radioButtonMight.Name = "radioButtonMight";
            this.radioButtonMight.Size = new System.Drawing.Size(61, 20);
            this.radioButtonMight.TabIndex = 45;
            this.radioButtonMight.TabStop = true;
            this.radioButtonMight.Text = "Might";
            this.radioButtonMight.UseVisualStyleBackColor = true;
            this.radioButtonMight.CheckedChanged += new System.EventHandler(this.radioButtonMight_CheckedChanged);
            // 
            // radioButtonIntrigue
            // 
            this.radioButtonIntrigue.AutoSize = true;
            this.radioButtonIntrigue.Location = new System.Drawing.Point(672, 616);
            this.radioButtonIntrigue.Name = "radioButtonIntrigue";
            this.radioButtonIntrigue.Size = new System.Drawing.Size(72, 20);
            this.radioButtonIntrigue.TabIndex = 36;
            this.radioButtonIntrigue.TabStop = true;
            this.radioButtonIntrigue.Text = "Intrigue";
            this.radioButtonIntrigue.UseVisualStyleBackColor = true;
            this.radioButtonIntrigue.CheckedChanged += new System.EventHandler(this.radioButtonIntrigue_CheckedChanged);
            // 
            // radioButtonLust
            // 
            this.radioButtonLust.AutoSize = true;
            this.radioButtonLust.Location = new System.Drawing.Point(783, 616);
            this.radioButtonLust.Name = "radioButtonLust";
            this.radioButtonLust.Size = new System.Drawing.Size(53, 20);
            this.radioButtonLust.TabIndex = 37;
            this.radioButtonLust.TabStop = true;
            this.radioButtonLust.Text = "Lust";
            this.radioButtonLust.UseVisualStyleBackColor = true;
            this.radioButtonLust.CheckedChanged += new System.EventHandler(this.radioButtonLust_CheckedChanged);
            // 
            // buttonSetPathOther
            // 
            this.buttonSetPathOther.Location = new System.Drawing.Point(701, 440);
            this.buttonSetPathOther.Name = "buttonSetPathOther";
            this.buttonSetPathOther.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathOther.TabIndex = 28;
            this.buttonSetPathOther.Text = "Other";
            this.buttonSetPathOther.UseVisualStyleBackColor = true;
            this.buttonSetPathOther.Click += new System.EventHandler(this.buttonSetPathMany_Click);
            // 
            // buttonSetPathSelf
            // 
            this.buttonSetPathSelf.Location = new System.Drawing.Point(565, 440);
            this.buttonSetPathSelf.Name = "buttonSetPathSelf";
            this.buttonSetPathSelf.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathSelf.TabIndex = 27;
            this.buttonSetPathSelf.Text = "Self";
            this.buttonSetPathSelf.UseVisualStyleBackColor = true;
            this.buttonSetPathSelf.Click += new System.EventHandler(this.buttonSetPathUnveiled_Click);
            // 
            // buttonSetPathChain
            // 
            this.buttonSetPathChain.Location = new System.Drawing.Point(701, 403);
            this.buttonSetPathChain.Name = "buttonSetPathChain";
            this.buttonSetPathChain.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathChain.TabIndex = 26;
            this.buttonSetPathChain.Text = "Chain";
            this.buttonSetPathChain.UseVisualStyleBackColor = true;
            this.buttonSetPathChain.Click += new System.EventHandler(this.buttonSetPathBound_Click);
            // 
            // buttonSetPathThorn
            // 
            this.buttonSetPathThorn.Location = new System.Drawing.Point(565, 403);
            this.buttonSetPathThorn.Name = "buttonSetPathThorn";
            this.buttonSetPathThorn.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathThorn.TabIndex = 25;
            this.buttonSetPathThorn.Text = "Thorn";
            this.buttonSetPathThorn.UseVisualStyleBackColor = true;
            this.buttonSetPathThorn.Click += new System.EventHandler(this.buttonSetPathLost_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.characterTab);
            this.tabControl.Controls.Add(this.spellTab);
            this.tabControl.Controls.Add(this.companionTab);
            this.tabControl.Location = new System.Drawing.Point(2, 1);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1113, 680);
            this.tabControl.TabIndex = 0;
            // 
            // characterTab
            // 
            this.characterTab.BackColor = System.Drawing.SystemColors.Control;
            this.characterTab.Controls.Add(this.buttonAddEsoteric);
            this.characterTab.Controls.Add(this.comboBoxEsoteric);
            this.characterTab.Controls.Add(this.labelGuildSchism);
            this.characterTab.Controls.Add(this.labelGuildSupportPrompt);
            this.characterTab.Controls.Add(this.groupBoxGuildSupport);
            this.characterTab.Controls.Add(this.checkBoxIsUnalignedPlayer);
            this.characterTab.Controls.Add(this.labelNamePrompt);
            this.characterTab.Controls.Add(this.listBoxPlayerTraits);
            this.characterTab.Controls.Add(this.textBoxSetName);
            this.characterTab.Controls.Add(this.buttonSetPathOther);
            this.characterTab.Controls.Add(this.buttonCharacterInfo);
            this.characterTab.Controls.Add(this.labelMasteryValue);
            this.characterTab.Controls.Add(this.comboBoxPact);
            this.characterTab.Controls.Add(this.buttonSetPathSelf);
            this.characterTab.Controls.Add(this.buttonSetPathSun);
            this.characterTab.Controls.Add(this.listBoxMasteries);
            this.characterTab.Controls.Add(this.buttonSetPathMoon);
            this.characterTab.Controls.Add(this.buttonSetPathChain);
            this.characterTab.Controls.Add(this.buttonSetPathStars);
            this.characterTab.Controls.Add(this.labelTraitsPrompt);
            this.characterTab.Controls.Add(this.buttonSetPathVoid);
            this.characterTab.Controls.Add(this.buttonSetPathThorn);
            this.characterTab.Controls.Add(this.labelPathsPrompt);
            this.characterTab.Controls.Add(this.comboBoxFaction);
            this.characterTab.Controls.Add(this.radioButtonLust);
            this.characterTab.Controls.Add(this.labelMasteriesPrompt);
            this.characterTab.Controls.Add(this.checkBoxIsJoyfulMaiden);
            this.characterTab.Controls.Add(this.radioButtonIntrigue);
            this.characterTab.Controls.Add(this.buttonSecondPath);
            this.characterTab.Controls.Add(this.labelFactionPrompt);
            this.characterTab.Controls.Add(this.buttonResetPaths);
            this.characterTab.Controls.Add(this.radioButtonMight);
            this.characterTab.Controls.Add(this.buttonAddEarth);
            this.characterTab.Controls.Add(this.labelPactPrompt);
            this.characterTab.Controls.Add(this.buttonAddAir);
            this.characterTab.Controls.Add(this.buttonAddFire);
            this.characterTab.Controls.Add(this.buttonAddWater);
            this.characterTab.Controls.Add(this.labelPlayerName);
            this.characterTab.Controls.Add(this.buttonAddCelestial);
            this.characterTab.Controls.Add(this.buttonResetTraits);
            this.characterTab.Controls.Add(this.buttonAddShadow);
            this.characterTab.Controls.Add(this.labelPlayerPact);
            this.characterTab.Controls.Add(this.buttonAddProdigy);
            this.characterTab.Controls.Add(this.buttonRemoveTrait);
            this.characterTab.Controls.Add(this.buttonAddTalent);
            this.characterTab.Controls.Add(this.labelPlayerFaction);
            this.characterTab.Controls.Add(this.buttonResetMasteries);
            this.characterTab.Controls.Add(this.buttonAddTrait);
            this.characterTab.Controls.Add(this.buttonResetAll);
            this.characterTab.Controls.Add(this.labelPlayerPaths);
            this.characterTab.Controls.Add(this.listBoxAvailableTraits);
            this.characterTab.Location = new System.Drawing.Point(4, 25);
            this.characterTab.Name = "characterTab";
            this.characterTab.Padding = new System.Windows.Forms.Padding(3);
            this.characterTab.Size = new System.Drawing.Size(1105, 651);
            this.characterTab.TabIndex = 0;
            this.characterTab.Text = "Character";
            // 
            // buttonAddEsoteric
            // 
            this.buttonAddEsoteric.Location = new System.Drawing.Point(701, 280);
            this.buttonAddEsoteric.Name = "buttonAddEsoteric";
            this.buttonAddEsoteric.Size = new System.Drawing.Size(130, 31);
            this.buttonAddEsoteric.TabIndex = 48;
            this.buttonAddEsoteric.Text = "Mystic";
            this.buttonAddEsoteric.UseVisualStyleBackColor = true;
            this.buttonAddEsoteric.Click += new System.EventHandler(this.buttonAddEsoteric_Click);
            // 
            // comboBoxEsoteric
            // 
            this.comboBoxEsoteric.BackColor = System.Drawing.SystemColors.ControlLight;
            this.comboBoxEsoteric.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEsoteric.FormattingEnabled = true;
            this.comboBoxEsoteric.ItemHeight = 16;
            this.comboBoxEsoteric.Location = new System.Drawing.Point(567, 283);
            this.comboBoxEsoteric.Name = "comboBoxEsoteric";
            this.comboBoxEsoteric.Size = new System.Drawing.Size(128, 24);
            this.comboBoxEsoteric.TabIndex = 47;
            // 
            // labelGuildSchism
            // 
            this.labelGuildSchism.AutoSize = true;
            this.labelGuildSchism.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGuildSchism.Location = new System.Drawing.Point(198, 132);
            this.labelGuildSchism.Name = "labelGuildSchism";
            this.labelGuildSchism.Size = new System.Drawing.Size(205, 31);
            this.labelGuildSchism.TabIndex = 38;
            this.labelGuildSchism.Text = "<Guild Schism>";
            // 
            // labelGuildSupportPrompt
            // 
            this.labelGuildSupportPrompt.AutoSize = true;
            this.labelGuildSupportPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGuildSupportPrompt.Location = new System.Drawing.Point(19, 132);
            this.labelGuildSupportPrompt.Name = "labelGuildSupportPrompt";
            this.labelGuildSupportPrompt.Size = new System.Drawing.Size(181, 31);
            this.labelGuildSupportPrompt.TabIndex = 37;
            this.labelGuildSupportPrompt.Text = "Guild Schism:";
            // 
            // groupBoxGuildSupport
            // 
            this.groupBoxGuildSupport.Controls.Add(this.radioButtonSupportNeither);
            this.groupBoxGuildSupport.Controls.Add(this.radioButtonSupportEternals);
            this.groupBoxGuildSupport.Controls.Add(this.radioButtonSupportVenerables);
            this.groupBoxGuildSupport.Location = new System.Drawing.Point(565, 124);
            this.groupBoxGuildSupport.Name = "groupBoxGuildSupport";
            this.groupBoxGuildSupport.Size = new System.Drawing.Size(429, 39);
            this.groupBoxGuildSupport.TabIndex = 36;
            this.groupBoxGuildSupport.TabStop = false;
            // 
            // radioButtonSupportNeither
            // 
            this.radioButtonSupportNeither.AutoSize = true;
            this.radioButtonSupportNeither.Location = new System.Drawing.Point(296, 12);
            this.radioButtonSupportNeither.Name = "radioButtonSupportNeither";
            this.radioButtonSupportNeither.Size = new System.Drawing.Size(122, 20);
            this.radioButtonSupportNeither.TabIndex = 11;
            this.radioButtonSupportNeither.TabStop = true;
            this.radioButtonSupportNeither.Text = "Support Neither";
            this.radioButtonSupportNeither.UseVisualStyleBackColor = true;
            this.radioButtonSupportNeither.CheckedChanged += new System.EventHandler(this.radioButtonSupportNeither_CheckedChanged);
            // 
            // radioButtonSupportEternals
            // 
            this.radioButtonSupportEternals.AutoSize = true;
            this.radioButtonSupportEternals.Location = new System.Drawing.Point(158, 13);
            this.radioButtonSupportEternals.Name = "radioButtonSupportEternals";
            this.radioButtonSupportEternals.Size = new System.Drawing.Size(128, 20);
            this.radioButtonSupportEternals.TabIndex = 10;
            this.radioButtonSupportEternals.TabStop = true;
            this.radioButtonSupportEternals.Text = "Support Eternals";
            this.radioButtonSupportEternals.UseVisualStyleBackColor = true;
            this.radioButtonSupportEternals.CheckedChanged += new System.EventHandler(this.radioButtonSupportEternals_CheckedChanged);
            // 
            // radioButtonSupportVenerables
            // 
            this.radioButtonSupportVenerables.AutoSize = true;
            this.radioButtonSupportVenerables.Location = new System.Drawing.Point(2, 13);
            this.radioButtonSupportVenerables.Name = "radioButtonSupportVenerables";
            this.radioButtonSupportVenerables.Size = new System.Drawing.Size(149, 20);
            this.radioButtonSupportVenerables.TabIndex = 9;
            this.radioButtonSupportVenerables.TabStop = true;
            this.radioButtonSupportVenerables.Text = "Support Venerables";
            this.radioButtonSupportVenerables.UseVisualStyleBackColor = true;
            this.radioButtonSupportVenerables.CheckedChanged += new System.EventHandler(this.radioButtonSupportVenerables_CheckedChanged);
            // 
            // checkBoxIsUnalignedPlayer
            // 
            this.checkBoxIsUnalignedPlayer.AutoSize = true;
            this.checkBoxIsUnalignedPlayer.Location = new System.Drawing.Point(567, 105);
            this.checkBoxIsUnalignedPlayer.Name = "checkBoxIsUnalignedPlayer";
            this.checkBoxIsUnalignedPlayer.Size = new System.Drawing.Size(92, 20);
            this.checkBoxIsUnalignedPlayer.TabIndex = 7;
            this.checkBoxIsUnalignedPlayer.Text = "Unaligned";
            this.checkBoxIsUnalignedPlayer.UseVisualStyleBackColor = true;
            this.checkBoxIsUnalignedPlayer.CheckedChanged += new System.EventHandler(this.checkBoxIsUnalignedPlayer_CheckedChanged);
            // 
            // spellTab
            // 
            this.spellTab.BackColor = System.Drawing.SystemColors.Control;
            this.spellTab.Controls.Add(this.textBoxEsotericSpell);
            this.spellTab.Controls.Add(this.labelEsotericSpell);
            this.spellTab.Controls.Add(this.textBoxSignatureSpell);
            this.spellTab.Controls.Add(this.labelSignatureSpell);
            this.spellTab.Controls.Add(this.labelCommonSpells);
            this.spellTab.Controls.Add(this.listBoxCommonSpells);
            this.spellTab.Controls.Add(this.listBoxKnownSpells);
            this.spellTab.Controls.Add(this.buttonInfo);
            this.spellTab.Controls.Add(this.buttonSignatureSpell);
            this.spellTab.Controls.Add(this.buttonResetSpells);
            this.spellTab.Controls.Add(this.buttonRemoveSpell);
            this.spellTab.Controls.Add(this.buttonAddSpell);
            this.spellTab.Controls.Add(this.textBoxSpellDescription);
            this.spellTab.Controls.Add(this.listBoxAvailableSpells);
            this.spellTab.Controls.Add(this.labelElementalSpells);
            this.spellTab.Location = new System.Drawing.Point(4, 25);
            this.spellTab.Name = "spellTab";
            this.spellTab.Padding = new System.Windows.Forms.Padding(3);
            this.spellTab.Size = new System.Drawing.Size(1105, 651);
            this.spellTab.TabIndex = 1;
            this.spellTab.Text = "Spells";
            // 
            // textBoxEsotericSpell
            // 
            this.textBoxEsotericSpell.Location = new System.Drawing.Point(330, 335);
            this.textBoxEsotericSpell.Name = "textBoxEsotericSpell";
            this.textBoxEsotericSpell.ReadOnly = true;
            this.textBoxEsotericSpell.Size = new System.Drawing.Size(295, 22);
            this.textBoxEsotericSpell.TabIndex = 14;
            // 
            // textBoxSignatureSpell
            // 
            this.textBoxSignatureSpell.Location = new System.Drawing.Point(21, 335);
            this.textBoxSignatureSpell.Name = "textBoxSignatureSpell";
            this.textBoxSignatureSpell.ReadOnly = true;
            this.textBoxSignatureSpell.Size = new System.Drawing.Size(295, 22);
            this.textBoxSignatureSpell.TabIndex = 6;
            // 
            // listBoxCommonSpells
            // 
            this.listBoxCommonSpells.FormattingEnabled = true;
            this.listBoxCommonSpells.ItemHeight = 16;
            this.listBoxCommonSpells.Location = new System.Drawing.Point(330, 48);
            this.listBoxCommonSpells.Name = "listBoxCommonSpells";
            this.listBoxCommonSpells.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listBoxCommonSpells.Size = new System.Drawing.Size(295, 244);
            this.listBoxCommonSpells.TabIndex = 3;
            // 
            // listBoxKnownSpells
            // 
            this.listBoxKnownSpells.FormattingEnabled = true;
            this.listBoxKnownSpells.ItemHeight = 16;
            this.listBoxKnownSpells.Location = new System.Drawing.Point(21, 48);
            this.listBoxKnownSpells.Name = "listBoxKnownSpells";
            this.listBoxKnownSpells.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listBoxKnownSpells.Size = new System.Drawing.Size(295, 244);
            this.listBoxKnownSpells.TabIndex = 1;
            // 
            // buttonInfo
            // 
            this.buttonInfo.Location = new System.Drawing.Point(560, 11);
            this.buttonInfo.Name = "buttonInfo";
            this.buttonInfo.Size = new System.Drawing.Size(65, 31);
            this.buttonInfo.TabIndex = 4;
            this.buttonInfo.Text = "Info";
            this.buttonInfo.UseVisualStyleBackColor = true;
            this.buttonInfo.Click += new System.EventHandler(this.buttonInfo_Click);
            // 
            // buttonSignatureSpell
            // 
            this.buttonSignatureSpell.Location = new System.Drawing.Point(936, 122);
            this.buttonSignatureSpell.Name = "buttonSignatureSpell";
            this.buttonSignatureSpell.Size = new System.Drawing.Size(141, 31);
            this.buttonSignatureSpell.TabIndex = 11;
            this.buttonSignatureSpell.Text = "Set Signature Spell";
            this.buttonSignatureSpell.UseVisualStyleBackColor = true;
            this.buttonSignatureSpell.Click += new System.EventHandler(this.buttonSignatureSpell_Click);
            // 
            // buttonResetSpells
            // 
            this.buttonResetSpells.Location = new System.Drawing.Point(936, 201);
            this.buttonResetSpells.Name = "buttonResetSpells";
            this.buttonResetSpells.Size = new System.Drawing.Size(141, 31);
            this.buttonResetSpells.TabIndex = 12;
            this.buttonResetSpells.Text = "Reset Spells";
            this.buttonResetSpells.UseVisualStyleBackColor = true;
            this.buttonResetSpells.Click += new System.EventHandler(this.buttonResetSpells_Click);
            // 
            // buttonRemoveSpell
            // 
            this.buttonRemoveSpell.Location = new System.Drawing.Point(936, 45);
            this.buttonRemoveSpell.Name = "buttonRemoveSpell";
            this.buttonRemoveSpell.Size = new System.Drawing.Size(141, 31);
            this.buttonRemoveSpell.TabIndex = 10;
            this.buttonRemoveSpell.Text = "Remove Spell";
            this.buttonRemoveSpell.UseVisualStyleBackColor = true;
            this.buttonRemoveSpell.Click += new System.EventHandler(this.buttonRemoveSpell_Click);
            // 
            // buttonAddSpell
            // 
            this.buttonAddSpell.Location = new System.Drawing.Point(936, 11);
            this.buttonAddSpell.Name = "buttonAddSpell";
            this.buttonAddSpell.Size = new System.Drawing.Size(141, 31);
            this.buttonAddSpell.TabIndex = 9;
            this.buttonAddSpell.Text = "Add Spell";
            this.buttonAddSpell.UseVisualStyleBackColor = true;
            this.buttonAddSpell.Click += new System.EventHandler(this.buttonAddSpell_Click);
            // 
            // textBoxSpellDescription
            // 
            this.textBoxSpellDescription.Location = new System.Drawing.Point(21, 376);
            this.textBoxSpellDescription.Multiline = true;
            this.textBoxSpellDescription.Name = "textBoxSpellDescription";
            this.textBoxSpellDescription.Size = new System.Drawing.Size(604, 263);
            this.textBoxSpellDescription.TabIndex = 7;
            // 
            // listBoxAvailableSpells
            // 
            this.listBoxAvailableSpells.FormattingEnabled = true;
            this.listBoxAvailableSpells.ItemHeight = 16;
            this.listBoxAvailableSpells.Location = new System.Drawing.Point(647, 11);
            this.listBoxAvailableSpells.Name = "listBoxAvailableSpells";
            this.listBoxAvailableSpells.Size = new System.Drawing.Size(256, 628);
            this.listBoxAvailableSpells.TabIndex = 8;
            this.listBoxAvailableSpells.SelectedIndexChanged += new System.EventHandler(this.listBoxAvailableSpells_SelectedIndexChanged);
            // 
            // companionTab
            // 
            this.companionTab.BackColor = System.Drawing.SystemColors.Control;
            this.companionTab.Controls.Add(this.buttonOverwriteCompanion);
            this.companionTab.Controls.Add(this.maskedTextBoxModifiedControlCost);
            this.companionTab.Controls.Add(this.maskedTextBoxControlCost);
            this.companionTab.Controls.Add(this.checkBoxIsLustWitch);
            this.companionTab.Controls.Add(this.checkBoxIsJoyfulMaidenCompanion);
            this.companionTab.Controls.Add(this.checkBoxIsUnaligned);
            this.companionTab.Controls.Add(this.checkBoxUseModifiedCost);
            this.companionTab.Controls.Add(this.comboBoxArcanePower);
            this.companionTab.Controls.Add(this.checkBoxIsLoverWithAllegiance);
            this.companionTab.Controls.Add(this.checkBoxIsDiscountedSlave);
            this.companionTab.Controls.Add(this.checkBoxIsKeeper);
            this.companionTab.Controls.Add(this.groupBoxLust);
            this.companionTab.Controls.Add(this.groupBoxIntrigue);
            this.companionTab.Controls.Add(this.groupBoxMight);
            this.companionTab.Controls.Add(this.groupBoxLoyalty);
            this.companionTab.Controls.Add(this.labelUseModifiedCost);
            this.companionTab.Controls.Add(this.comboBoxCompanionFaction);
            this.companionTab.Controls.Add(this.textBoxName);
            this.companionTab.Controls.Add(this.textBoxNotes);
            this.companionTab.Controls.Add(this.labelNotesPrompt);
            this.companionTab.Controls.Add(this.labelSpecial);
            this.companionTab.Controls.Add(this.labelAptitude);
            this.companionTab.Controls.Add(this.labelFaction);
            this.companionTab.Controls.Add(this.labelDevotion);
            this.companionTab.Controls.Add(this.labelControlCost);
            this.companionTab.Controls.Add(this.labelMagic);
            this.companionTab.Controls.Add(this.labelName);
            this.companionTab.Controls.Add(this.labelCompanions);
            this.companionTab.Controls.Add(this.labelAllies);
            this.companionTab.Controls.Add(this.listBoxAllies);
            this.companionTab.Controls.Add(this.listBoxLovers);
            this.companionTab.Controls.Add(this.buttonCreateCompanion);
            this.companionTab.Controls.Add(this.buttonDeleteCompanion);
            this.companionTab.Controls.Add(this.buttonClearData);
            this.companionTab.Controls.Add(this.listBoxCompanions);
            this.companionTab.Controls.Add(this.labelPactBound);
            this.companionTab.Location = new System.Drawing.Point(4, 25);
            this.companionTab.Name = "companionTab";
            this.companionTab.Size = new System.Drawing.Size(1105, 651);
            this.companionTab.TabIndex = 2;
            this.companionTab.Text = "Companions";
            // 
            // buttonOverwriteCompanion
            // 
            this.buttonOverwriteCompanion.Location = new System.Drawing.Point(778, 581);
            this.buttonOverwriteCompanion.Name = "buttonOverwriteCompanion";
            this.buttonOverwriteCompanion.Size = new System.Drawing.Size(298, 31);
            this.buttonOverwriteCompanion.TabIndex = 70;
            this.buttonOverwriteCompanion.Text = "Overwrite Selected Companion";
            this.buttonOverwriteCompanion.UseVisualStyleBackColor = true;
            // 
            // maskedTextBoxModifiedControlCost
            // 
            this.maskedTextBoxModifiedControlCost.Location = new System.Drawing.Point(1022, 162);
            this.maskedTextBoxModifiedControlCost.Mask = "0";
            this.maskedTextBoxModifiedControlCost.Name = "maskedTextBoxModifiedControlCost";
            this.maskedTextBoxModifiedControlCost.Size = new System.Drawing.Size(54, 22);
            this.maskedTextBoxModifiedControlCost.TabIndex = 50;
            // 
            // maskedTextBoxControlCost
            // 
            this.maskedTextBoxControlCost.Location = new System.Drawing.Point(778, 162);
            this.maskedTextBoxControlCost.Mask = "0";
            this.maskedTextBoxControlCost.Name = "maskedTextBoxControlCost";
            this.maskedTextBoxControlCost.ReadOnly = true;
            this.maskedTextBoxControlCost.Size = new System.Drawing.Size(54, 22);
            this.maskedTextBoxControlCost.TabIndex = 34;
            // 
            // checkBoxIsLustWitch
            // 
            this.checkBoxIsLustWitch.AutoSize = true;
            this.checkBoxIsLustWitch.Location = new System.Drawing.Point(936, 376);
            this.checkBoxIsLustWitch.Name = "checkBoxIsLustWitch";
            this.checkBoxIsLustWitch.Size = new System.Drawing.Size(90, 20);
            this.checkBoxIsLustWitch.TabIndex = 68;
            this.checkBoxIsLustWitch.Text = "Lust Witch";
            this.checkBoxIsLustWitch.UseVisualStyleBackColor = true;
            // 
            // checkBoxIsJoyfulMaidenCompanion
            // 
            this.checkBoxIsJoyfulMaidenCompanion.AutoSize = true;
            this.checkBoxIsJoyfulMaidenCompanion.Location = new System.Drawing.Point(779, 376);
            this.checkBoxIsJoyfulMaidenCompanion.Name = "checkBoxIsJoyfulMaidenCompanion";
            this.checkBoxIsJoyfulMaidenCompanion.Size = new System.Drawing.Size(113, 20);
            this.checkBoxIsJoyfulMaidenCompanion.TabIndex = 67;
            this.checkBoxIsJoyfulMaidenCompanion.Text = "Joyful Maiden";
            this.checkBoxIsJoyfulMaidenCompanion.UseVisualStyleBackColor = true;
            // 
            // checkBoxIsUnaligned
            // 
            this.checkBoxIsUnaligned.AutoSize = true;
            this.checkBoxIsUnaligned.Location = new System.Drawing.Point(936, 405);
            this.checkBoxIsUnaligned.Name = "checkBoxIsUnaligned";
            this.checkBoxIsUnaligned.Size = new System.Drawing.Size(138, 20);
            this.checkBoxIsUnaligned.TabIndex = 66;
            this.checkBoxIsUnaligned.Text = "Former Unaligned";
            this.checkBoxIsUnaligned.UseVisualStyleBackColor = true;
            // 
            // checkBoxUseModifiedCost
            // 
            this.checkBoxUseModifiedCost.AutoSize = true;
            this.checkBoxUseModifiedCost.Location = new System.Drawing.Point(867, 167);
            this.checkBoxUseModifiedCost.Name = "checkBoxUseModifiedCost";
            this.checkBoxUseModifiedCost.Size = new System.Drawing.Size(18, 17);
            this.checkBoxUseModifiedCost.TabIndex = 65;
            this.checkBoxUseModifiedCost.UseVisualStyleBackColor = true;
            // 
            // comboBoxArcanePower
            // 
            this.comboBoxArcanePower.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxArcanePower.FormattingEnabled = true;
            this.comboBoxArcanePower.Location = new System.Drawing.Point(778, 121);
            this.comboBoxArcanePower.Name = "comboBoxArcanePower";
            this.comboBoxArcanePower.Size = new System.Drawing.Size(296, 24);
            this.comboBoxArcanePower.TabIndex = 64;
            // 
            // checkBoxIsLoverWithAllegiance
            // 
            this.checkBoxIsLoverWithAllegiance.AutoSize = true;
            this.checkBoxIsLoverWithAllegiance.Location = new System.Drawing.Point(936, 348);
            this.checkBoxIsLoverWithAllegiance.Name = "checkBoxIsLoverWithAllegiance";
            this.checkBoxIsLoverWithAllegiance.Size = new System.Drawing.Size(137, 20);
            this.checkBoxIsLoverWithAllegiance.TabIndex = 63;
            this.checkBoxIsLoverWithAllegiance.Text = "Spend Allegiance";
            this.checkBoxIsLoverWithAllegiance.UseVisualStyleBackColor = true;
            // 
            // checkBoxIsDiscountedSlave
            // 
            this.checkBoxIsDiscountedSlave.AutoSize = true;
            this.checkBoxIsDiscountedSlave.Location = new System.Drawing.Point(779, 348);
            this.checkBoxIsDiscountedSlave.Name = "checkBoxIsDiscountedSlave";
            this.checkBoxIsDiscountedSlave.Size = new System.Drawing.Size(128, 20);
            this.checkBoxIsDiscountedSlave.TabIndex = 61;
            this.checkBoxIsDiscountedSlave.Text = "Enthrall For Free";
            this.checkBoxIsDiscountedSlave.UseVisualStyleBackColor = true;
            // 
            // checkBoxIsKeeper
            // 
            this.checkBoxIsKeeper.AutoSize = true;
            this.checkBoxIsKeeper.Location = new System.Drawing.Point(779, 405);
            this.checkBoxIsKeeper.Name = "checkBoxIsKeeper";
            this.checkBoxIsKeeper.Size = new System.Drawing.Size(105, 20);
            this.checkBoxIsKeeper.TabIndex = 60;
            this.checkBoxIsKeeper.Text = "Your Keeper";
            this.checkBoxIsKeeper.UseVisualStyleBackColor = true;
            // 
            // groupBoxLust
            // 
            this.groupBoxLust.Controls.Add(this.radioButtonLustPlus);
            this.groupBoxLust.Controls.Add(this.radioButtonLustAverage);
            this.groupBoxLust.Controls.Add(this.radioButtonLustMinus);
            this.groupBoxLust.Location = new System.Drawing.Point(999, 239);
            this.groupBoxLust.Name = "groupBoxLust";
            this.groupBoxLust.Size = new System.Drawing.Size(76, 88);
            this.groupBoxLust.TabIndex = 59;
            this.groupBoxLust.TabStop = false;
            // 
            // radioButtonLustPlus
            // 
            this.radioButtonLustPlus.AutoSize = true;
            this.radioButtonLustPlus.Location = new System.Drawing.Point(2, 62);
            this.radioButtonLustPlus.Name = "radioButtonLustPlus";
            this.radioButtonLustPlus.Size = new System.Drawing.Size(63, 20);
            this.radioButtonLustPlus.TabIndex = 57;
            this.radioButtonLustPlus.TabStop = true;
            this.radioButtonLustPlus.Text = "Lust +";
            this.radioButtonLustPlus.UseVisualStyleBackColor = true;
            // 
            // radioButtonLustAverage
            // 
            this.radioButtonLustAverage.AutoSize = true;
            this.radioButtonLustAverage.Location = new System.Drawing.Point(2, 36);
            this.radioButtonLustAverage.Name = "radioButtonLustAverage";
            this.radioButtonLustAverage.Size = new System.Drawing.Size(53, 20);
            this.radioButtonLustAverage.TabIndex = 1;
            this.radioButtonLustAverage.TabStop = true;
            this.radioButtonLustAverage.Text = "Lust";
            this.radioButtonLustAverage.UseVisualStyleBackColor = true;
            // 
            // radioButtonLustMinus
            // 
            this.radioButtonLustMinus.AutoSize = true;
            this.radioButtonLustMinus.Location = new System.Drawing.Point(2, 10);
            this.radioButtonLustMinus.Name = "radioButtonLustMinus";
            this.radioButtonLustMinus.Size = new System.Drawing.Size(61, 20);
            this.radioButtonLustMinus.TabIndex = 0;
            this.radioButtonLustMinus.TabStop = true;
            this.radioButtonLustMinus.Text = "Lust –";
            this.radioButtonLustMinus.UseVisualStyleBackColor = true;
            // 
            // groupBoxIntrigue
            // 
            this.groupBoxIntrigue.Controls.Add(this.radioButtonIntriguePlus);
            this.groupBoxIntrigue.Controls.Add(this.radioButtonIntrigueAverage);
            this.groupBoxIntrigue.Controls.Add(this.radioButtonIntrigueMinus);
            this.groupBoxIntrigue.Location = new System.Drawing.Point(883, 239);
            this.groupBoxIntrigue.Name = "groupBoxIntrigue";
            this.groupBoxIntrigue.Size = new System.Drawing.Size(96, 88);
            this.groupBoxIntrigue.TabIndex = 58;
            this.groupBoxIntrigue.TabStop = false;
            // 
            // radioButtonIntriguePlus
            // 
            this.radioButtonIntriguePlus.AutoSize = true;
            this.radioButtonIntriguePlus.Location = new System.Drawing.Point(2, 62);
            this.radioButtonIntriguePlus.Name = "radioButtonIntriguePlus";
            this.radioButtonIntriguePlus.Size = new System.Drawing.Size(82, 20);
            this.radioButtonIntriguePlus.TabIndex = 57;
            this.radioButtonIntriguePlus.TabStop = true;
            this.radioButtonIntriguePlus.Text = "Intrigue +";
            this.radioButtonIntriguePlus.UseVisualStyleBackColor = true;
            // 
            // radioButtonIntrigueAverage
            // 
            this.radioButtonIntrigueAverage.AutoSize = true;
            this.radioButtonIntrigueAverage.Location = new System.Drawing.Point(2, 36);
            this.radioButtonIntrigueAverage.Name = "radioButtonIntrigueAverage";
            this.radioButtonIntrigueAverage.Size = new System.Drawing.Size(72, 20);
            this.radioButtonIntrigueAverage.TabIndex = 1;
            this.radioButtonIntrigueAverage.TabStop = true;
            this.radioButtonIntrigueAverage.Text = "Intrigue";
            this.radioButtonIntrigueAverage.UseVisualStyleBackColor = true;
            // 
            // radioButtonIntrigueMinus
            // 
            this.radioButtonIntrigueMinus.AutoSize = true;
            this.radioButtonIntrigueMinus.Location = new System.Drawing.Point(2, 10);
            this.radioButtonIntrigueMinus.Name = "radioButtonIntrigueMinus";
            this.radioButtonIntrigueMinus.Size = new System.Drawing.Size(80, 20);
            this.radioButtonIntrigueMinus.TabIndex = 0;
            this.radioButtonIntrigueMinus.TabStop = true;
            this.radioButtonIntrigueMinus.Text = "Intrigue –";
            this.radioButtonIntrigueMinus.UseVisualStyleBackColor = true;
            // 
            // groupBoxMight
            // 
            this.groupBoxMight.Controls.Add(this.radioButtonMightPlus);
            this.groupBoxMight.Controls.Add(this.radioButtonMightAverage);
            this.groupBoxMight.Controls.Add(this.radioButtonMightMinus);
            this.groupBoxMight.Location = new System.Drawing.Point(777, 239);
            this.groupBoxMight.Name = "groupBoxMight";
            this.groupBoxMight.Size = new System.Drawing.Size(84, 88);
            this.groupBoxMight.TabIndex = 56;
            this.groupBoxMight.TabStop = false;
            // 
            // radioButtonMightPlus
            // 
            this.radioButtonMightPlus.AutoSize = true;
            this.radioButtonMightPlus.Location = new System.Drawing.Point(2, 62);
            this.radioButtonMightPlus.Name = "radioButtonMightPlus";
            this.radioButtonMightPlus.Size = new System.Drawing.Size(71, 20);
            this.radioButtonMightPlus.TabIndex = 57;
            this.radioButtonMightPlus.TabStop = true;
            this.radioButtonMightPlus.Text = "Might +";
            this.radioButtonMightPlus.UseVisualStyleBackColor = true;
            // 
            // radioButtonMightAverage
            // 
            this.radioButtonMightAverage.AutoSize = true;
            this.radioButtonMightAverage.Location = new System.Drawing.Point(2, 36);
            this.radioButtonMightAverage.Name = "radioButtonMightAverage";
            this.radioButtonMightAverage.Size = new System.Drawing.Size(61, 20);
            this.radioButtonMightAverage.TabIndex = 1;
            this.radioButtonMightAverage.TabStop = true;
            this.radioButtonMightAverage.Text = "Might";
            this.radioButtonMightAverage.UseVisualStyleBackColor = true;
            // 
            // radioButtonMightMinus
            // 
            this.radioButtonMightMinus.AutoSize = true;
            this.radioButtonMightMinus.Location = new System.Drawing.Point(2, 10);
            this.radioButtonMightMinus.Name = "radioButtonMightMinus";
            this.radioButtonMightMinus.Size = new System.Drawing.Size(69, 20);
            this.radioButtonMightMinus.TabIndex = 0;
            this.radioButtonMightMinus.TabStop = true;
            this.radioButtonMightMinus.Text = "Might –";
            this.radioButtonMightMinus.UseVisualStyleBackColor = true;
            // 
            // groupBoxLoyalty
            // 
            this.groupBoxLoyalty.Controls.Add(this.radioButtonNone);
            this.groupBoxLoyalty.Controls.Add(this.radioButtonAlly);
            this.groupBoxLoyalty.Controls.Add(this.radioButtonSlave);
            this.groupBoxLoyalty.Controls.Add(this.radioButtonLover);
            this.groupBoxLoyalty.Location = new System.Drawing.Point(777, 190);
            this.groupBoxLoyalty.Name = "groupBoxLoyalty";
            this.groupBoxLoyalty.Size = new System.Drawing.Size(298, 39);
            this.groupBoxLoyalty.TabIndex = 55;
            this.groupBoxLoyalty.TabStop = false;
            // 
            // radioButtonNone
            // 
            this.radioButtonNone.AutoSize = true;
            this.radioButtonNone.Location = new System.Drawing.Point(2, 13);
            this.radioButtonNone.Name = "radioButtonNone";
            this.radioButtonNone.Size = new System.Drawing.Size(62, 20);
            this.radioButtonNone.TabIndex = 54;
            this.radioButtonNone.TabStop = true;
            this.radioButtonNone.Text = "None";
            this.radioButtonNone.UseVisualStyleBackColor = true;
            // 
            // radioButtonAlly
            // 
            this.radioButtonAlly.AutoSize = true;
            this.radioButtonAlly.Location = new System.Drawing.Point(82, 13);
            this.radioButtonAlly.Name = "radioButtonAlly";
            this.radioButtonAlly.Size = new System.Drawing.Size(51, 20);
            this.radioButtonAlly.TabIndex = 51;
            this.radioButtonAlly.TabStop = true;
            this.radioButtonAlly.Text = "Ally";
            this.radioButtonAlly.UseVisualStyleBackColor = true;
            // 
            // radioButtonSlave
            // 
            this.radioButtonSlave.AutoSize = true;
            this.radioButtonSlave.Location = new System.Drawing.Point(223, 13);
            this.radioButtonSlave.Name = "radioButtonSlave";
            this.radioButtonSlave.Size = new System.Drawing.Size(64, 20);
            this.radioButtonSlave.TabIndex = 53;
            this.radioButtonSlave.TabStop = true;
            this.radioButtonSlave.Text = "Slave";
            this.radioButtonSlave.UseVisualStyleBackColor = true;
            // 
            // radioButtonLover
            // 
            this.radioButtonLover.AutoSize = true;
            this.radioButtonLover.Location = new System.Drawing.Point(150, 13);
            this.radioButtonLover.Name = "radioButtonLover";
            this.radioButtonLover.Size = new System.Drawing.Size(63, 20);
            this.radioButtonLover.TabIndex = 52;
            this.radioButtonLover.TabStop = true;
            this.radioButtonLover.Text = "Lover";
            this.radioButtonLover.UseVisualStyleBackColor = true;
            // 
            // labelUseModifiedCost
            // 
            this.labelUseModifiedCost.AutoSize = true;
            this.labelUseModifiedCost.Location = new System.Drawing.Point(892, 167);
            this.labelUseModifiedCost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelUseModifiedCost.Name = "labelUseModifiedCost";
            this.labelUseModifiedCost.Size = new System.Drawing.Size(121, 16);
            this.labelUseModifiedCost.TabIndex = 49;
            this.labelUseModifiedCost.Text = "Use Modified Cost:";
            // 
            // comboBoxCompanionFaction
            // 
            this.comboBoxCompanionFaction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCompanionFaction.FormattingEnabled = true;
            this.comboBoxCompanionFaction.Location = new System.Drawing.Point(779, 84);
            this.comboBoxCompanionFaction.Name = "comboBoxCompanionFaction";
            this.comboBoxCompanionFaction.Size = new System.Drawing.Size(296, 24);
            this.comboBoxCompanionFaction.TabIndex = 48;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(778, 48);
            this.textBoxName.MaxLength = 40;
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(297, 22);
            this.textBoxName.TabIndex = 47;
            // 
            // textBoxNotes
            // 
            this.textBoxNotes.Location = new System.Drawing.Point(778, 431);
            this.textBoxNotes.MaxLength = 4000;
            this.textBoxNotes.Multiline = true;
            this.textBoxNotes.Name = "textBoxNotes";
            this.textBoxNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxNotes.Size = new System.Drawing.Size(298, 92);
            this.textBoxNotes.TabIndex = 46;
            // 
            // labelNotesPrompt
            // 
            this.labelNotesPrompt.AutoSize = true;
            this.labelNotesPrompt.Location = new System.Drawing.Point(630, 431);
            this.labelNotesPrompt.Name = "labelNotesPrompt";
            this.labelNotesPrompt.Size = new System.Drawing.Size(47, 16);
            this.labelNotesPrompt.TabIndex = 45;
            this.labelNotesPrompt.Text = "Not&es:";
            // 
            // labelSpecial
            // 
            this.labelSpecial.AutoSize = true;
            this.labelSpecial.Location = new System.Drawing.Point(630, 349);
            this.labelSpecial.Name = "labelSpecial";
            this.labelSpecial.Size = new System.Drawing.Size(57, 16);
            this.labelSpecial.TabIndex = 43;
            this.labelSpecial.Text = "Special:";
            // 
            // labelAptitude
            // 
            this.labelAptitude.AutoSize = true;
            this.labelAptitude.Location = new System.Drawing.Point(630, 238);
            this.labelAptitude.Name = "labelAptitude";
            this.labelAptitude.Size = new System.Drawing.Size(60, 16);
            this.labelAptitude.TabIndex = 37;
            this.labelAptitude.Text = "Aptitude:";
            // 
            // labelFaction
            // 
            this.labelFaction.AutoSize = true;
            this.labelFaction.Location = new System.Drawing.Point(630, 86);
            this.labelFaction.Name = "labelFaction";
            this.labelFaction.Size = new System.Drawing.Size(55, 16);
            this.labelFaction.TabIndex = 29;
            this.labelFaction.Text = "Faction:";
            // 
            // labelDevotion
            // 
            this.labelDevotion.AutoSize = true;
            this.labelDevotion.Location = new System.Drawing.Point(630, 200);
            this.labelDevotion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDevotion.Name = "labelDevotion";
            this.labelDevotion.Size = new System.Drawing.Size(65, 16);
            this.labelDevotion.TabIndex = 35;
            this.labelDevotion.Text = "Devotion:";
            // 
            // labelControlCost
            // 
            this.labelControlCost.AutoSize = true;
            this.labelControlCost.Location = new System.Drawing.Point(630, 162);
            this.labelControlCost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelControlCost.Name = "labelControlCost";
            this.labelControlCost.Size = new System.Drawing.Size(83, 16);
            this.labelControlCost.TabIndex = 33;
            this.labelControlCost.Text = "Control Cost:";
            // 
            // labelMagic
            // 
            this.labelMagic.AutoSize = true;
            this.labelMagic.Location = new System.Drawing.Point(630, 124);
            this.labelMagic.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelMagic.Name = "labelMagic";
            this.labelMagic.Size = new System.Drawing.Size(95, 16);
            this.labelMagic.TabIndex = 31;
            this.labelMagic.Text = "Arcane Power:";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(630, 48);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(48, 16);
            this.labelName.TabIndex = 27;
            this.labelName.Text = "Name:";
            // 
            // listBoxAllies
            // 
            this.listBoxAllies.FormattingEnabled = true;
            this.listBoxAllies.ItemHeight = 16;
            this.listBoxAllies.Location = new System.Drawing.Point(21, 352);
            this.listBoxAllies.Name = "listBoxAllies";
            this.listBoxAllies.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listBoxAllies.Size = new System.Drawing.Size(295, 260);
            this.listBoxAllies.TabIndex = 16;
            // 
            // listBoxLovers
            // 
            this.listBoxLovers.FormattingEnabled = true;
            this.listBoxLovers.ItemHeight = 16;
            this.listBoxLovers.Location = new System.Drawing.Point(21, 48);
            this.listBoxLovers.Name = "listBoxLovers";
            this.listBoxLovers.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listBoxLovers.Size = new System.Drawing.Size(295, 260);
            this.listBoxLovers.TabIndex = 14;
            // 
            // buttonCreateCompanion
            // 
            this.buttonCreateCompanion.Location = new System.Drawing.Point(777, 544);
            this.buttonCreateCompanion.Name = "buttonCreateCompanion";
            this.buttonCreateCompanion.Size = new System.Drawing.Size(299, 31);
            this.buttonCreateCompanion.TabIndex = 24;
            this.buttonCreateCompanion.Text = "Create New Companion";
            this.buttonCreateCompanion.UseVisualStyleBackColor = true;
            this.buttonCreateCompanion.Click += new System.EventHandler(this.buttonSaveCompanion_Click);
            // 
            // buttonDeleteCompanion
            // 
            this.buttonDeleteCompanion.Location = new System.Drawing.Point(620, 581);
            this.buttonDeleteCompanion.Name = "buttonDeleteCompanion";
            this.buttonDeleteCompanion.Size = new System.Drawing.Size(141, 31);
            this.buttonDeleteCompanion.TabIndex = 23;
            this.buttonDeleteCompanion.Text = "Delete Companion";
            this.buttonDeleteCompanion.UseVisualStyleBackColor = true;
            this.buttonDeleteCompanion.Click += new System.EventHandler(this.buttonDeleteCompanion_Click);
            // 
            // buttonClearData
            // 
            this.buttonClearData.Location = new System.Drawing.Point(620, 544);
            this.buttonClearData.Name = "buttonClearData";
            this.buttonClearData.Size = new System.Drawing.Size(141, 31);
            this.buttonClearData.TabIndex = 22;
            this.buttonClearData.Text = "Clear Form Data";
            this.buttonClearData.UseVisualStyleBackColor = true;
            this.buttonClearData.Click += new System.EventHandler(this.buttonClearData_Click);
            // 
            // listBoxCompanions
            // 
            this.listBoxCompanions.FormattingEnabled = true;
            this.listBoxCompanions.ItemHeight = 16;
            this.listBoxCompanions.Location = new System.Drawing.Point(344, 48);
            this.listBoxCompanions.Name = "listBoxCompanions";
            this.listBoxCompanions.Size = new System.Drawing.Size(256, 564);
            this.listBoxCompanions.TabIndex = 21;
            this.listBoxCompanions.SelectedIndexChanged += new System.EventHandler(this.listBoxCompanions_SelectedIndexChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 705);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.statusStripMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phoenix Throne Character Generator v0.2.2";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStripMain.ResumeLayout(false);
            this.statusStripMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.characterTab.ResumeLayout(false);
            this.characterTab.PerformLayout();
            this.groupBoxGuildSupport.ResumeLayout(false);
            this.groupBoxGuildSupport.PerformLayout();
            this.spellTab.ResumeLayout(false);
            this.spellTab.PerformLayout();
            this.companionTab.ResumeLayout(false);
            this.companionTab.PerformLayout();
            this.groupBoxLust.ResumeLayout(false);
            this.groupBoxLust.PerformLayout();
            this.groupBoxIntrigue.ResumeLayout(false);
            this.groupBoxIntrigue.PerformLayout();
            this.groupBoxMight.ResumeLayout(false);
            this.groupBoxMight.PerformLayout();
            this.groupBoxLoyalty.ResumeLayout(false);
            this.groupBoxLoyalty.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPlayerName;
        private System.Windows.Forms.Label labelPlayerPact;
        private System.Windows.Forms.Label labelPlayerFaction;
        private System.Windows.Forms.Label labelPlayerPaths;
        private System.Windows.Forms.TextBox textBoxSetName;
        private System.Windows.Forms.Button buttonCharacterInfo;
        private System.Windows.Forms.ComboBox comboBoxPact;
        private System.Windows.Forms.Button buttonSetPathSun;
        private System.Windows.Forms.Button buttonSetPathMoon;
        private System.Windows.Forms.Button buttonSetPathStars;
        private System.Windows.Forms.Button buttonSetPathVoid;
        private System.Windows.Forms.Label labelNamePrompt;
        private System.Windows.Forms.Label labelPactPrompt;
        private System.Windows.Forms.Label labelMasteriesPrompt;
        private System.Windows.Forms.Label labelFactionPrompt;
        private System.Windows.Forms.ComboBox comboBoxFaction;
        private System.Windows.Forms.CheckBox checkBoxIsJoyfulMaiden;
        private System.Windows.Forms.Label labelPathsPrompt;
        private System.Windows.Forms.Button buttonSecondPath;
        private System.Windows.Forms.Button buttonResetPaths;
        private System.Windows.Forms.Label labelTraitsPrompt;
        private System.Windows.Forms.ListBox listBoxMasteries;
        private System.Windows.Forms.Button buttonAddEarth;
        private System.Windows.Forms.Button buttonAddAir;
        private System.Windows.Forms.Button buttonAddFire;
        private System.Windows.Forms.Button buttonAddWater;
        private System.Windows.Forms.Button buttonAddCelestial;
        private System.Windows.Forms.Button buttonAddShadow;
        private System.Windows.Forms.Button buttonAddProdigy;
        private System.Windows.Forms.Button buttonAddTalent;
        private System.Windows.Forms.Button buttonResetMasteries;
        private System.Windows.Forms.Label labelMasteryValue;
        private System.Windows.Forms.Button buttonResetAll;
        private System.Windows.Forms.ListBox listBoxPlayerTraits;
        private System.Windows.Forms.ListBox listBoxAvailableTraits;
        private System.Windows.Forms.Button buttonAddTrait;
        private System.Windows.Forms.Button buttonRemoveTrait;
        private System.Windows.Forms.Button buttonResetTraits;
        private System.Windows.Forms.StatusStrip statusStripMain;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelControl;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelAllegiance;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelPotential;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelAptitudes;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.RadioButton radioButtonLust;
        private System.Windows.Forms.RadioButton radioButtonIntrigue;
        private System.Windows.Forms.RadioButton radioButtonMight;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelLeadership;
        private System.Windows.Forms.Button buttonSetPathOther;
        private System.Windows.Forms.Button buttonSetPathSelf;
        private System.Windows.Forms.Button buttonSetPathChain;
        private System.Windows.Forms.Button buttonSetPathThorn;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage characterTab;
        private System.Windows.Forms.TabPage spellTab;
        private System.Windows.Forms.TabPage companionTab;
        private System.Windows.Forms.Label labelElementalSpells;
        private System.Windows.Forms.TextBox textBoxSpellDescription;
        private System.Windows.Forms.ListBox listBoxAvailableSpells;
        private System.Windows.Forms.Button buttonResetSpells;
        private System.Windows.Forms.Button buttonRemoveSpell;
        private System.Windows.Forms.Button buttonAddSpell;
        private System.Windows.Forms.Button buttonSignatureSpell;
        private System.Windows.Forms.Label labelCommonSpells;
        private System.Windows.Forms.ListBox listBoxCommonSpells;
        private System.Windows.Forms.ListBox listBoxKnownSpells;
        private System.Windows.Forms.Button buttonInfo;
        private System.Windows.Forms.Label labelSignatureSpell;
        private System.Windows.Forms.TextBox textBoxSignatureSpell;
        private System.Windows.Forms.Label labelCompanions;
        private System.Windows.Forms.Label labelAllies;
        private System.Windows.Forms.ListBox listBoxAllies;
        private System.Windows.Forms.ListBox listBoxLovers;
        private System.Windows.Forms.Button buttonCreateCompanion;
        private System.Windows.Forms.Button buttonDeleteCompanion;
        private System.Windows.Forms.Button buttonClearData;
        private System.Windows.Forms.ListBox listBoxCompanions;
        private System.Windows.Forms.Label labelPactBound;
        private System.Windows.Forms.TextBox textBoxNotes;
        private System.Windows.Forms.Label labelNotesPrompt;
        private System.Windows.Forms.Label labelSpecial;
        private System.Windows.Forms.Label labelAptitude;
        private System.Windows.Forms.Label labelFaction;
        private System.Windows.Forms.Label labelDevotion;
        private System.Windows.Forms.Label labelControlCost;
        private System.Windows.Forms.Label labelMagic;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.ComboBox comboBoxCompanionFaction;
        private System.Windows.Forms.Label labelUseModifiedCost;
        private System.Windows.Forms.RadioButton radioButtonAlly;
        private System.Windows.Forms.GroupBox groupBoxLoyalty;
        private System.Windows.Forms.RadioButton radioButtonNone;
        private System.Windows.Forms.RadioButton radioButtonSlave;
        private System.Windows.Forms.RadioButton radioButtonLover;
        private System.Windows.Forms.GroupBox groupBoxMight;
        private System.Windows.Forms.RadioButton radioButtonMightPlus;
        private System.Windows.Forms.RadioButton radioButtonMightAverage;
        private System.Windows.Forms.RadioButton radioButtonMightMinus;
        private System.Windows.Forms.GroupBox groupBoxIntrigue;
        private System.Windows.Forms.RadioButton radioButtonIntriguePlus;
        private System.Windows.Forms.RadioButton radioButtonIntrigueAverage;
        private System.Windows.Forms.RadioButton radioButtonIntrigueMinus;
        private System.Windows.Forms.GroupBox groupBoxLust;
        private System.Windows.Forms.RadioButton radioButtonLustPlus;
        private System.Windows.Forms.RadioButton radioButtonLustAverage;
        private System.Windows.Forms.RadioButton radioButtonLustMinus;
        private System.Windows.Forms.CheckBox checkBoxIsKeeper;
        private System.Windows.Forms.CheckBox checkBoxIsDiscountedSlave;
        private System.Windows.Forms.CheckBox checkBoxIsLoverWithAllegiance;
        private System.Windows.Forms.ComboBox comboBoxArcanePower;
        private System.Windows.Forms.CheckBox checkBoxIsUnalignedPlayer;
        private System.Windows.Forms.GroupBox groupBoxGuildSupport;
        private System.Windows.Forms.RadioButton radioButtonSupportVenerables;
        private System.Windows.Forms.RadioButton radioButtonSupportNeither;
        private System.Windows.Forms.RadioButton radioButtonSupportEternals;
        private System.Windows.Forms.Label labelGuildSchism;
        private System.Windows.Forms.Label labelGuildSupportPrompt;
        private System.Windows.Forms.CheckBox checkBoxUseModifiedCost;
        private System.Windows.Forms.Button buttonAddEsoteric;
        private System.Windows.Forms.ComboBox comboBoxEsoteric;
        private System.Windows.Forms.Label labelEsotericSpell;
        private System.Windows.Forms.TextBox textBoxEsotericSpell;
        private System.Windows.Forms.CheckBox checkBoxIsUnaligned;
        private System.Windows.Forms.CheckBox checkBoxIsLustWitch;
        private System.Windows.Forms.CheckBox checkBoxIsJoyfulMaidenCompanion;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxControlCost;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxModifiedControlCost;
        private System.Windows.Forms.Button buttonOverwriteCompanion;
    }
}

