﻿namespace CharacterGenerator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.labelPlayerName = new System.Windows.Forms.Label();
            this.labelPlayerPact = new System.Windows.Forms.Label();
            this.labelPlayerFaction = new System.Windows.Forms.Label();
            this.labelPlayerPaths = new System.Windows.Forms.Label();
            this.textBoxSetName = new System.Windows.Forms.TextBox();
            this.buttonSetName = new System.Windows.Forms.Button();
            this.comboBoxPact = new System.Windows.Forms.ComboBox();
            this.buttonSetPathSun = new System.Windows.Forms.Button();
            this.buttonSetPathMoon = new System.Windows.Forms.Button();
            this.buttonSetPathStars = new System.Windows.Forms.Button();
            this.buttonSetPathVoid = new System.Windows.Forms.Button();
            this.groupBoxPlayerCharacter = new System.Windows.Forms.GroupBox();
            this.listBoxPlayerTraits = new System.Windows.Forms.ListBox();
            this.labelMasteryValue = new System.Windows.Forms.Label();
            this.listBoxMasteries = new System.Windows.Forms.ListBox();
            this.labelTraitsPrompt = new System.Windows.Forms.Label();
            this.labelPathsPrompt = new System.Windows.Forms.Label();
            this.labelMasteriesPrompt = new System.Windows.Forms.Label();
            this.labelFactionPrompt = new System.Windows.Forms.Label();
            this.labelPactPrompt = new System.Windows.Forms.Label();
            this.labelNamePrompt = new System.Windows.Forms.Label();
            this.buttonSetPact = new System.Windows.Forms.Button();
            this.comboBoxFaction = new System.Windows.Forms.ComboBox();
            this.buttonSetFaction = new System.Windows.Forms.Button();
            this.checkBoxIsJoyfulMaiden = new System.Windows.Forms.CheckBox();
            this.buttonSecondPath = new System.Windows.Forms.Button();
            this.buttonResetPaths = new System.Windows.Forms.Button();
            this.buttonAddEarth = new System.Windows.Forms.Button();
            this.buttonAddAir = new System.Windows.Forms.Button();
            this.buttonAddFire = new System.Windows.Forms.Button();
            this.buttonAddWater = new System.Windows.Forms.Button();
            this.buttonAddCelestial = new System.Windows.Forms.Button();
            this.buttonAddShadow = new System.Windows.Forms.Button();
            this.buttonAddProdigy = new System.Windows.Forms.Button();
            this.buttonAddTalent = new System.Windows.Forms.Button();
            this.buttonResetMasteries = new System.Windows.Forms.Button();
            this.buttonResetAll = new System.Windows.Forms.Button();
            this.listBoxAvailableTraits = new System.Windows.Forms.ListBox();
            this.buttonAddTrait = new System.Windows.Forms.Button();
            this.buttonRemoveTrait = new System.Windows.Forms.Button();
            this.buttonResetTraits = new System.Windows.Forms.Button();
            this.statusStripMain = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelLeadership = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelAllegiance = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelControl = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelPotential = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelAptitudes = new System.Windows.Forms.ToolStripStatusLabel();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.radioButtonMight = new System.Windows.Forms.RadioButton();
            this.radioButtonIntrigue = new System.Windows.Forms.RadioButton();
            this.radioButtonLust = new System.Windows.Forms.RadioButton();
            this.buttonSetPathMany = new System.Windows.Forms.Button();
            this.buttonSetPathUnveiled = new System.Windows.Forms.Button();
            this.buttonSetPathBound = new System.Windows.Forms.Button();
            this.buttonSetPathLost = new System.Windows.Forms.Button();
            this.groupBoxPlayerCharacter.SuspendLayout();
            this.statusStripMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // labelPlayerName
            // 
            this.labelPlayerName.AutoSize = true;
            this.labelPlayerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPlayerName.Location = new System.Drawing.Point(178, 32);
            this.labelPlayerName.Name = "labelPlayerName";
            this.labelPlayerName.Size = new System.Drawing.Size(195, 31);
            this.labelPlayerName.TabIndex = 1;
            this.labelPlayerName.Text = "<PlayerName>";
            // 
            // labelPlayerPact
            // 
            this.labelPlayerPact.AutoSize = true;
            this.labelPlayerPact.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPlayerPact.Location = new System.Drawing.Point(178, 76);
            this.labelPlayerPact.Name = "labelPlayerPact";
            this.labelPlayerPact.Size = new System.Drawing.Size(178, 31);
            this.labelPlayerPact.TabIndex = 3;
            this.labelPlayerPact.Text = "<PlayerPact>";
            // 
            // labelPlayerFaction
            // 
            this.labelPlayerFaction.AutoSize = true;
            this.labelPlayerFaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPlayerFaction.Location = new System.Drawing.Point(178, 118);
            this.labelPlayerFaction.Name = "labelPlayerFaction";
            this.labelPlayerFaction.Size = new System.Drawing.Size(213, 31);
            this.labelPlayerFaction.TabIndex = 5;
            this.labelPlayerFaction.Text = "<PlayerFaction>";
            // 
            // labelPlayerPaths
            // 
            this.labelPlayerPaths.AutoSize = true;
            this.labelPlayerPaths.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8806F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPlayerPaths.Location = new System.Drawing.Point(177, 307);
            this.labelPlayerPaths.Name = "labelPlayerPaths";
            this.labelPlayerPaths.Size = new System.Drawing.Size(269, 44);
            this.labelPlayerPaths.TabIndex = 10;
            this.labelPlayerPaths.Text = "<PlayerPaths>";
            // 
            // textBoxSetName
            // 
            this.textBoxSetName.Location = new System.Drawing.Point(579, 56);
            this.textBoxSetName.MaxLength = 20;
            this.textBoxSetName.Name = "textBoxSetName";
            this.textBoxSetName.Size = new System.Drawing.Size(266, 22);
            this.textBoxSetName.TabIndex = 1;
            this.textBoxSetName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSetName_KeyDown);
            // 
            // buttonSetName
            // 
            this.buttonSetName.Location = new System.Drawing.Point(876, 54);
            this.buttonSetName.Name = "buttonSetName";
            this.buttonSetName.Size = new System.Drawing.Size(105, 26);
            this.buttonSetName.TabIndex = 2;
            this.buttonSetName.Text = "Set Name";
            this.buttonSetName.UseVisualStyleBackColor = true;
            this.buttonSetName.Click += new System.EventHandler(this.buttonSetName_Click);
            // 
            // comboBoxPact
            // 
            this.comboBoxPact.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPact.FormattingEnabled = true;
            this.comboBoxPact.Location = new System.Drawing.Point(579, 99);
            this.comboBoxPact.Name = "comboBoxPact";
            this.comboBoxPact.Size = new System.Drawing.Size(266, 24);
            this.comboBoxPact.TabIndex = 3;
            // 
            // buttonSetPathSun
            // 
            this.buttonSetPathSun.Location = new System.Drawing.Point(579, 324);
            this.buttonSetPathSun.Name = "buttonSetPathSun";
            this.buttonSetPathSun.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathSun.TabIndex = 17;
            this.buttonSetPathSun.Text = "Sun";
            this.buttonSetPathSun.UseVisualStyleBackColor = true;
            this.buttonSetPathSun.Click += new System.EventHandler(this.buttonSetPathSun_Click);
            // 
            // buttonSetPathMoon
            // 
            this.buttonSetPathMoon.Location = new System.Drawing.Point(715, 324);
            this.buttonSetPathMoon.Name = "buttonSetPathMoon";
            this.buttonSetPathMoon.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathMoon.TabIndex = 18;
            this.buttonSetPathMoon.Text = "Moon";
            this.buttonSetPathMoon.UseVisualStyleBackColor = true;
            this.buttonSetPathMoon.Click += new System.EventHandler(this.buttonSetPathMoon_Click);
            // 
            // buttonSetPathStars
            // 
            this.buttonSetPathStars.Location = new System.Drawing.Point(579, 361);
            this.buttonSetPathStars.Name = "buttonSetPathStars";
            this.buttonSetPathStars.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathStars.TabIndex = 19;
            this.buttonSetPathStars.Text = "Stars";
            this.buttonSetPathStars.UseVisualStyleBackColor = true;
            this.buttonSetPathStars.Click += new System.EventHandler(this.buttonSetPathStars_Click);
            // 
            // buttonSetPathVoid
            // 
            this.buttonSetPathVoid.Location = new System.Drawing.Point(715, 361);
            this.buttonSetPathVoid.Name = "buttonSetPathVoid";
            this.buttonSetPathVoid.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathVoid.TabIndex = 20;
            this.buttonSetPathVoid.Text = "Void";
            this.buttonSetPathVoid.UseVisualStyleBackColor = true;
            this.buttonSetPathVoid.Click += new System.EventHandler(this.buttonSetPathVoid_Click);
            // 
            // groupBoxPlayerCharacter
            // 
            this.groupBoxPlayerCharacter.Controls.Add(this.listBoxPlayerTraits);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelMasteryValue);
            this.groupBoxPlayerCharacter.Controls.Add(this.listBoxMasteries);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelTraitsPrompt);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelPathsPrompt);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelMasteriesPrompt);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelFactionPrompt);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelPactPrompt);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelNamePrompt);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelPlayerName);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelPlayerPact);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelPlayerFaction);
            this.groupBoxPlayerCharacter.Controls.Add(this.labelPlayerPaths);
            this.groupBoxPlayerCharacter.Location = new System.Drawing.Point(22, 18);
            this.groupBoxPlayerCharacter.Name = "groupBoxPlayerCharacter";
            this.groupBoxPlayerCharacter.Size = new System.Drawing.Size(493, 664);
            this.groupBoxPlayerCharacter.TabIndex = 0;
            this.groupBoxPlayerCharacter.TabStop = false;
            this.groupBoxPlayerCharacter.Text = "Character Details";
            // 
            // listBoxPlayerTraits
            // 
            this.listBoxPlayerTraits.BackColor = System.Drawing.SystemColors.Control;
            this.listBoxPlayerTraits.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBoxPlayerTraits.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxPlayerTraits.FormattingEnabled = true;
            this.listBoxPlayerTraits.ItemHeight = 30;
            this.listBoxPlayerTraits.Location = new System.Drawing.Point(185, 358);
            this.listBoxPlayerTraits.Name = "listBoxPlayerTraits";
            this.listBoxPlayerTraits.Size = new System.Drawing.Size(291, 270);
            this.listBoxPlayerTraits.TabIndex = 15;
            // 
            // labelMasteryValue
            // 
            this.labelMasteryValue.AutoSize = true;
            this.labelMasteryValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMasteryValue.Location = new System.Drawing.Point(15, 193);
            this.labelMasteryValue.Name = "labelMasteryValue";
            this.labelMasteryValue.Size = new System.Drawing.Size(219, 31);
            this.labelMasteryValue.TabIndex = 14;
            this.labelMasteryValue.Text = "<Mastery Value>";
            // 
            // listBoxMasteries
            // 
            this.listBoxMasteries.BackColor = System.Drawing.SystemColors.Control;
            this.listBoxMasteries.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBoxMasteries.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxMasteries.FormattingEnabled = true;
            this.listBoxMasteries.ItemHeight = 30;
            this.listBoxMasteries.Location = new System.Drawing.Point(184, 162);
            this.listBoxMasteries.Name = "listBoxMasteries";
            this.listBoxMasteries.Size = new System.Drawing.Size(291, 150);
            this.listBoxMasteries.TabIndex = 13;
            // 
            // labelTraitsPrompt
            // 
            this.labelTraitsPrompt.AutoSize = true;
            this.labelTraitsPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelTraitsPrompt, 3);
            this.labelTraitsPrompt.Location = new System.Drawing.Point(16, 358);
            this.labelTraitsPrompt.Name = "labelTraitsPrompt";
            this.labelTraitsPrompt.Size = new System.Drawing.Size(91, 31);
            this.labelTraitsPrompt.TabIndex = 12;
            this.labelTraitsPrompt.Text = "Traits:";
            // 
            // labelPathsPrompt
            // 
            this.labelPathsPrompt.AutoSize = true;
            this.labelPathsPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPathsPrompt.Location = new System.Drawing.Point(15, 315);
            this.labelPathsPrompt.Name = "labelPathsPrompt";
            this.labelPathsPrompt.Size = new System.Drawing.Size(92, 31);
            this.labelPathsPrompt.TabIndex = 9;
            this.labelPathsPrompt.Text = "Paths:";
            // 
            // labelMasteriesPrompt
            // 
            this.labelMasteriesPrompt.AutoSize = true;
            this.labelMasteriesPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorProvider.SetIconPadding(this.labelMasteriesPrompt, 3);
            this.labelMasteriesPrompt.Location = new System.Drawing.Point(15, 162);
            this.labelMasteriesPrompt.Name = "labelMasteriesPrompt";
            this.labelMasteriesPrompt.Size = new System.Drawing.Size(140, 31);
            this.labelMasteriesPrompt.TabIndex = 6;
            this.labelMasteriesPrompt.Text = "Masteries:";
            // 
            // labelFactionPrompt
            // 
            this.labelFactionPrompt.AutoSize = true;
            this.labelFactionPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFactionPrompt.Location = new System.Drawing.Point(15, 119);
            this.labelFactionPrompt.Name = "labelFactionPrompt";
            this.labelFactionPrompt.Size = new System.Drawing.Size(112, 31);
            this.labelFactionPrompt.TabIndex = 4;
            this.labelFactionPrompt.Text = "Faction:";
            // 
            // labelPactPrompt
            // 
            this.labelPactPrompt.AutoSize = true;
            this.labelPactPrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPactPrompt.Location = new System.Drawing.Point(15, 76);
            this.labelPactPrompt.Name = "labelPactPrompt";
            this.labelPactPrompt.Size = new System.Drawing.Size(77, 31);
            this.labelPactPrompt.TabIndex = 2;
            this.labelPactPrompt.Text = "Pact:";
            // 
            // labelNamePrompt
            // 
            this.labelNamePrompt.AutoSize = true;
            this.labelNamePrompt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.97015F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNamePrompt.Location = new System.Drawing.Point(15, 32);
            this.labelNamePrompt.Name = "labelNamePrompt";
            this.labelNamePrompt.Size = new System.Drawing.Size(94, 31);
            this.labelNamePrompt.TabIndex = 0;
            this.labelNamePrompt.Text = "Name:";
            // 
            // buttonSetPact
            // 
            this.buttonSetPact.Location = new System.Drawing.Point(876, 99);
            this.buttonSetPact.Name = "buttonSetPact";
            this.buttonSetPact.Size = new System.Drawing.Size(105, 26);
            this.buttonSetPact.TabIndex = 4;
            this.buttonSetPact.Text = "Set Pact";
            this.buttonSetPact.UseVisualStyleBackColor = true;
            this.buttonSetPact.Click += new System.EventHandler(this.buttonSetPact_Click);
            // 
            // comboBoxFaction
            // 
            this.comboBoxFaction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFaction.FormattingEnabled = true;
            this.comboBoxFaction.Location = new System.Drawing.Point(579, 142);
            this.comboBoxFaction.Name = "comboBoxFaction";
            this.comboBoxFaction.Size = new System.Drawing.Size(266, 24);
            this.comboBoxFaction.TabIndex = 5;
            // 
            // buttonSetFaction
            // 
            this.buttonSetFaction.Location = new System.Drawing.Point(876, 142);
            this.buttonSetFaction.Name = "buttonSetFaction";
            this.buttonSetFaction.Size = new System.Drawing.Size(105, 26);
            this.buttonSetFaction.TabIndex = 6;
            this.buttonSetFaction.Text = "Set Faction";
            this.buttonSetFaction.UseVisualStyleBackColor = true;
            this.buttonSetFaction.Click += new System.EventHandler(this.buttonSetFaction_Click);
            // 
            // checkBoxIsJoyfulMaiden
            // 
            this.checkBoxIsJoyfulMaiden.AutoSize = true;
            this.checkBoxIsJoyfulMaiden.Location = new System.Drawing.Point(1006, 146);
            this.checkBoxIsJoyfulMaiden.Name = "checkBoxIsJoyfulMaiden";
            this.checkBoxIsJoyfulMaiden.Size = new System.Drawing.Size(113, 20);
            this.checkBoxIsJoyfulMaiden.TabIndex = 7;
            this.checkBoxIsJoyfulMaiden.Text = "Joyful Maiden";
            this.checkBoxIsJoyfulMaiden.UseVisualStyleBackColor = true;
            // 
            // buttonSecondPath
            // 
            this.buttonSecondPath.Location = new System.Drawing.Point(876, 323);
            this.buttonSecondPath.Name = "buttonSecondPath";
            this.buttonSecondPath.Size = new System.Drawing.Size(130, 31);
            this.buttonSecondPath.TabIndex = 25;
            this.buttonSecondPath.Text = "Second Path";
            this.buttonSecondPath.UseVisualStyleBackColor = true;
            this.buttonSecondPath.Click += new System.EventHandler(this.buttonAddPath_Click);
            // 
            // buttonResetPaths
            // 
            this.buttonResetPaths.Location = new System.Drawing.Point(876, 435);
            this.buttonResetPaths.Name = "buttonResetPaths";
            this.buttonResetPaths.Size = new System.Drawing.Size(130, 31);
            this.buttonResetPaths.TabIndex = 26;
            this.buttonResetPaths.Text = "Reset Paths";
            this.buttonResetPaths.UseVisualStyleBackColor = true;
            this.buttonResetPaths.Click += new System.EventHandler(this.buttonResetPaths_Click);
            // 
            // buttonAddEarth
            // 
            this.buttonAddEarth.Location = new System.Drawing.Point(579, 192);
            this.buttonAddEarth.Name = "buttonAddEarth";
            this.buttonAddEarth.Size = new System.Drawing.Size(130, 31);
            this.buttonAddEarth.TabIndex = 8;
            this.buttonAddEarth.Text = "Earth";
            this.buttonAddEarth.UseVisualStyleBackColor = true;
            this.buttonAddEarth.Click += new System.EventHandler(this.buttonAddEarth_Click);
            // 
            // buttonAddAir
            // 
            this.buttonAddAir.Location = new System.Drawing.Point(715, 192);
            this.buttonAddAir.Name = "buttonAddAir";
            this.buttonAddAir.Size = new System.Drawing.Size(130, 31);
            this.buttonAddAir.TabIndex = 9;
            this.buttonAddAir.Text = "Air";
            this.buttonAddAir.UseVisualStyleBackColor = true;
            this.buttonAddAir.Click += new System.EventHandler(this.buttonAddAir_Click);
            // 
            // buttonAddFire
            // 
            this.buttonAddFire.Location = new System.Drawing.Point(579, 229);
            this.buttonAddFire.Name = "buttonAddFire";
            this.buttonAddFire.Size = new System.Drawing.Size(130, 31);
            this.buttonAddFire.TabIndex = 10;
            this.buttonAddFire.Text = "Fire";
            this.buttonAddFire.UseVisualStyleBackColor = true;
            this.buttonAddFire.Click += new System.EventHandler(this.buttonAddFire_Click);
            // 
            // buttonAddWater
            // 
            this.buttonAddWater.Location = new System.Drawing.Point(715, 229);
            this.buttonAddWater.Name = "buttonAddWater";
            this.buttonAddWater.Size = new System.Drawing.Size(130, 31);
            this.buttonAddWater.TabIndex = 11;
            this.buttonAddWater.Text = "Water";
            this.buttonAddWater.UseVisualStyleBackColor = true;
            this.buttonAddWater.Click += new System.EventHandler(this.buttonAddWater_Click);
            // 
            // buttonAddCelestial
            // 
            this.buttonAddCelestial.Location = new System.Drawing.Point(579, 266);
            this.buttonAddCelestial.Name = "buttonAddCelestial";
            this.buttonAddCelestial.Size = new System.Drawing.Size(130, 31);
            this.buttonAddCelestial.TabIndex = 12;
            this.buttonAddCelestial.Text = "Celestial";
            this.buttonAddCelestial.UseVisualStyleBackColor = true;
            this.buttonAddCelestial.Click += new System.EventHandler(this.buttonAddCelestial_Click);
            // 
            // buttonAddShadow
            // 
            this.buttonAddShadow.Location = new System.Drawing.Point(715, 266);
            this.buttonAddShadow.Name = "buttonAddShadow";
            this.buttonAddShadow.Size = new System.Drawing.Size(130, 31);
            this.buttonAddShadow.TabIndex = 13;
            this.buttonAddShadow.Text = "Shadow";
            this.buttonAddShadow.UseVisualStyleBackColor = true;
            this.buttonAddShadow.Click += new System.EventHandler(this.buttonAddShadow_Click);
            // 
            // buttonAddProdigy
            // 
            this.buttonAddProdigy.Location = new System.Drawing.Point(876, 229);
            this.buttonAddProdigy.Name = "buttonAddProdigy";
            this.buttonAddProdigy.Size = new System.Drawing.Size(130, 31);
            this.buttonAddProdigy.TabIndex = 15;
            this.buttonAddProdigy.Text = "Arcane Prodigy";
            this.buttonAddProdigy.UseVisualStyleBackColor = true;
            this.buttonAddProdigy.Click += new System.EventHandler(this.buttonAddProdigy_Click);
            // 
            // buttonAddTalent
            // 
            this.buttonAddTalent.Location = new System.Drawing.Point(876, 192);
            this.buttonAddTalent.Name = "buttonAddTalent";
            this.buttonAddTalent.Size = new System.Drawing.Size(130, 31);
            this.buttonAddTalent.TabIndex = 14;
            this.buttonAddTalent.Text = "Arcane Talent";
            this.buttonAddTalent.UseVisualStyleBackColor = true;
            this.buttonAddTalent.Click += new System.EventHandler(this.buttonAddTalent_Click);
            // 
            // buttonResetMasteries
            // 
            this.buttonResetMasteries.Location = new System.Drawing.Point(876, 266);
            this.buttonResetMasteries.Name = "buttonResetMasteries";
            this.buttonResetMasteries.Size = new System.Drawing.Size(130, 31);
            this.buttonResetMasteries.TabIndex = 16;
            this.buttonResetMasteries.Text = "Reset Masteries";
            this.buttonResetMasteries.UseVisualStyleBackColor = true;
            this.buttonResetMasteries.Click += new System.EventHandler(this.buttonResetMasteries_Click);
            // 
            // buttonResetAll
            // 
            this.buttonResetAll.Location = new System.Drawing.Point(876, 651);
            this.buttonResetAll.Name = "buttonResetAll";
            this.buttonResetAll.Size = new System.Drawing.Size(130, 31);
            this.buttonResetAll.TabIndex = 34;
            this.buttonResetAll.Text = "Reset All";
            this.buttonResetAll.UseVisualStyleBackColor = true;
            this.buttonResetAll.Click += new System.EventHandler(this.buttonResetAll_Click);
            // 
            // listBoxAvailableTraits
            // 
            this.listBoxAvailableTraits.FormattingEnabled = true;
            this.listBoxAvailableTraits.ItemHeight = 16;
            this.listBoxAvailableTraits.Location = new System.Drawing.Point(579, 487);
            this.listBoxAvailableTraits.Name = "listBoxAvailableTraits";
            this.listBoxAvailableTraits.Size = new System.Drawing.Size(266, 148);
            this.listBoxAvailableTraits.TabIndex = 27;
            // 
            // buttonAddTrait
            // 
            this.buttonAddTrait.Location = new System.Drawing.Point(876, 487);
            this.buttonAddTrait.Name = "buttonAddTrait";
            this.buttonAddTrait.Size = new System.Drawing.Size(130, 31);
            this.buttonAddTrait.TabIndex = 28;
            this.buttonAddTrait.Text = "Add Trait";
            this.buttonAddTrait.UseVisualStyleBackColor = true;
            this.buttonAddTrait.Click += new System.EventHandler(this.buttonAddTrait_Click);
            // 
            // buttonRemoveTrait
            // 
            this.buttonRemoveTrait.Location = new System.Drawing.Point(876, 524);
            this.buttonRemoveTrait.Name = "buttonRemoveTrait";
            this.buttonRemoveTrait.Size = new System.Drawing.Size(130, 31);
            this.buttonRemoveTrait.TabIndex = 29;
            this.buttonRemoveTrait.Text = "Remove Trait";
            this.buttonRemoveTrait.UseVisualStyleBackColor = true;
            this.buttonRemoveTrait.Click += new System.EventHandler(this.buttonRemoveTrait_Click);
            // 
            // buttonResetTraits
            // 
            this.buttonResetTraits.Location = new System.Drawing.Point(876, 604);
            this.buttonResetTraits.Name = "buttonResetTraits";
            this.buttonResetTraits.Size = new System.Drawing.Size(130, 31);
            this.buttonResetTraits.TabIndex = 30;
            this.buttonResetTraits.Text = "Reset Traits";
            this.buttonResetTraits.UseVisualStyleBackColor = true;
            this.buttonResetTraits.Click += new System.EventHandler(this.buttonResetTraits_Click);
            // 
            // statusStripMain
            // 
            this.statusStripMain.ImageScalingSize = new System.Drawing.Size(22, 22);
            this.statusStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelLeadership,
            this.toolStripStatusLabelAllegiance,
            this.toolStripStatusLabelControl,
            this.toolStripStatusLabelPotential,
            this.toolStripStatusLabelAptitudes});
            this.statusStripMain.Location = new System.Drawing.Point(0, 696);
            this.statusStripMain.Name = "statusStripMain";
            this.statusStripMain.Size = new System.Drawing.Size(1133, 28);
            this.statusStripMain.TabIndex = 34;
            // 
            // toolStripStatusLabelLeadership
            // 
            this.toolStripStatusLabelLeadership.Name = "toolStripStatusLabelLeadership";
            this.toolStripStatusLabelLeadership.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.toolStripStatusLabelLeadership.Size = new System.Drawing.Size(128, 23);
            this.toolStripStatusLabelLeadership.Text = "<Leadership>";
            this.toolStripStatusLabelLeadership.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // toolStripStatusLabelAllegiance
            // 
            this.toolStripStatusLabelAllegiance.Name = "toolStripStatusLabelAllegiance";
            this.toolStripStatusLabelAllegiance.Size = new System.Drawing.Size(112, 23);
            this.toolStripStatusLabelAllegiance.Text = "<Allegiance>";
            this.toolStripStatusLabelAllegiance.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // toolStripStatusLabelControl
            // 
            this.toolStripStatusLabelControl.Name = "toolStripStatusLabelControl";
            this.toolStripStatusLabelControl.Size = new System.Drawing.Size(91, 23);
            this.toolStripStatusLabelControl.Text = "<Control>";
            this.toolStripStatusLabelControl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabelPotential
            // 
            this.toolStripStatusLabelPotential.Name = "toolStripStatusLabelPotential";
            this.toolStripStatusLabelPotential.Size = new System.Drawing.Size(101, 23);
            this.toolStripStatusLabelPotential.Text = "<Potential>";
            this.toolStripStatusLabelPotential.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabelAptitudes
            // 
            this.toolStripStatusLabelAptitudes.Name = "toolStripStatusLabelAptitudes";
            this.toolStripStatusLabelAptitudes.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.toolStripStatusLabelAptitudes.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStripStatusLabelAptitudes.Size = new System.Drawing.Size(127, 23);
            this.toolStripStatusLabelAptitudes.Text = "<Aptitudes>";
            this.toolStripStatusLabelAptitudes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // errorProvider
            // 
            this.errorProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider.ContainerControl = this;
            // 
            // radioButtonMight
            // 
            this.radioButtonMight.AutoSize = true;
            this.radioButtonMight.Location = new System.Drawing.Point(577, 656);
            this.radioButtonMight.Name = "radioButtonMight";
            this.radioButtonMight.Size = new System.Drawing.Size(61, 20);
            this.radioButtonMight.TabIndex = 31;
            this.radioButtonMight.TabStop = true;
            this.radioButtonMight.Text = "Might";
            this.radioButtonMight.UseVisualStyleBackColor = true;
            this.radioButtonMight.CheckedChanged += new System.EventHandler(this.radioButtonMight_CheckedChanged);
            // 
            // radioButtonIntrigue
            // 
            this.radioButtonIntrigue.AutoSize = true;
            this.radioButtonIntrigue.Location = new System.Drawing.Point(686, 656);
            this.radioButtonIntrigue.Name = "radioButtonIntrigue";
            this.radioButtonIntrigue.Size = new System.Drawing.Size(72, 20);
            this.radioButtonIntrigue.TabIndex = 32;
            this.radioButtonIntrigue.TabStop = true;
            this.radioButtonIntrigue.Text = "Intrigue";
            this.radioButtonIntrigue.UseVisualStyleBackColor = true;
            this.radioButtonIntrigue.CheckedChanged += new System.EventHandler(this.radioButtonIntrigue_CheckedChanged);
            // 
            // radioButtonLust
            // 
            this.radioButtonLust.AutoSize = true;
            this.radioButtonLust.Location = new System.Drawing.Point(797, 656);
            this.radioButtonLust.Name = "radioButtonLust";
            this.radioButtonLust.Size = new System.Drawing.Size(53, 20);
            this.radioButtonLust.TabIndex = 33;
            this.radioButtonLust.TabStop = true;
            this.radioButtonLust.Text = "Lust";
            this.radioButtonLust.UseVisualStyleBackColor = true;
            this.radioButtonLust.CheckedChanged += new System.EventHandler(this.radioButtonLust_CheckedChanged);
            // 
            // buttonSetPathMany
            // 
            this.buttonSetPathMany.Location = new System.Drawing.Point(715, 435);
            this.buttonSetPathMany.Name = "buttonSetPathMany";
            this.buttonSetPathMany.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathMany.TabIndex = 24;
            this.buttonSetPathMany.Text = "Many";
            this.buttonSetPathMany.UseVisualStyleBackColor = true;
            this.buttonSetPathMany.Click += new System.EventHandler(this.buttonSetPathMany_Click);
            // 
            // buttonSetPathUnveiled
            // 
            this.buttonSetPathUnveiled.Location = new System.Drawing.Point(579, 435);
            this.buttonSetPathUnveiled.Name = "buttonSetPathUnveiled";
            this.buttonSetPathUnveiled.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathUnveiled.TabIndex = 23;
            this.buttonSetPathUnveiled.Text = "Unveiled";
            this.buttonSetPathUnveiled.UseVisualStyleBackColor = true;
            this.buttonSetPathUnveiled.Click += new System.EventHandler(this.buttonSetPathUnveiled_Click);
            // 
            // buttonSetPathBound
            // 
            this.buttonSetPathBound.Location = new System.Drawing.Point(715, 398);
            this.buttonSetPathBound.Name = "buttonSetPathBound";
            this.buttonSetPathBound.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathBound.TabIndex = 22;
            this.buttonSetPathBound.Text = "Bound";
            this.buttonSetPathBound.UseVisualStyleBackColor = true;
            this.buttonSetPathBound.Click += new System.EventHandler(this.buttonSetPathBound_Click);
            // 
            // buttonSetPathLost
            // 
            this.buttonSetPathLost.Location = new System.Drawing.Point(579, 398);
            this.buttonSetPathLost.Name = "buttonSetPathLost";
            this.buttonSetPathLost.Size = new System.Drawing.Size(130, 31);
            this.buttonSetPathLost.TabIndex = 21;
            this.buttonSetPathLost.Text = "Lost";
            this.buttonSetPathLost.UseVisualStyleBackColor = true;
            this.buttonSetPathLost.Click += new System.EventHandler(this.buttonSetPathLost_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1133, 724);
            this.Controls.Add(this.buttonSetPathMany);
            this.Controls.Add(this.buttonSetPathUnveiled);
            this.Controls.Add(this.buttonSetPathBound);
            this.Controls.Add(this.buttonSetPathLost);
            this.Controls.Add(this.radioButtonLust);
            this.Controls.Add(this.radioButtonIntrigue);
            this.Controls.Add(this.radioButtonMight);
            this.Controls.Add(this.statusStripMain);
            this.Controls.Add(this.buttonResetTraits);
            this.Controls.Add(this.buttonRemoveTrait);
            this.Controls.Add(this.buttonAddTrait);
            this.Controls.Add(this.listBoxAvailableTraits);
            this.Controls.Add(this.buttonResetAll);
            this.Controls.Add(this.buttonResetMasteries);
            this.Controls.Add(this.buttonAddTalent);
            this.Controls.Add(this.buttonAddProdigy);
            this.Controls.Add(this.buttonAddShadow);
            this.Controls.Add(this.buttonAddCelestial);
            this.Controls.Add(this.buttonAddWater);
            this.Controls.Add(this.buttonAddFire);
            this.Controls.Add(this.buttonAddAir);
            this.Controls.Add(this.buttonAddEarth);
            this.Controls.Add(this.buttonResetPaths);
            this.Controls.Add(this.buttonSecondPath);
            this.Controls.Add(this.checkBoxIsJoyfulMaiden);
            this.Controls.Add(this.buttonSetFaction);
            this.Controls.Add(this.comboBoxFaction);
            this.Controls.Add(this.buttonSetPact);
            this.Controls.Add(this.groupBoxPlayerCharacter);
            this.Controls.Add(this.buttonSetPathVoid);
            this.Controls.Add(this.buttonSetPathStars);
            this.Controls.Add(this.buttonSetPathMoon);
            this.Controls.Add(this.buttonSetPathSun);
            this.Controls.Add(this.comboBoxPact);
            this.Controls.Add(this.buttonSetName);
            this.Controls.Add(this.textBoxSetName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phoenix Throne Character Generator v0.1.4";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBoxPlayerCharacter.ResumeLayout(false);
            this.groupBoxPlayerCharacter.PerformLayout();
            this.statusStripMain.ResumeLayout(false);
            this.statusStripMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPlayerName;
        private System.Windows.Forms.Label labelPlayerPact;
        private System.Windows.Forms.Label labelPlayerFaction;
        private System.Windows.Forms.Label labelPlayerPaths;
        private System.Windows.Forms.TextBox textBoxSetName;
        private System.Windows.Forms.Button buttonSetName;
        private System.Windows.Forms.ComboBox comboBoxPact;
        private System.Windows.Forms.Button buttonSetPathSun;
        private System.Windows.Forms.Button buttonSetPathMoon;
        private System.Windows.Forms.Button buttonSetPathStars;
        private System.Windows.Forms.Button buttonSetPathVoid;
        private System.Windows.Forms.GroupBox groupBoxPlayerCharacter;
        private System.Windows.Forms.Label labelNamePrompt;
        private System.Windows.Forms.Label labelPactPrompt;
        private System.Windows.Forms.Label labelMasteriesPrompt;
        private System.Windows.Forms.Label labelFactionPrompt;
        private System.Windows.Forms.Button buttonSetPact;
        private System.Windows.Forms.ComboBox comboBoxFaction;
        private System.Windows.Forms.Button buttonSetFaction;
        private System.Windows.Forms.CheckBox checkBoxIsJoyfulMaiden;
        private System.Windows.Forms.Label labelPathsPrompt;
        private System.Windows.Forms.Button buttonSecondPath;
        private System.Windows.Forms.Button buttonResetPaths;
        private System.Windows.Forms.Label labelTraitsPrompt;
        private System.Windows.Forms.ListBox listBoxMasteries;
        private System.Windows.Forms.Button buttonAddEarth;
        private System.Windows.Forms.Button buttonAddAir;
        private System.Windows.Forms.Button buttonAddFire;
        private System.Windows.Forms.Button buttonAddWater;
        private System.Windows.Forms.Button buttonAddCelestial;
        private System.Windows.Forms.Button buttonAddShadow;
        private System.Windows.Forms.Button buttonAddProdigy;
        private System.Windows.Forms.Button buttonAddTalent;
        private System.Windows.Forms.Button buttonResetMasteries;
        private System.Windows.Forms.Label labelMasteryValue;
        private System.Windows.Forms.Button buttonResetAll;
        private System.Windows.Forms.ListBox listBoxPlayerTraits;
        private System.Windows.Forms.ListBox listBoxAvailableTraits;
        private System.Windows.Forms.Button buttonAddTrait;
        private System.Windows.Forms.Button buttonRemoveTrait;
        private System.Windows.Forms.Button buttonResetTraits;
        private System.Windows.Forms.StatusStrip statusStripMain;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelControl;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelAllegiance;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelPotential;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelAptitudes;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.RadioButton radioButtonLust;
        private System.Windows.Forms.RadioButton radioButtonIntrigue;
        private System.Windows.Forms.RadioButton radioButtonMight;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelLeadership;
        private System.Windows.Forms.Button buttonSetPathMany;
        private System.Windows.Forms.Button buttonSetPathUnveiled;
        private System.Windows.Forms.Button buttonSetPathBound;
        private System.Windows.Forms.Button buttonSetPathLost;
    }
}

