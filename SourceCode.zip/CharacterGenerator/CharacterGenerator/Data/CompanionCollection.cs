﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterGenerator.Data
{
    public class CompanionCollection : BindingList<Companion>
    {
        public CompanionCollection() { }

        public CompanionCollection(IEnumerable<Companion> companions)
        {
            foreach (Companion c in companions)
            {
                Add(c);
            }
        }

        private int KeeperSum => this.Sum(x => x.IsKeeper == true ? 1 : 0);
        public bool TooManyKeepers => (PlayerCharacter.IsJoyfulMaiden && KeeperSum == 1) || KeeperSum == 0 ? false : true;

        public int UnalignedRecruitCount => this.Count(x => x.IsUnaligned);
        public int TotalControlCost => this.Sum(x => x.ControlCost);
        public int TotalMightBonus => this.Sum(x => x.MightBonus);
        public int TotalIntrigueBonus => this.Sum(x => x.IntrigueBonus);
        public int TotalLustBonus => this.Sum(x => x.LustBonus);
        public int MinistryLoyalty => this.Sum(x => x.CompanionFaction == Companion.Faction.Ministry ? x.FactionLoyalty : 0);
        public int ChurchLoyalty => this.Sum(x => x.CompanionFaction == Companion.Faction.Church ? x.FactionLoyalty : 0);
        public int GuildLoyalty => this.Sum(x => x.CompanionFaction == Companion.Faction.Guild ? x.FactionLoyalty : 0);
        public int HaremLoyalty => this.Sum(x => x.CompanionFaction == Companion.Faction.Harem ? x.FactionLoyalty : 0);
        public int CultLoyalty => this.Sum(x => x.CompanionFaction == Companion.Faction.Cult ? x.FactionLoyalty : 0);

    }
}
