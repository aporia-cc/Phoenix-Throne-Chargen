﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterGenerator.Data
{
    public class Pact
    {
        //data
        public enum Type
        {
            Domination,
            Inspiration,
            Temptation,
            Retribution,
            Seduction,
            Possession,
            None
        }

        private static readonly int[] DOMINATION_BONUSES =  { 3, 2, 1 };
        private static readonly int[] INSPIRATION_BONUSES = { 2, 3, 1 };
        private static readonly int[] TEMPTATION_BONUSES =  { 2, 1, 3 };
        private static readonly int[] RETRIBUTION_BONUSES = { 3, 1, 2 };
        private static readonly int[] SEDUCTION_BONUSES =   { 1, 3, 2 };
        private static readonly int[] POSSESSION_BONUSES =  { 1, 2, 3 };
        private static readonly int[] NO_BONUS =            { 0, 0, 0 };

        private static readonly List<int[]> PactBonuses
            = new List<int[]> { DOMINATION_BONUSES
                                , INSPIRATION_BONUSES
                                , TEMPTATION_BONUSES
                                , RETRIBUTION_BONUSES
                                , SEDUCTION_BONUSES
                                , POSSESSION_BONUSES
                                , NO_BONUS};

        public Type PactType { get; set; }

        public string PactName 
                => (PactType != Type.None)
                ? "Pact of " + PactType : string.Empty;

        public bool IsLustWitch
                => (PactType == Type.Temptation || PactType == Type.Possession) 
                ? true : false;

        public int Might => PactBonuses[(int)PactType][0];
        public int Intrigue => PactBonuses[(int)PactType][1];
        public int Lust => PactBonuses[(int)PactType][2];

        //constructor
        public Pact()
        {
            PactType = Type.None;
        }

        public Pact(Type pactType)
        {
            PactType = pactType;
        }
    }
}
