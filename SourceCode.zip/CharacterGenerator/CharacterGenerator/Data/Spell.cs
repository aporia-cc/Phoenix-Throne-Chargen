﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PC = CharacterGenerator.Data.PlayerCharacter;

namespace CharacterGenerator
{
    public class Spell
    {
        //data
        public enum SpellElement
        {
            Earth,
            Air,
            Fire,
            Water,
            Celestial,
            Shadow,
            Universal
        }
        
        public string Name { get; set; }
        public SpellElement Element { get; set; }
        public int Mastery { get; set; } // 5 for dividers
        public string Description { get; set; }
        public bool IsLustMagic { get; set; }
        public bool IsKnownToAll { get; set; }

        public string Title
        {
            get
            {
                string mastery = "";
                if (Mastery <= 1 || PC.SignatureSpell != this)
                {
                    mastery = $"{PC.MASTERY_DOTS[Mastery]}";
                }
                else if (PC.SignatureSpell == this)
                {
                    mastery = $"{PC.MASTERY_DOTS[Mastery-1]}";
                }

                string lustMagic = "";
                if (IsLustMagic)
                {
                    lustMagic = ", Lust Magic";
                }

                string title;
                if (!string.IsNullOrEmpty(Name))
                {
                    title = $"{Name}, {mastery} {Element}{lustMagic}";
                }
                else
                {
                    title = "";
                }
                return title;
            }
        }

        //constructors
        public Spell()
        {

        }

        public Spell(string name, SpellElement element, int mastery, string description
                , bool isLustMagic = false)
        {
            Name = name;
            Element = element;
            Mastery = mastery;
            Description = description;
            IsLustMagic = isLustMagic;
        }

        // methods
        public override string ToString()
        {
            if (IsLustMagic)
            {
                return $"{Name} (L)"; 
            }
            else
            {
                return $"{Name}";
            }
        }
    }
}
