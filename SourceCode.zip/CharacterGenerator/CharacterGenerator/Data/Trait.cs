﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterGenerator.Data
{
    public class Trait
    {
        //data
        public string Name { get; set; }
        public int Cost { get; set; }
        public int Bonus { get; set; }
        public int Might { get; set; }
        public int Intrigue { get; set; }
        public int Lust { get; set; }
        public int Any { get; set; }

        public bool IsSilverTongue { get; set; }
        public bool IsTiesThatBind { get; set; }
        public bool IsLustWitch { get; set; }
        public bool IsTalent { get; set; }
        public bool IsProdigy { get; set; }
        public bool IsNovice { get; set; }
        public bool IsRevenant { get; set; }
        public bool IsLover { get; set; }

        //constructors
        public Trait()
        {

        }

        public Trait(string name, int cost, int bonus, int might, int intrigue
                , int lust, int any, bool ties = false, bool tongue = false, bool witch = false, bool talent = false
                , bool prodigy = false, bool revenant = false)
        {
            Name = name;
            Cost = cost;
            Bonus = bonus;
            Might = might;
            Intrigue = intrigue;
            Lust = lust;
            Any = any;
            IsSilverTongue = tongue;
            IsTiesThatBind = ties;
            IsLustWitch = witch;
            IsTalent = talent;
            IsProdigy = prodigy;
            IsRevenant = revenant;
        }

        //methods
        public override string ToString()
        {
            return $"({Cost}) {Name}";
        }
    }
}
