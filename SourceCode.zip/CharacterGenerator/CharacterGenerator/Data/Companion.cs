﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PC = CharacterGenerator.Data.PlayerCharacter;

namespace CharacterGenerator.Data
{
    public class Companion : IComparable<Companion>
    {
        //data

        //radio button automatic booleans
        public bool IsDevotionNone => DevotionLevel == Devotion.None;
        public bool IsDevotionAlly => DevotionLevel == Devotion.Ally;
        public bool IsDevotionLover => DevotionLevel == Devotion.Lover;
        public bool IsDevotionSlave => DevotionLevel == Devotion.Slave;
        
        public bool IsMightUntrained => MightAptitude == Might.Untrained;
        public bool IsMightTrained => MightAptitude == Might.Trained;
        public bool IsMightFocus => MightAptitude == Might.Focus;

        public bool IsIntrigueUntrained => IntrigueAptitude == Intrigue.Untrained;
        public bool IsIntrigueTrained => IntrigueAptitude == Intrigue.Trained;
        public bool IsIntrigueFocus => IntrigueAptitude == Intrigue.Focus;

        public bool IsLustUntrained => LustAptitude == Lust.Untrained;
        public bool IsLustTrained => LustAptitude == Lust.Trained;
        public bool IsLustFocus => LustAptitude == Lust.Focus;


        public enum Faction
        {
            Ministry,
            Church,
            Guild,
            Harem,
            Cult,        //Maiden == bool IsMaiden
            Exiles,
            Unaligned
        }

        public enum Subfaction
        {
            None,
            BurningHeart,
            HouseOfThorns,
            ShiningPath
        }

        public enum Guild
        {
            Venerables = -1,
            None,
            Eternals
        }
        
        public enum Might
        {
            Untrained = -1,
            Trained,
            Focus
        }

        public enum Intrigue
        {
            Untrained = -1,
            Trained,
            Focus
        }

        public enum Lust
        {
            Untrained = -1,
            Trained,
            Focus
        }

        public enum Devotion
        {
            None = int.MinValue,
            Ally = -1,
            Lover,
            Slave
        }

        public enum Magic
        {
            Mundane,
            Novice,
            Sorceress,
            Talent,
            Prodigy
        }

        public const int NOVICE_CONTROL_COST = 3;
        public const int SORCERESS_CONTROL_COST = 4;
        public const int TALENT_CONTROL_COST = 5;
        public const int PRODIGY_CONTROL_COST = 7;
        public const int OPPOSING_ALCHEMIST_DIFF = 2; //difference between PC.Guild and Companion.Guild
        public const int HOSTILE_FACTION_MODIFIER = 1;
        public const int FRIENDLY_FACTION_MODIFIER = -1;
        public const int HOSTILE_GUILD_MODIFIER = -1;
        public const int FRIENDLY_GUILD_MODIFIER = 1;
        public const int RECRUIT_KEEPER_BONUS = -3; //for Joyful Maiden player's keeper
        public const int ENSLAVE_COST = -1;

        public string Title => ToString();
        public string Name { get; set; }
        public string Notes { get; set; }
        public Devotion DevotionLevel { get; set; } //level of recruitment
        public Magic ArcanePower { get; set; } //ability in magic

        public Faction CompanionFaction { get; set; }
        public Subfaction CompanionSubfaction { get; set; }
        public Guild GuildAllegiance { get; set; }
        
        public Might MightAptitude { get; set; }
        public Intrigue IntrigueAptitude { get; set; }
        public Lust LustAptitude { get; set; }

        public int ModifiedControlCost { get; set; }
        public bool IsCostModifiedByPlayer { get; set; }

        public bool IsLustWitch { get; set; }
        public bool IsKeeper { get; set; }      //is the player's keeper
        public bool IsUnaligned { get; set; }   //check for if companion starts unaligned
        public bool IsJoyfulMaiden { get; set; }
        public bool IsTyrantQueen { get; set; }
        public bool IsPlayerCreated { get; set; }

        //Joyful Maidens can always be enslaved for free, but otherwise player will set
        public bool IsDiscountedSlaveManual { get; set; }
        public bool IsLoverWithAllegiance { get; set; }
        public bool IsDivider { get; set; }

        //set automatically
        public bool IsNovice => (ArcanePower == Magic.Mundane || ArcanePower == Magic.Novice)
                             ? true : false;
        public bool IsTalent => ArcanePower == Magic.Talent ? true : false;
        public bool IsProdigy => ArcanePower == Magic.Prodigy ? true : false;
        public bool IsDiscountedSlave => IsJoyfulMaiden ? true : IsDiscountedSlaveManual;
        //Control cost charged to the player
        public int DefaultControlCost => getDefaultControlCost();
        public int ControlCost => IsCostModifiedByPlayer ? ModifiedControlCost : getDefaultControlCost();

        public int MightBonus
        {
            get
            {
                int baseBonus = getDefaultModifier();
                int bonusMod = (int)DevotionLevel + (int)MightAptitude;
                return DevotionLevel == Devotion.None ? 0 : baseBonus + bonusMod;
            }
        }

        public int IntrigueBonus
        {
            get
            {
                int baseBonus = getDefaultModifier();
                int bonusMod = (int)DevotionLevel + (int)IntrigueAptitude;
                return DevotionLevel == Devotion.None ? 0 : baseBonus + bonusMod;
            }
        }

        public int LustBonus
        {
            get
            {
                int baseBonus = getDefaultModifier();
                int bonusMod = (int)DevotionLevel + (int)LustAptitude;
                return DevotionLevel == Devotion.None ? 0 : baseBonus + bonusMod;
            }
        }

        public int FactionLoyalty
        {
            get
            {
                int baseBonus = getDefaultModifier();
                int devotionBonus = (int)DevotionLevel;
                int guildBonus = 0;
                //if PC supports same or opposing guild subfaction as this alchemist
                if (CompanionFaction == Faction.Guild)
                {
                    if ((int)PC.GuildAllegiance - (int)GuildAllegiance == 0)
                    {
                        guildBonus = FRIENDLY_GUILD_MODIFIER;
                    }
                    else if (Math.Abs((int)PC.GuildAllegiance - (int)GuildAllegiance)
                            == OPPOSING_ALCHEMIST_DIFF)
                    {
                        guildBonus = HOSTILE_GUILD_MODIFIER;
                    }
                }
                return DevotionLevel == Devotion.None 
                        ? 0 : baseBonus + guildBonus + devotionBonus;
            }
        }

        //constructors
        public Companion()
        {
            IsDivider = true;
            DevotionLevel = Devotion.None;
            MightAptitude = Might.Untrained;
            IntrigueAptitude = Intrigue.Untrained;
            LustAptitude = Lust.Untrained;
            CompanionFaction = Faction.Unaligned;
        }

        public Companion(string name, Faction faction) : this()
        {
            Name = name;
            CompanionFaction = faction;
        }

        public Companion(string name, Devotion devotionLevel, Magic arcanePower
                , Faction companionFaction
                , Subfaction companionSubfaction
                , Guild guildAllegiance

                , Might mightAptitude = Might.Untrained
                , Intrigue intrigueAptitude = Intrigue.Untrained
                , Lust lustAptitude = Lust.Untrained
                , string notes = ""
                , int modifiedControlCost = 0, bool isCostModifiedByPlayer = false
                , bool isLustWitch = false, bool isUnaligned = false, bool isJoyfulMaiden = false
                , bool isTyrantQueen = false, bool isPlayerCreated = false
                , bool isLoverWithAllegiance = false, bool isDiscountedSlaveManual = false)
        {
            //automatic
            IsDivider = false;

            //mandatory
            Name = name;
            DevotionLevel = devotionLevel; //level of recruitment
            ArcanePower = arcanePower;     //level of magical ability
            CompanionFaction = companionFaction;
            CompanionSubfaction = companionSubfaction;
            GuildAllegiance = guildAllegiance;
            MightAptitude = mightAptitude;
            IntrigueAptitude = intrigueAptitude;
            LustAptitude = lustAptitude;

            //optional
            Notes = notes;
            ModifiedControlCost = modifiedControlCost;
            IsCostModifiedByPlayer = isCostModifiedByPlayer;
            IsLustWitch = isLustWitch;
            IsUnaligned = isUnaligned;
            IsJoyfulMaiden = isJoyfulMaiden;
            IsPlayerCreated = IsPlayerCreated;

            IsLoverWithAllegiance = isLoverWithAllegiance;
            IsDiscountedSlaveManual = isDiscountedSlaveManual;
        }

        //methods
        private int calculateRecruitmentModifier()
        {
            int controlMod = 0;
            if (PC.IsJoyfulMaiden && PC.Keeper == this)
            {
                controlMod = RECRUIT_KEEPER_BONUS;
            }
            else if (PC.IsJoyfulMaiden || PC.PlayerFaction == null)
            {
                controlMod = 0;
            }
            else if ((int)PC.PlayerFaction == (int)CompanionFaction)
            {
                controlMod = FRIENDLY_FACTION_MODIFIER;
            }
            else if ((PC.PlayerFaction == PC.Faction.Ministry && CompanionFaction == Faction.Church)
                    || (PC.PlayerFaction == PC.Faction.Church && CompanionFaction == Faction.Ministry)
                    || (PC.PlayerFaction == PC.Faction.Harem && CompanionFaction == Faction.Cult)
                    || (PC.PlayerFaction == PC.Faction.Cult && CompanionFaction == Faction.Harem)
                    || (PC.PlayerFaction == PC.Faction.Guild && IsJoyfulMaiden)
                    || (PC.PlayerFaction == PC.Faction.Exiles && CompanionFaction != Faction.Exiles 
                            && (IsTalent || IsProdigy)))
            {
                controlMod = HOSTILE_FACTION_MODIFIER;
            }
            return controlMod;
        }

        //base modifier used in Control, might/intrigue/lust, loyalty calculations
        private int getDefaultModifier()
        {
            int modifier;
            switch (ArcanePower)
            {
                case Magic.Mundane:
                    modifier = NOVICE_CONTROL_COST;
                    break;
                case Magic.Novice:
                    modifier = NOVICE_CONTROL_COST;
                    break;
                case Magic.Sorceress:
                    modifier = SORCERESS_CONTROL_COST;
                    break;
                case Magic.Talent:
                    modifier = TALENT_CONTROL_COST;
                    break;
                case Magic.Prodigy:
                    modifier = PRODIGY_CONTROL_COST;
                    break;
                default:
                    modifier = 0;
                    break;
            }
            return modifier;
        }
        
        private int getDefaultControlCost()
        {
            int baseCost = getDefaultModifier();
            int recruitMod = calculateRecruitmentModifier();
            int slaveMod = 0;
            if (DevotionLevel == Devotion.Slave && !IsDiscountedSlave)
            {
                slaveMod = ENSLAVE_COST;
            }
            return DevotionLevel == Devotion.None 
                ? 0 : baseCost + recruitMod + slaveMod;
        }

        private string getFullFactionName()
        {
            string faction = "";
            string subfaction = "";
            switch (CompanionFaction)
            {
                case Faction.Ministry:
                    faction = "Ministry of Harmony";
                    break;
                case Faction.Church:
                    faction = "Church of the Sun";
                    break;
                case Faction.Guild:
                    { if (GuildAllegiance==Guild.None) faction = "Alchemist Guild";
                        else if (GuildAllegiance == Guild.Venerables) faction = "Venerable Alchemist";
                        else if (GuildAllegiance == Guild.Eternals) faction = "Eternal Alchemist"; }
                    break;
                case Faction.Harem:
                    faction = "Imperial Harem";
                    break;
                case Faction.Cult:
                    faction = "Cult of Pleasure";
                    break;
                case Faction.Exiles:
                    faction = "First Exiles";
                    break;
                case Faction.Unaligned:
                    faction = "Unaligned";
                    break;
                default:
                    faction = "";
                    break;
            }

            //override faction if...
            if (IsJoyfulMaiden && IsTyrantQueen)
            {
                faction = $"Tethered Queen ({CompanionFaction})";
            }
            else if (IsJoyfulMaiden)
            {
                faction = $"Joyful Maiden ({CompanionFaction})";
            }
            else if (IsTyrantQueen)
            {
                faction = $"Tyrant Queen ({CompanionFaction})";
            }

            switch (CompanionSubfaction)
            {
                case Subfaction.BurningHeart:
                    subfaction = "(Burning Heart) ";
                    break;
                case Subfaction.HouseOfThorns:
                    subfaction = "(House of Thorns) ";
                    break;
                case Subfaction.ShiningPath:
                    subfaction = "(Shining Path) ";
                    break;
                default:
                    subfaction = "";
                    break;
            }
            return $"{subfaction}{faction}";
        }

        public override string ToString()
        {
            string devotion = DevotionLevel == Devotion.None ? "": DevotionLevel.ToString();

            if (IsDivider)
            {
                return Name;
            }
            else
            {
                return $"{Name}, {getFullFactionName()} {ArcanePower} {devotion}";
            }
        }

        public int CompareTo(Companion other)
        {
            int result = CompanionFaction.CompareTo(other.CompanionFaction);
            if (result == 0)
            {
                result = Name.CompareTo(other.Name);
            }
            return result;
        }
    }
}
