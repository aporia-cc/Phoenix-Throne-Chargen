﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterGenerator.Data
{
    public class TraitCollection : BindingList<Trait>
    {
        //data
        public int CostTotal
        {
            get
            {
                int total = 0;
                foreach (Trait trait in this)
                {
                    total += trait.Cost;
                }
                return total;
            }
        }

        public int BonusTotal
        {
            get
            {
                int total = 0;
                foreach (Trait trait in this)
                {
                    total += trait.Bonus;
                }
                return total;
            }
        }


        public int MightTotal
        {
            get
            {
                int total = 0;
                foreach (Trait trait in this)
                {
                    total += trait.Might;
                }
                return total;
            }
        }

        public int IntrigueTotal
        {
            get
            {
                int total = 0;
                foreach (Trait trait in this)
                {
                    total += trait.Intrigue;
                }
                return total;
            }
        }

        public int LustTotal
        {
            get
            {
                int total = 0;
                foreach (Trait trait in this)
                {
                    total += trait.Lust;
                }
                return total;
            }
        }

        public int AnyTotal
        {
            get
            {
                int total = 0;
                foreach (Trait trait in this)
                {
                    total += trait.Any;
                }
                return total;
            }
        }

        public bool IsLustWitch
        {
            get
            {
                bool witch = false;
                foreach (Trait trait in this)
                {
                    if (trait.IsLustWitch == true)
                    {
                        witch = trait.IsLustWitch;
                    }
                }
                return witch;
            }
        }

        public bool IsTalent
        {
            get
            {
                bool talent = false;
                foreach (Trait trait in this)
                {
                    if (trait.IsTalent == true)
                    {
                        talent = trait.IsTalent;
                    }
                }
                return talent;
            }
        }

        public bool IsProdigy
        {
            get
            {
                bool prodigy = false;
                foreach (Trait trait in this)
                {
                    if (trait.IsProdigy == true)
                    {
                        prodigy = trait.IsProdigy;
                    }
                }
                return prodigy;
            }
        }

        public bool IsNovice
        {
            get
            {
                bool novice = false;
                foreach (Trait trait in this)
                {
                    if (trait.IsNovice == true)
                    {
                        novice = trait.IsNovice;
                    }
                }
                return novice;
            }
        }

        public bool IsRevenant
        {
            get
            {
                bool revenant = false;
                foreach (Trait trait in this)
                {
                    if (trait.IsRevenant == true)
                    {
                        revenant = trait.IsRevenant;
                    }
                }
                return revenant;
            }
        }

        public bool IsLover
        {
            get
            {
                bool lover = false;
                foreach (Trait trait in this)
                {
                    if (trait.IsLover == true)
                    {
                        lover = trait.IsLover;
                    }
                }
                return lover;
            }
        }
    }
}
