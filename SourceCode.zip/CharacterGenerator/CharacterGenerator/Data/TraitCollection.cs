﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterGenerator.Data
{
    public class TraitCollection : BindingList<Trait>
    {
        //data
        public int CostTotal => this.Sum(x => x.Cost);
        public int BonusTotal => this.Sum(x => x.Bonus);
        public int MightTotal => this.Sum(x => x.Might);
        public int IntrigueTotal => this.Sum(x => x.Intrigue);
        public int LustTotal => this.Sum(x => x.Lust);
        public int AnyTotal => this.Sum(x => x.Any);
        public bool IsSilverTongue => this.Any(x => x.IsSilverTongue);
        public bool IsTiesThatBind => this.Any(x => x.IsTiesThatBind);
        public bool IsLustWitch => this.Any(x => x.IsLustWitch);
        public bool IsTalent => this.Any(x => x.IsTalent);
        public bool IsProdigy => this.Any(x => x.IsProdigy);
        public bool IsNovice => this.Any(x => x.IsNovice);
        public bool IsRevenant => this.Any(x => x.IsRevenant);
        public bool IsLover => this.Any(x => x.IsLover);

        //non lambda logic
        //public int CostTotal
        //{
        //    get
        //    {
        //        int total = 0;
        //        foreach (Trait trait in this)
        //        {
        //            total += trait.Cost;
        //        }
        //        return total;
        //    }
        //}

    }
}
