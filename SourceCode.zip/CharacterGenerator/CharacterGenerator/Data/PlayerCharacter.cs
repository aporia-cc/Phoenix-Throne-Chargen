﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterGenerator.Data
{
    public static class PlayerCharacter
    {
        // data
        public enum Faction
        {
            Ministry,
            Church,
            Guild,
            Harem,
            Cult        // Maiden == bool IsMaiden
        }

        public enum Subfaction
        {
            Eternals,
            Venerables
        }

        public enum Path
        {
            Sun,
            Moon,
            Stars,
            Void,
            Lost,
            Bound,
            Unveiled,
            Many
        }

        public static readonly char[] PATH_CHARS = { '☼', '☽', '✶', '⌽', '⨳' , '☋', '⚶', '❖' };
        public static readonly string[] MASTERY_DOTS = { "◆", "◆", "◆◆", "◆◆◆", "◆◆◆◆", "" };

        public const int STARTING_ALLEGIANCE = 20;
        public const int STARTING_CONTROL = 10;
        public const int STARTING_POTENTIAL = 5;
        public const int STARTING_MASTERY_LEVELS = 3;

        public const int DOMINATION_CONTROL_BONUS = 4;
        public const int INSPIRATION_POTENTIAL_BONUS = 2;
        public const int INSPIRATION_POTENTIAL_BONUS_ALLIES = 5;
        public const int CORRUPTION_POTENTIAL_BONUS_TALENT = 3;
        public const int CORRUPTION_POTENTIAL_BONUS_PRODIGY = 5;
        public const int RETRIBUTION_CONTROL_BONUS = 4;
        public const int POSSESSION_POTENTIAL_BONUS_TIES = 2;
        public const int INVALID_SPELL_MASTERY = 5;
        
        public const int MAX_NEGATIVE_TRAIT_BONUS = 3;

        public const int LOYALTY_PLEDGE_BONUS = 2;

        public const int NOVICE_RANK = 1;
        public const int ADEPT_RANK = 2;
        public const int SCHOLAR_RANK = 3;
        public const int PRODIGY_RANK = 4;

        public static string PlayerName { get; set; }
        public static int Allegiance { get; set; }
        public static int AllegianceOld { get; set; }
        public static int Control { get; set; }
        public static int Potential { get; set; }
        public static int PotentialBonusForAllies
                => PlayerPact.PactType == Pact.Type.Inspiration
                ? INSPIRATION_POTENTIAL_BONUS_ALLIES : 0;
        public static int MasteryLevels { get; set; }

        public static Pact PlayerPact { get; set; }
        public static Faction? PlayerFaction { get; set; }
        public static Subfaction? PlayerSubfaction { get; set; }
        public static Path? PathOfPleasure { get; set; }
        public static Path? PathOfPleasure2 { get; set; }

        public static int EarthMastery { get; set; }
        public static int AirMastery { get; set; }
        public static int FireMastery { get; set; }
        public static int WaterMastery { get; set; }
        public static int CelestialMastery { get; set; }
        public static int ShadowMastery { get; set; }
        public static int TotalMastery => EarthMastery + AirMastery + FireMastery
                + WaterMastery + CelestialMastery + ShadowMastery;
        public static int HighestMastery => new int[]{ EarthMastery, AirMastery
                , FireMastery, WaterMastery, CelestialMastery, ShadowMastery }.Max();

        public static bool IsLustWitch => PlayerPact.IsLustWitch || PlayerTraits.IsLustWitch 
                || PlayerFaction == Faction.Cult;
        public static bool IsJoyfulMaiden { get; set; }

        //set by MainForm what is this nonsense ಠ_ಠ
        public static bool IsTalent { get; set; }
        public static bool IsProdigy { get; set; }
        public static bool IsNovice { get; set; }
        //public static bool IsTalent => PlayerTraits.IsTalent;
        //public static bool IsProdigy => PlayerTraits.IsProdigy;
        //public static bool IsNovice => PlayerTraits.IsNovice;

        public static bool IsLover => PlayerTraits.IsLover;
        public static bool IsRevenant => PlayerTraits.IsRevenant;

        public static int MightTotal => PlayerPact.Might + PlayerTraits.MightTotal;
        public static int IntrigueTotal => PlayerPact.Intrigue + PlayerTraits.IntrigueTotal;
        public static int LustTotal => PlayerPact.Lust + PlayerTraits.LustTotal;
        public static int AnyTotal => PlayerTraits.AnyTotal;
        public static int BonusTotal => PlayerTraits.BonusTotal;

        public static int LoyaltyMinistry { get; set; }
        public static int LoyaltyChurch { get; set; }
        public static int LoyaltyHarem { get; set; }
        public static int LoyaltyGuild { get; set; }
        public static int LoyaltyCult { get; set; }

        public static int UnalignedRecruitCount { get; set; }

        public static TraitCollection PlayerTraits { get; set; }
        public static TraitCollection TraitList => DataGenerator.CreateTraitList();

        public static Spell SignatureSpell { get; set; }
        public static SpellCollection PlayerSpells { get; set; }
        public static SpellCollection SpellList => DataGenerator.CreateSpellList();
        
        // constructors
        static PlayerCharacter()
        {
            Allegiance = STARTING_ALLEGIANCE;
            Control = STARTING_CONTROL;
            Potential = STARTING_POTENTIAL;
            MasteryLevels = STARTING_MASTERY_LEVELS;
            PlayerPact = new Pact();
            PlayerTraits = new TraitCollection();
            PlayerSpells = new SpellCollection();
            SignatureSpell = new Spell();
            foreach (Spell spell in SpellList)
            {
                if (spell.IsKnownToAll)
                {
                    PlayerSpells.Add(spell);
                }
            }
        }

        public static void ApplyPactBonus(Pact playerPact)
        {
            switch (playerPact.PactType)
            {
                case Pact.Type.Domination:
                    Control += DOMINATION_CONTROL_BONUS;
                    break;
                case Pact.Type.Inspiration:
                    Potential += INSPIRATION_POTENTIAL_BONUS;
                    break;
                case Pact.Type.Retribution:
                    Control += RETRIBUTION_CONTROL_BONUS;
                    break;
                case Pact.Type.Seduction:
                    AllegianceOld = Allegiance;
                    Control += Allegiance;
                    Allegiance = 0;
                    break;
                default:
                    break;
            }
        }

        public static void RemovePactBonus(Pact playerPact)
        {
            switch (playerPact.PactType)
            {
                case Pact.Type.Domination:
                    Control -= DOMINATION_CONTROL_BONUS;
                    break;
                case Pact.Type.Inspiration:
                    Potential -= INSPIRATION_POTENTIAL_BONUS;
                    break;
                case Pact.Type.Retribution:
                    Control -= RETRIBUTION_CONTROL_BONUS;
                    break;
                case Pact.Type.Seduction:
                    Control -= AllegianceOld;
                    Allegiance = AllegianceOld;
                    AllegianceOld = 0;
                    break;
                default:
                    break;
            }
        }

        public static void ApplySubfactionBonuses(Subfaction playerSubfaction)
        {
            PlayerSubfaction = playerSubfaction;
            LoyaltyGuild += LOYALTY_PLEDGE_BONUS;
        }

        public static void RemoveSubfactionBonuses(Subfaction playerSubfaction)
        {
            PlayerSubfaction = playerSubfaction;
            LoyaltyGuild -= LOYALTY_PLEDGE_BONUS;
        }

        public static void SetMasteriesForProdigy(string element)
        {
            MasteryLevels = 0;
            EarthMastery = 0;
            AirMastery = 0;
            FireMastery = 0;
            WaterMastery = 0;
            CelestialMastery = 0;
            ShadowMastery = 0;

            switch (element)
            {
                case "Earth":
                    EarthMastery = PRODIGY_RANK;
                    break;
                case "Air":
                    AirMastery = PRODIGY_RANK;
                    break;
                case "Fire":
                    FireMastery = PRODIGY_RANK;
                    break;
                case "Water":
                    WaterMastery = PRODIGY_RANK;
                    break;
                case "Celestial":
                    CelestialMastery = PRODIGY_RANK;
                    break;
                case "Shadow":
                    ShadowMastery = PRODIGY_RANK;
                    break;
                default:
                    break;
            }
        }

        public static void ApplyTraitBonus(Trait trait)
        {
            if(trait == null)
            {
                return;
            }
            switch (trait.Name)
            {
                case "Silver Tongue":
                    Allegiance += 1;
                    break;
                case "Spell Addled":
                    Allegiance -= 1;
                    break;
                case "Lavish Excess":
                    Control -= 1;
                    break;
                case "Undying Thirst":
                    Allegiance -= 2;
                    break;
                default:
                    break;
            }
        }

        public static void RemoveTraitBonus(Trait trait)
        {
            switch (trait.Name)
            {
                case "Silver Tongue":
                    Allegiance -= 1;
                    break;
                case "Spell Addled":
                    Allegiance += 1;
                    break;
                case "Lavish Excess":
                    Control += 1;
                    break;
                case "Undying Thirst":
                    Allegiance += 2;
                    break;
                default:
                    break;
            }
        }

        public static void ResetAll()
        {
            PlayerName = string.Empty;
            Allegiance = STARTING_ALLEGIANCE;
            AllegianceOld = 0;
            Control = STARTING_CONTROL;
            Potential = STARTING_POTENTIAL;
            MasteryLevels = STARTING_MASTERY_LEVELS;

            PlayerPact = new Pact();
            PlayerTraits = new TraitCollection();
            PlayerFaction = null;
            PlayerSubfaction = null;
            PathOfPleasure = null;
            PathOfPleasure2 = null;

            EarthMastery = 0;
            AirMastery = 0;
            FireMastery = 0;
            WaterMastery = 0;
            CelestialMastery = 0;
            ShadowMastery = 0;

            IsJoyfulMaiden = false;

            LoyaltyMinistry = 0;
            LoyaltyChurch = 0;
            LoyaltyHarem = 0;
            LoyaltyGuild = 0;
            LoyaltyCult = 0;

            UnalignedRecruitCount = 0;

            PlayerTraits.Clear();
            PlayerSpells.Clear();
            foreach (Spell spell in SpellList)
            {
                if (spell.IsKnownToAll)
                {
                    PlayerSpells.Add(spell);
                }
            }
            SignatureSpell = new Spell();
        }
    }
}
