﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterGenerator.Data
{
    public static class DataGenerator
    {
        public static TraitCollection CreateTraitList()
        {
            TraitCollection traits = new TraitCollection();
            traits.Add(new Trait { Name = "Fount of Power",     Cost = 1, Might = 1 });
            traits.Add(new Trait { Name = "Able Diplomat",      Cost = 1, Intrigue = 1 });
            traits.Add(new Trait { Name = "Spell Blade",        Cost = 1, Might = 1 });
            traits.Add(new Trait { Name = "Lover's Touch",      Cost = 1, Lust = 1, IsLover = true });
            traits.Add(new Trait { Name = "Signature Spell",    Cost = 2, Any = 1 });
            traits.Add(new Trait { Name = "Silver Tongue",      Cost = 2, Intrigue = 1 });
            traits.Add(new Trait { Name = "Ties That Bind",     Cost = 2, Might = 1 });
            traits.Add(new Trait { Name = "Heart of Lust",       Cost = 2, Lust = 1, IsLustWitch = true });
            traits.Add(new Trait { Name = "Esoteric Study",     Cost = 3, Any = 2 });
            traits.Add(new Trait { Name = "Arcane Talent",      Cost = 3, Any = 2, IsTalent = true });
            traits.Add(new Trait { Name = "Curse Weaver",       Cost = 3, Lust = 2 });
            traits.Add(new Trait { Name = "Soulfire Adept",     Cost = 3, Lust = 2 });
            traits.Add(new Trait { Name = "Kindred Spirit",     Cost = 4, Intrigue = 2 });
            traits.Add(new Trait { Name = "Mistress of Joy",    Cost = 4, Intrigue = 2 });
            traits.Add(new Trait { Name = "Enchantress",        Cost = 4, Might = 2 });
            traits.Add(new Trait { Name = "Arcane Prodigy",     Cost = 5, Any = 3, IsProdigy = true });

            traits.Add(new Trait { Name = "Mana Flux",          Cost = -1, Bonus = 1, Might = -1 });
            traits.Add(new Trait { Name = "Taboo Desires",      Cost = -1, Bonus = 1, Intrigue = -1 });
            traits.Add(new Trait { Name = "Slave to Pleasure",  Cost = -1, Bonus = 1, Intrigue = -1 });
            traits.Add(new Trait { Name = "Spell Addled",       Cost = -1, Bonus = 1, Lust = -1 });
            traits.Add(new Trait { Name = "Lavish Excess",      Cost = -2, Bonus = 2, Lust = -1 });
            traits.Add(new Trait { Name = "Need to Submit",     Cost = -2, Bonus = 2, Might = -1 });
            traits.Add(new Trait { Name = "Arcane Novice",      Cost = -3, Bonus = 3, Might = -1, IsNovice = true });
            traits.Add(new Trait { Name = "Undying Thirst",     Cost = -3, Bonus = 3, Intrigue = -1, Lust = -1, IsRevenant = true });

            return traits;
        }
    }
}
