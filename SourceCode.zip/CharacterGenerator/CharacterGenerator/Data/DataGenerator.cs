﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using e = CharacterGenerator.Spell.SpellElement;
using c = CharacterGenerator.Data.Companion;

namespace CharacterGenerator.Data
{
    public static class DataGenerator
    {
        public static TraitCollection CreateTraitList()
        {
            TraitCollection traits = new TraitCollection();
            traits.Add(new Trait { Name = "Fount of Power",     Cost = 1, Might = 1 });
            traits.Add(new Trait { Name = "Able Diplomat",      Cost = 1, Intrigue = 1 });
            traits.Add(new Trait { Name = "Spell Blade",        Cost = 1, Might = 1 });
            traits.Add(new Trait { Name = "Lover's Touch",      Cost = 1, Lust = 1, IsLover = true });
            traits.Add(new Trait { Name = "Signature Spell",    Cost = 2, Any = 1 });
            traits.Add(new Trait { Name = "Silver Tongue",      Cost = 2, Intrigue = 1, IsSilverTongue = true});
            traits.Add(new Trait { Name = "Ties That Bind",     Cost = 2, Might = 1, IsTiesThatBind = true });
            traits.Add(new Trait { Name = "Heart of Lust",      Cost = 2, Lust = 1, IsLustWitch = true });
            traits.Add(new Trait { Name = "Esoteric Study",     Cost = 3, Any = 2 });
            traits.Add(new Trait { Name = "Arcane Talent",      Cost = 3, Any = 2, IsTalent = true });
            traits.Add(new Trait { Name = "Curse Weaver",       Cost = 3, Lust = 2 });
            traits.Add(new Trait { Name = "Soulfire Adept",     Cost = 3, Lust = 2 });
            traits.Add(new Trait { Name = "Kindred Spirit",     Cost = 4, Intrigue = 2 });
            traits.Add(new Trait { Name = "Mistress of Joy",    Cost = 4, Intrigue = 2 });
            traits.Add(new Trait { Name = "Enchantress",        Cost = 4, Might = 2 });
            traits.Add(new Trait { Name = "Arcane Prodigy",     Cost = 5, Any = 3, IsProdigy = true });

            traits.Add(new Trait { Name = "Mana Flux",          Cost = -1, Bonus = 1, Might = -1 });
            traits.Add(new Trait { Name = "Taboo Desires",      Cost = -1, Bonus = 1, Intrigue = -1 });
            traits.Add(new Trait { Name = "Slave to Pleasure",  Cost = -1, Bonus = 1, Intrigue = -1 });
            traits.Add(new Trait { Name = "Spell Addled",       Cost = -1, Bonus = 1, Lust = -1 });
            traits.Add(new Trait { Name = "Lavish Excess",      Cost = -2, Bonus = 2, Lust = -1 });
            traits.Add(new Trait { Name = "Need to Submit",     Cost = -2, Bonus = 2, Might = -1 });
            traits.Add(new Trait { Name = "Arcane Novice",      Cost = -3, Bonus = 3, Might = -1, IsNovice = true });
            traits.Add(new Trait { Name = "Undying Thirst",     Cost = -3, Bonus = 3, Intrigue = -1, Lust = -1, IsRevenant = true });

            return traits;
        }

        //for creating spell descriptions
        private static string generateDescription (string name, string keyWords1, string mastery1
                , string keyWords2 = "", string mastery2 = ""
                , bool isLustMagic = false
                , string keyWords3 = "", string mastery3 = ""
                , string keyWords4 = "", string mastery4 = ""
                , bool isCelestialShadow = false)
        {
            string description;
            string lustMagic = "";
            if (isLustMagic)
            {
                lustMagic = " (Lust Magic)";
            }

            if (!isCelestialShadow)
            {
                description = $"{name}{lustMagic}\r\n\r\n{keyWords1}\r\n{mastery1}\r\n\r\n{keyWords2}\r\n{mastery2}";
            }
            else
            {
                description = $"{name}{lustMagic}\r\n\r\n{keyWords1}\r\n{mastery1}\r\n\r\n{keyWords2}\r\n{mastery2}\r\n\r\n{keyWords3}\r\n{mastery3}\r\n\r\n{keyWords4}\r\n{mastery4}";
            }
            return description;
        }

        public static SpellCollection CreateSpellList()
        {
            SpellCollection spells = new SpellCollection();
            string name = "";
            string keyWords1 = "";
            string keyWords2 = "";
            string keyWords3 = "";
            string keyWords4 = "";
            string mastery1 = "";
            string mastery2 = "";
            string mastery3 = "";
            string mastery4 = "";

            //Earth 1
            spells.Add(new Spell { Name = "–––  Earth ◆ –––", Element = e.Earth, Mastery = 5 });

            name = "Essence of Earth";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self";
            mastery1 = "Your skin becomes almost as hard as stone. Although you are not invulnerable, your body is very resilient against most weapons.";
            mastery2 = "Your body also slowly knits itself back together even when you are cut or pierced, healing your wounds.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Shards of Stone";
            keyWords1 = "◆ Self, Expendable";
            keyWords2 = "◆◆ Self, Expendable";
            mastery1 = "You call forth a swarm of rocks to surround you and strike those who venture too close. You can also hurl the individual rock shards at enemies with great force.";
            mastery2 = "The rocks are razor sharp and as strong as iron.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Root to Stem";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target";
            mastery1 = "The target is filled with arousal and desire to be deeply penetrated, and will only climax from yielding to obscenely large intrusions. It costs no mana to extend this spell's duration.";
            mastery2 = "The target can be safely pleasured by vastly oversized objects and partners.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            name = "Wilting Reed";
            keyWords1 = "◆ Area";
            keyWords2 = "◆◆ Area";
            mastery1 = "You weaken the resilience of anyone you select within the area, leaving them more sensitive to pain and prone to injury.";
            mastery2 = "The spell also weakens the active wards of others within the area, rendering them much less able to withstand attack.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Entangling Vines";
            keyWords1 = "◆ Area";
            keyWords2 = "◆◆ Area";
            mastery1 = "You cause tendrils of smooth or thorny vines to burst forth and entangle all creatures in the area. This spell can only be cast where plants are present.";
            mastery2 = "The vines can be called forth at any location to entangle enemies.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Primal Vigor";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Target";
            mastery1 = "You will not tire from physical exertion for the spell duration, and have no refractory period.";
            mastery2 = "You can grant others the same enhanced vigor and sexual potency.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Earth 2
            spells.Add(new Spell { Name = "–––  Earth ◆◆ –––", Element = e.Earth, Mastery = 5 });

            name = "The Earth Endures";
            keyWords1 = "◆◆ Self, Daylong";
            keyWords2 = "◆◆◆ Self, Daylong";
            mastery1 = "You draw upon the power of the earth to sustain yourself. You have no need for any food or water, become immune to disease and poison, and can withstand most weather.";
            mastery2 = "You can stay active without sleep, although you still need sleep to restore mana.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Choking Sands";
            keyWords1 = "◆◆ Area";
            keyWords2 = "◆◆◆ Area";
            mastery1 = "You create a harshly abrasive sandstorm that can strip flesh from bone if given time. Vision is very limited inside the storm.";
            mastery2 = "You are immune to the effects of the sands, and can keep the cloud centered on yourself as you move with no ill effect.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Mating Call";
            keyWords1 = "◆◆ Target";
            keyWords2 = "◆◆◆ Target";
            mastery1 = "The target feels an urgent need to copulate with anyone you specify. Even after being sated, the urge will soon return in force.";
            mastery2 = "You can drive the target to offer themselves submissively to their obsession, or seek to ravage them with animalistic lust.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            name = "Ferocious Beasts";
            keyWords1 = "◆◆ Summon, Daylong";
            keyWords2 = "◆◆◆ Summon, Daylong";
            mastery1 = "Call forth a wild creature to protect you and attack your enemies. Cast the spell without the full day duration to call a swarm instead.";
            mastery2 = "You can command the actions of the creatures you summon, beyond having them merely defend or attack.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Noxious Vapors";
            keyWords1 = "◆◆ Area";
            keyWords2 = "◆◆◆ Area";
            mastery1 = "You bring foul smelling vapors from deep within the earth to the surface. All in the area are left nauseated.";
            mastery2 = "The vapors can be scentless, and will knock out anyone who does not leave the area immediately.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Mark of Fertility";
            keyWords1 = "◆◆ Touch, Daylong, Expendable";
            keyWords2 = "◆◆◆ Touch, Daylong, Expendable";
            mastery1 = "The target is guaranteed to conceive with, or impregnate, their next compatible partner.";
            mastery2 = "Any woman who conceives will feel great contentment in her pregnancy, which is shortened to only three months. Her labor and delivery will be easy and pleasurable.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Earth 3
            spells.Add(new Spell { Name = "––– Earth ◆◆◆ –––", Element = e.Earth, Mastery = 5 });

            name = "Timeless Beauty";
            keyWords1 = "◆◆◆ Self, Daylong";
            keyWords2 = "◆◆◆◆ Self, Daylong";
            mastery1 = "You are restored to a state of idealized youth, where your vitality and beauty return to their prime, although your true age is unchanged. You can extend the spell duration to a week.";
            mastery2 = "You also age at half the normal rate, and can extend the duration to a month.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "The Mountain Speaks";
            keyWords1 = "◆◆◆ Area, Instant";
            keyWords2 = "◆◆◆◆ Area, Instant";
            mastery1 = "Send forth waves of violent tremors at an area, hurling enemies to the ground to be swallowed up by open fissures. ";
            mastery2 = "Your earthquake is especially destructive, and can bring down castle walls and other large structures.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Sinful Roots";
            keyWords1 = "◆◆◆ Target, Instant";
            keyWords2 = "◆◆◆◆ Target, Instant";
            mastery1 = "The target is encased inside the trunk of a twisted tree, where they are ravished while force fed a life sustaining aphrodisiac sap.";
            mastery2 = "Your tree can be commanded to ensnare nearby prey with their roots, turning them into more trees that lacks this ability.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            name = "Dust to Dust";
            keyWords1 = "◆◆◆ Item, Instant";
            keyWords2 = "◆◆◆◆ Area, Instant";
            mastery1 = "You cause an unattended non magical object smaller than yourself to disintegrate to dust.";
            mastery2 = "Destroy any number of mundane objects up to ten times your size in the area. You could disarm an entire phalanx at once.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Command the Stone";
            keyWords1 = "◆◆◆ Summon";
            keyWords2 = "◆◆◆◆ Summon";
            mastery1 = "You summon a massive earth elemental to pulverize your enemies. Commanding the elemental requires concentration.";
            mastery2 = "Your elemental can serve as a fearsome mount, as well as protect you in combat without your direct guidance.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Marble Curse";
            keyWords1 = "◆◆◆ Target, Permanent, Curse";
            keyWords2 = "◆◆◆◆ Target, Permanent, Curse";
            mastery1 = "The target will feel such arousal as to initially leave them stunned. The next time they near the peak of pleasure, they turn into a marble statue, kept conscious just shy of climax.";
            mastery2 = "The target's body stays warm, and is pliant enough to be posed and pleasured.";
            spells.Add(new Spell { Name = name, Element = e.Earth, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Air 1
            spells.Add(new Spell { Name = "", Element = e.Air, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Air ◆ –––", Element = e.Air, Mastery = 5 });

            name = "Essence of Air";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self";
            mastery1 = "You become light on your feet. You can leap great distances and move with extreme grace and precision.";
            mastery2 = "You can maintain perfect balance, make yourself as light as a feather at will, and land from any height without harm.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Biting Winds";
            keyWords1 = "◆ Area, Instant";
            keyWords2 = "◆◆ Target, Instant";
            mastery1 = "You conjure a sudden fierce windstorm strong enough to shred clothing and tear flesh. ";
            mastery2 = "Your focused windstorm is strong enough to hurl a target off their feet.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Whirlwind Kiss";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target";
            mastery1 = "The target is violated by a probing vortex of swirling magic, which can be controlled, or will attend the target on its own. It costs no mana to extend this spell's duration.";
            mastery2 = "You can create multiple vortices which restrain and violate the target as one.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            name = "Stolen Grace";
            keyWords1 = "◆ Area";
            keyWords2 = "◆◆ Area";
            mastery1 = "You hamper the sense of precision of anyone you select within the area, leaving them clumsy both in and out of battle.";
            mastery2 = "The affected are rendered so out of balance, they will be struck with vertigo and left barely able to walk.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Veil of Silence";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Area";
            mastery1 = "Your silence the target, preventing them from making any noise for the spell's duration. The silence makes spellcasting more difficult.";
            mastery2 = "You can hush an entire area, and lull those within to sleep if you wish.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Mask of Vanity";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self";
            mastery1 = "You weave a subtle illusion that improves attractiveness and provokes lust. You are still recognizably you, only more beautiful.";
            mastery2 = "You can alter your appearance much more drastically, as long as your new guise remains beautiful.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Air 2
            spells.Add(new Spell { Name = "––– Air ◆◆ –––", Element = e.Air, Mastery = 5 });

            name = "Whispered Secrets";
            keyWords1 = "◆◆ Self";
            keyWords2 = "◆◆◆ Self";
            mastery1 = "You can read the surface thoughts of anyone close by who is under your attention. You retain enough focus to still act normally.";
            mastery2 = "You can delve deeper than mere surface thoughts, although this will be felt by the target of your interrogation.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Pillar of Heaven";
            keyWords1 = "◆◆ Target, Instant";
            keyWords2 = "◆◆◆ Area, Instant";
            mastery1 = "You conjure a brilliant bolt of lightning, which may either stun or electrocute the target.";
            mastery2 = "The lightning will arc from creature to creature, striking only those you choose.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Beguiling Scent";
            keyWords1 = "◆◆ Self";
            keyWords2 = "◆◆◆ Self";
            mastery1 = "You exude an alluring scent that makes those around you intensely horny and more likely to seek out your company.";
            mastery2 = "Those affected by your scent are rendered very suggestible, and are easily convinced by reasonable sounding requests.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            name = "Booming Thunder";
            keyWords1 = "◆◆ Area, Instant";
            keyWords2 = "◆◆◆ Area, Instant";
            mastery1 = "You create a painfully loud boom that harms, disorients, and temporarily deafens everyone within the area.";
            mastery2 = "You can dampen the sound when it reaches you, and can cast the spell centered on yourself without ill effects.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Weave Illusions";
            keyWords1 = "◆◆ Target, Item";
            keyWords2 = "◆◆◆ Area";
            mastery1 = "You can alter the appearance of a person or smaller sized object, or conjure a single phantom image accompanied by sound.";
            mastery2 = "Create massed illusions that can move freely throughout the chosen area.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Freedom Denied";
            keyWords1 = "◆◆ Touch, Daylong";
            keyWords2 = "◆◆◆ Touch, Daylong";
            mastery1 = "Prohibit the target against a course of action. Any attempted violation will be halted by the pins and needles torment of a sudden and wretched ruined orgasm. This dictate cannot place the target in obvious mortal danger.";
            mastery2 = "The target cannot reveal their plight.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Air 3
            spells.Add(new Spell { Name = "––– Air ◆◆◆ –––", Element = e.Air, Mastery = 5 });

            name = "Cloak of the Skies";
            keyWords1 = "◆◆◆ Self";
            keyWords2 = "◆◆◆◆ Self";
            mastery1 = "You can move through the air at a nimble speed with hummingbird precision, and use the wind around you to deflect attacks.";
            mastery2 = "You can fly even faster, and use the wind around you to try and deflect not just swords and arrows, but also spells.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Turn Into Mist";
            keyWords1 = "◆◆◆ Self";
            keyWords2 = "◆◆◆◆ Self, Expendable";
            mastery1 = "You transform into an intangible mist that can hover and slip through the tiniest gaps. You may not cast spells in this form.";
            mastery2 = "You may cast a spell in mist form.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Edge of Surrender";
            keyWords1 = "◆◆◆ Target, Permanent, Curse";
            keyWords2 = "◆◆◆◆ Target, Permanent, Curse";
            mastery1 = "The target is cursed with a lingering arousal, but every time they climax, they become more shameless, submissive, and debauched.";
            mastery2 = "You can plant the seeds of specific kinks in place of, or in addition to, the other behavior changes caused by the spell.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            name = "Reap the Whirlwind";
            keyWords1 = "◆◆◆ Area";
            keyWords2 = "◆◆◆◆ Area";
            mastery1 = "You call down a destructive whirlwind that dashes about all within the area, before it starts to wander the field randomly.";
            mastery2 = "You can control the path of the whirlwind with concentration. It also stays put when you are not concentrating on it.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Command the Wind";
            keyWords1 = "◆◆◆ Summon";
            keyWords2 = "◆◆◆◆ Summon";
            mastery1 = "You summon a massive air elemental to suffocate your enemies. Commanding the elemental requires concentration.";
            mastery2 = "Your elemental can carry you aloft, as well as protect you in combat without your direct guidance.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Edict of Obedience";
            keyWords1 = "◆◆◆ Target, Daylong";
            keyWords2 = "◆◆◆◆ Target, Daylong";
            mastery1 = "You cause the target to feel great pleasure while following a given order, and intense dread at the thought of actively disobeying it.";
            mastery2 = "You bury the compulsion deep within the target's mind, making it harder to resist, or be noticed by the target and others.";
            spells.Add(new Spell { Name = name, Element = e.Air, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Fire 1
            spells.Add(new Spell { Name = "", Element = e.Fire, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Fire ◆ –––", Element = e.Fire, Mastery = 5 });

            name = "Essence of Fire";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self, Expendable";
            mastery1 = "You gain incredible speed. Your movements are almost faster than the eye can follow.";
            mastery2 = "You may expend your haste all at once to immediately cast a second spell.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Blazing Tendrils";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self, Expendable";
            mastery1 = "Two tendrils of flame extend from your hands, letting you lash out at your enemies.";
            mastery2 = "You can relinquish each tendril to chase down and strike an enemy on its own.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Enkindle the Fire";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target";
            mastery1 = "Any part of the target's body can be turned into a highly responsive erogenous zone. It costs no mana to extend this spell's duration.";
            mastery2 = "You can tease the chosen part of the body at a distance while the spell lasts.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            name = "Fading Embers";
            keyWords1 = "◆ Area";
            keyWords2 = "◆◆ Area";
            mastery1 = "You inflict anyone you select within the area with soreness, leaving them sluggish and unable to keep pace with others.";
            mastery2 = "The affected have their reaction times so compromised, evading their sword strikes becomes child's play.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Quickfire Wit";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self";
            mastery1 = "You can think fast on your feet, and are never at a loss for words. Your eloquence will leave others charmed or inspired.";
            mastery2 = "You can also observe unfamiliar social customs and rapidly adjust your own behavior to match.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Tender Passions";
            keyWords1 = "◆ Touch, Daylong";
            keyWords2 = "◆◆ Touch, Daylong";
            mastery1 = "Those who surrender willingly to your warm and pleasurable touch will feel elated and favorable towards you for the rest of the day.";
            mastery2 = "Your willing lovers are emotionally vulnerable when you pleasure them, and will open up to you at the slightest prompting.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Fire 2
            spells.Add(new Spell { Name = "––– Fire ◆◆ –––", Element = e.Fire, Mastery = 5 });

            name = "Raise the Banner";
            keyWords1 = "◆◆ Target";
            keyWords2 = "◆◆◆ Area";
            mastery1 = "You drive away fear and doubt to inspire the target towards acts of greatness.";
            mastery2 = "You can inspire a large crowd of your chosen followers all at once.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Meteor Hammer";
            keyWords1 = "◆◆ Target, Instant";
            keyWords2 = "◆◆◆ Area, Instant";
            mastery1 = "You hurl a white hot orb that strikes a target and explodes with tremendous force.";
            mastery2 = "The flaming orb causes a larger explosion that devastates an entire area.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Fan the Flame";
            keyWords1 = "◆◆ Target";
            keyWords2 = "◆◆◆ Target";
            mastery1 = "You inflame the target's desire to perform a particular type of lewd act, while at the same time lowering their natural inhibitions.";
            mastery2 = "The target will be convinced the desire is their own, no matter how unusual.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });
            
            name = "Heat Metal";
            keyWords1 = "◆◆ Item";
            keyWords2 = "◆◆◆ Item";
            mastery1 = "You can heat up a metal weapon, piece of armor, or other metallic object. While it will burn anyone else who touches it, you can wield any weapon heated by your own spell.";
            mastery2 = "You can fully melt down a metal item into molten slag.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Wall of Fire";
            keyWords1 = "◆◆ Area";
            keyWords2 = "◆◆◆ Area";
            mastery1 = "You set the ground aflame with a wall of fire, promising a painful and gruesome death for anyone foolhardy enough to charge through.";
            mastery2 = "You can curve the wall into any shape rather than just a straight line, and have it radiate intense heat on only one side.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Painful Passions";
            keyWords1 = "◆◆ Target";
            keyWords2 = "◆◆◆ Target";
            mastery1 = "The target experiences physical pain also as pleasure, while having it be no less painful.";
            mastery2 = "The target's sense of pleasure is massively amplified by pain. Sustained agony can be enough to push them over the edge and force them into climax.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Fire 3
            spells.Add(new Spell { Name = "––– Fire ◆◆◆ –––", Element = e.Fire, Mastery = 5 });

            name = "Mindless Rage";
            keyWords1 = "◆◆◆ Target";
            keyWords2 = "◆◆◆◆ Area";
            mastery1 = "You cause the target to enter into a blind rage and attack everyone with pure hatred.";
            mastery2 = "You can affect a whole group at once, turning them against each other, and driving them into a mad frenzy of slaughter.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Burn to Cinders";
            keyWords1 = "◆◆◆ Target, Item, Instant";
            keyWords2 = "◆◆◆◆ Target, Instant";
            mastery1 = "You bathe the target creature or object in a blinding hot flash, quickly reducing it to ash.";
            mastery2 = "You cause a living target to be overwhelmed by your fire magic and explode in a horrific conflagration.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Light the Inferno";
            keyWords1 = "◆◆◆ Area, Instant";
            keyWords2 = "◆◆◆◆ Area, Instant";
            mastery1 = "Everyone in the area is brought to the peak of pleasure. Those who can climax reach a sudden and overwhelming series of orgasms.";
            mastery2 = "The unnatural surge of pleasure is so overwhelming, it will cause those affected to fall unconscious and be rendered helpless.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            name = "Living Fire";
            keyWords1 = "◆◆◆ Self";
            keyWords2 = "◆◆◆◆ Self";
            mastery1 = "You are surrounded by a flaming nimbus that does you no harm, but will burn away arrows and horribly scorch anyone who strikes you.";
            mastery2 = "You can soar through the air like a shooting star, hurl bolts of fire, and choose to burn everything in your wake.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Command the Flame";
            keyWords1 = "◆◆◆ Summon";
            keyWords2 = "◆◆◆◆ Summon";
            mastery1 = "You summon a massive fire elemental to incinerate your enemies. Commanding the elemental requires concentration.";
            mastery2 = "Your elemental can hurl bolts of fire, as well as protect you in combat without your direct guidance.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Savage Passions";
            keyWords1 = "◆◆◆ Target, Permanent, Curse";
            keyWords2 = "◆◆◆◆ Target, Permanent, Curse";
            mastery1 = "The target is filled with a desire to cruelly dominate and torment the people you have specified, and will take great pleasure in it.";
            mastery2 = "The longer the target resists, the more aroused they become, and the more cruel they will be once they finally give in.";
            spells.Add(new Spell { Name = name, Element = e.Fire, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Water 1
            spells.Add(new Spell { Name = "", Element = e.Water, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Water ◆ –––", Element = e.Water, Mastery = 5 });
            
            name = "Essence of Water";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self";
            mastery1 = "You gain the might of the waves. You are strong enough to lift many times your body weight, and bend steel with your bare hands.";
            mastery2 = "You may breathe and cast spells underwater, as well as swim as fast and as skillfully as a dolphin.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });

            name = "Ice Daggers";
            keyWords1 = "◆ Self, Expendable";
            keyWords2 = "◆◆ Self, Expendable";
            mastery1 = "You call forth a ring of spinning icicles to menace your foes. You can also hurl the individual icicles at enemies with great force.";
            mastery2 = "Anyone struck by the freezing ice will be numbed by a chilling cold that spreads through their entire body.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Dam the River";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target";
            mastery1 = "The target is kept aroused, but left unable to climax no matter how hard they try. It costs no mana to extend this spell's duration.";
            mastery2 = "You can instead cause the target's orgasms to feel unsatisfactory and ruined, or allow climax only under select circumstances, as determined by you.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });
            
            name = "Receding Tide";
            keyWords1 = "◆ Area";
            keyWords2 = "◆◆ Area";
            mastery1 = "You enfeeble anyone you select within the area. What once required little exertion now feels like a heavy burden.";
            mastery2 = "The affected are so weakened, they can barely swing a sword, and can be easily wrestled to the ground.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Flash Freeze";
            keyWords1 = "◆ Area";
            keyWords2 = "◆◆ Area";
            mastery1 = "You quickly lower the temperature within the area, causing water to freeze, and the ground to become slippery with frost.";
            mastery2 = "The piercing chill is debilitating to others in the area, and those who succumb may find themselves frozen in their tracks.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Taste Like Honey";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self";
            mastery1 = "Your saliva and sexual fluids have a pleasant taste, and act as a potent aphrodisiac. This can apply to breast milk if you are lactating.";
            mastery2 = "Anyone who has had a taste will also feel far more uninhibited and sexually adventurous for several hours.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });
            
            spells.Add(new Spell { Name = "––– Water ◆◆ –––", Element = e.Water, Mastery = 5 });

            name = "Fountain of Life";
            keyWords1 = "◆◆ Touch";
            keyWords2 = "◆◆◆ Touch";
            mastery1 = "You assist the body in healing over time. The longer the target is affected by the spell, the more they are healed by its magic.";
            mastery2 = "With enough castings, you can cure diseases, purge poisons, remove any mental afflictions, and even regrow limbs.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Unseen Depths";
            keyWords1 = "◆◆ Self";
            keyWords2 = "◆◆◆ Target, Daylong";
            mastery1 = "Both your active spell auras and your true intentions become much harder to discern. ";
            mastery2 = "The obscuring effect now lasts for much longer, and can be cast on others.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Milk of Ambrosia";
            keyWords1 = "◆◆ Self";
            keyWords2 = "◆◆◆ Self";
            mastery1 = "Your swelling bosom produces an abundance of mildly addictive breast milk. Drinking their fill sates a person's hunger, and imparts a brief but potent rush of alertness and virility.";
            mastery2 = "Your milk is even more potent and addictive, causing a rush lasting many hours.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });
            
            name = "Submerging Sphere";
            keyWords1 = "◆◆ Target";
            keyWords2 = "◆◆◆ Area";
            mastery1 = "You submerge the target in an inescapable hovering sphere of water. The sphere can be moved with concentration.";
            mastery2 = "Your sphere is large enough to engulf several people at once.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Mirror of Clarity";
            keyWords1 = "◆◆ Area, Item";
            keyWords2 = "◆◆◆ Area, Item";
            mastery1 = "Conjure a vision of a remote area in a bowl of water. The closer and more familiar the area, the clearer the vision. This scrying may be sensed and dismissed by hostile sorcery.";
            mastery2 = "The vision will reveal the presence of illusions and arcane transmutations.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Ebb and Flow";
            keyWords1 = "◆◆ Touch, Permanent, Curse";
            keyWords2 = "◆◆◆ Touch, Instant";
            mastery1 = "You curse some or all of the target's body to appear more masculine or feminine in some regard, short of outright changing their sex.";
            mastery2 = "Any changes made to the target's body is treated as their new natural form.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 2
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            spells.Add(new Spell { Name = "––– Water ◆◆◆ –––", Element = e.Water, Mastery = 5 });

            name = "Ritual of Rebirth";
            keyWords1 = "◆◆◆ Target, Daylong";
            keyWords2 = "◆◆◆◆ Target, Daylong";
            mastery1 = "Grant the willing a new body of the same age and sex. Once a lifetime, a sorceress can gain a new natural form, making the spell instant.";
            mastery2 = "The target's body can appear to be a younger adult age, without changing their true age. This effect cannot be made instant.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Eternal Ice";
            keyWords1 = "◆◆◆ Target, Instant";
            keyWords2 = "◆◆◆◆ Target, Instant";
            mastery1 = "You encase the target in a block of unmelting tough to shatter ice. The target is frozen, still conscious yet helplessly trapped.";
            mastery2 = "The ice can be dismissed, but only by a sorceress at least as powerful as you. It cannot be shattered by mundane means.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Ravishing Tentacles";
            keyWords1 = "◆◆◆ Summon";
            keyWords2 = "◆◆◆◆ Summon";
            mastery1 = "Slimy tentacles burst forth to ravish your foes. The tentacle mass can chase after prey with surprising speed, possesses inhuman strength, and secrete a powerful aphrodisiac.";
            mastery2 = "The tentacles obey you and count as extensions of yourself for Paths of Pleasure.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });
            
            name = "Be Without Form";
            keyWords1 = "◆◆◆ Self";
            keyWords2 = "◆◆◆◆ Self";
            mastery1 = "Your body becomes incredibly flexible and resilient. You can stretch and contort beyond human limits, as well as fit through tiny gaps. Mundane weapons will slide off your body.";
            mastery2 = "You can reflect the momentum of mundane attacks by touch.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Command the Waves";
            keyWords1 = "◆◆◆ Summon";
            keyWords2 = "◆◆◆◆ Summon";
            mastery1 = "You summon a massive water elemental to sweep away your enemies. Commanding the elemental requires concentration.";
            mastery2 = "Your elemental can carry you with air underwater, as well as protect you in combat without your direct guidance.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2)
            });
            
            name = "Heart to Heart";
            keyWords1 = "◆◆◆ Touch, Self, Daylong";
            keyWords2 = "◆◆◆◆ Touch, Self, Daylong";
            mastery1 = "Form an intimate bond with another willing sorceress. Afterwards, you may share in each other's thoughts, senses, and available mana. You may only bond with one sorceress a day.";
            mastery2 = "Each of you may act as the conduit or recipient of the other's completed spells.";
            spells.Add(new Spell { Name = name, Element = e.Water, Mastery = 3
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true)
                , IsLustMagic = true
            });

            //Celestial 1
            spells.Add(new Spell { Name = "", Element = e.Celestial, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Celestial ◆ –––", Element = e.Celestial, Mastery = 5 });

            name = "Lay on Hands";
            keyWords1 = "◆ Touch, Instant";
            keyWords2 = "◆◆ Touch, Instant";
            keyWords3 = "◆◆◆ Touch, Instant";
            keyWords4 = "◆◆◆◆ Touch, Instant";
            mastery1 = "You can channel soothing energies to dismiss fatigue and heal minor injuries.";
            mastery2 = "You can cure disease and poisons, and heal more serious wounds. Truly severe injuries may need multiple castings to fully mend.";
            mastery3 = "You can cure the most severe maladies such as lifelong afflictions or even missing limbs.";
            mastery4 = "On a willing target, you may undo an instant spell effect that altered their natural form.";
            spells.Add(new Spell { Name = name, Element = e.Celestial, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Celestial Blessing";
            keyWords1 = "◆ Touch, Expendable";
            keyWords2 = "◆◆ Touch, Expendable";
            keyWords3 = "◆◆◆ Touch, Expendable";
            keyWords4 = "◆◆◆◆ Touch";
            mastery1 = "You bless the target with minor yet notable good fortune in whatever task they choose to focus upon next.";
            mastery2 = "The target may call upon their blessing at a time of their choosing, while the spell lasts.";
            mastery3 = "The target will intuit any impending failure.";
            mastery4 = "Good fortune persists for the spell's duration.";
            spells.Add(new Spell { Name = name, Element = e.Celestial, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Speak to the Heart";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target";
            keyWords3 = "◆◆◆ Target";
            keyWords4 = "◆◆◆◆ Target";
            mastery1 = "Strengthen the target's romantic attraction to you. This spell can only be cast on someone who already desires you, and not on yourself.";
            mastery2 = "The target feels great joy in serving you.";
            mastery3 = "The target's affection for you is so great, they will eagerly perform almost any non violent act you request.";
            mastery4 = "The target is willing to do anything you ask, even turn against kin, or sacrifice their life.";
            spells.Add(new Spell { Name = name, Element = e.Celestial, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true, keyWords3, mastery3, keyWords4, mastery4, true)
                , IsLustMagic = true
            });
            
            name = "Divine Judgment";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target, Instant";
            keyWords3 = "◆◆◆ Area, Instant";
            keyWords4 = "◆◆◆◆ Area, Instant";
            mastery1 = "The target is wracked by crippling pain if they attempt any act of violence.";
            mastery2 = "Strike the unworthy with scorching light.";
            mastery3 = "Scour a wide area with divine power.";
            mastery4 = "You and your allies in the area remain safe, while slain enemies are turned to dust.";
            spells.Add(new Spell { Name = name, Element = e.Celestial, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Radiant Shield";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target, Expendable";
            keyWords3 = "◆◆◆ Self, Expendable";
            keyWords4 = "◆◆◆◆ Self, Expendable";
            mastery1 = "Entirely negate the next outside spell cast at an equal or lower Mastery that would affect you. A spell of higher Mastery that breaches the shield is still dampened.";
            mastery2 = "You can channel the energy of a collapsing Radiant Shield into strengthening your Ward.";
            mastery3 = "If you fully negate a targeted spell, you can instead reflect it back at the caster.";
            mastery4 = "You can negate an area spell cast near you.";
            spells.Add(new Spell { Name = name, Element = e.Celestial, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Sublime Sympathy";
            keyWords1 = "◆ Target, Self";
            keyWords2 = "◆◆ Target, Self";
            keyWords3 = "◆◆◆ Target, Self";
            keyWords4 = "◆◆◆◆ Target, Self";
            mastery1 = "Sense the target's pain and pleasure, have them experience yours, or make it mutual. It costs no mana to extend this spell's duration.";
            mastery2 = "Mentally converse with the target and hear their surface thoughts with concentration.";
            mastery3 = "Link with two targets at once, and control how sensations are shared between them.";
            mastery4 = "You and your targets always count as being in each other's presence for Paths of Pleasure.";
            spells.Add(new Spell { Name = name, Element = e.Celestial, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true, keyWords3, mastery3, keyWords4, mastery4, true)
                , IsLustMagic = true
            });
            
            name = "Guiding Light";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self";
            keyWords3 = "◆◆◆ Self";
            keyWords4 = "◆◆◆◆ Self, Instant";
            mastery1 = "Your blessed vision lets you see clearly in the dark, and better spot what has been hidden.";
            mastery2 = "The celestial light also reveals any weakness in enemy defenses, helping you in battle.";
            mastery3 = "You can see through magical illusions.";
            mastery4 = "You glimpse brief visions of a specified event up to a day ahead in a likely potential future.";
            spells.Add(new Spell { Name = name, Element = e.Celestial, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Sanctified Space";
            keyWords1 = "◆ Area, Permanent";
            keyWords2 = "◆◆ Area, Permanent";
            keyWords3 = "◆◆◆ Area, Permanent";
            keyWords4 = "◆◆◆◆ Area";
            mastery1 = "Spend 10 minutes to inscribe a sacred circle that prevents all spellcasting within the area.";
            mastery2 = "You can attune the circle to exempt yourself and select others, or to only affect one person.";
            mastery3 = "Warded enemies cannot enter your circle.";
            mastery4 = "Hastily cast a circle around where you stand, although attuning to it still takes 10 minutes.";
            spells.Add(new Spell { Name = name, Element = e.Celestial, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Touch of Euphoria";
            keyWords1 = "◆ Touch, Self";
            keyWords2 = "◆◆ Touch, Self";
            keyWords3 = "◆◆◆ Touch, Self";
            keyWords4 = "◆◆◆◆ Touch, Self";
            mastery1 = "You cause anyone else touched to experience an intense and mildly addictive pleasure.";
            mastery2 = "You can conjure a phallus of light from your sex that can pleasure yourself and a lover at once. Its touch is just as addictive to others.";
            mastery3 = "Your touch is so pleasurable, the affected will feel strong cravings for a full month. Anyone deprived will suffer daily painful withdraw.";
            mastery4 = "Withdraw is agonizing and will never lessen.";
            spells.Add(new Spell { Name = name, Element = e.Celestial, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true, keyWords3, mastery3, keyWords4, mastery4, true)
                , IsLustMagic = true
            });
            
            //Shadow 1
            spells.Add(new Spell { Name = "", Element = e.Shadow, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Shadow ◆ –––", Element = e.Shadow, Mastery = 5 });

            name = "Summon Spirit";
            keyWords1 = "◆ Summon";
            keyWords2 = "◆◆ Summon";
            keyWords3 = "◆◆◆ Summon";
            keyWords4 = "◆◆◆◆ Summon";
            mastery1 = "You may attempt to converse with the spirit of someone who has died within the last year.";
            mastery2 = "Attempt to converse with long dead spirits.";
            mastery3 = "By offering a fitting treasure or promise, you can beseech a mighty spirit for help to cast an unknown spell, or for some other service.";
            mastery4 = "Summon the spirit of a deceased sorceress to briefly aid you in battle. Although you must find a way to honor or repay her afterwards.";
            spells.Add(new Spell { Name = name, Element = e.Shadow, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Drain the Lifeblood";
            keyWords1 = "◆ Touch, Self, Instant";
            keyWords2 = "◆◆ Touch, Self, Instant";
            keyWords3 = "◆◆◆ Touch, Self, Instant";
            keyWords4 = "◆◆◆◆ Touch, Self, Instant";
            mastery1 = "You feed off the vitality of a touched mortal to sate your hunger and cure injuries. This stolen vitality can only be healed naturally.";
            mastery2 = "You also grow stronger and faster for an hour.";
            mastery3 = "Cease aging for a year by draining an adult human to death. You also look and feel more youthful overall in that time. As an Alchemist, you may craft an Elixir of Immortality instead.";
            mastery4 = "Age in reverse for your year of stolen youth.";
            spells.Add(new Spell { Name = name, Element = e.Shadow, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Bind the Soul";
            keyWords1 = "◆ Target, Item, Daylong";
            keyWords2 = "◆◆ Target, Item, Daylong";
            keyWords3 = "◆◆◆ Target, Item, Daylong";
            keyWords4 = "◆◆◆◆ Target, Item, Daylong";
            mastery1 = "Once per hour, you may attempt to usurp the target's actions and arousal for an hour. The target must carry a focus item made by you.";
            mastery2 = "The target feels in control even when you win the struggle. You may recast this spell at any range as long as the target carries the focus.";
            mastery3 = "In death, also trap the target's soul inside the focus, where it will remain bound until freed.";
            mastery4 = "The focus makes resisting you impossible.";
            spells.Add(new Spell { Name = name, Element = e.Shadow, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true, keyWords3, mastery3, keyWords4, mastery4, true)
                , IsLustMagic = true
            });
            
            name = "Dire Shadows";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target, Instant";
            keyWords3 = "◆◆◆ Area, Instant";
            keyWords4 = "◆◆◆◆ Area, Instant";
            mastery1 = "The target's vision is clouded by darkness, striking them blind.";
            mastery2 = "Strike the living with devouring darkness.";
            mastery3 = "Scour a wide area with hungry shadows.";
            mastery4 = "You may instantly raise the slain as zombies under your control.";
            spells.Add(new Spell { Name = name, Element = e.Shadow, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Rise from the Grave";
            keyWords1 = "◆ Touch, Instant";
            keyWords2 = "◆◆ Touch, Instant";
            keyWords3 = "◆◆◆ Touch, Instant";
            keyWords4 = "◆◆◆◆ Touch, Permanent, Expendable";
            mastery1 = "Raise a fleshless corpse as a simple skeleton.";
            mastery2 = "Raise an intact, recently dead corpse as a more durable and slightly smarter zombie.";
            mastery3 = "Raise the newly dead as a revenant that can cast Drain the Lifeblood without mana at will.";
            mastery4 = "The target rises as a revenant an hour after death. Revenants cannot receive this spell.";
            spells.Add(new Spell { Name = name, Element = e.Shadow, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Tame the Flesh";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target";
            keyWords3 = "◆◆◆ Target";
            keyWords4 = "◆◆◆◆ Target";
            mastery1 = "Lock the target in strict or sensual bindings. The bound need no sustenance, air, or rest. It costs no mana to extend this spell's duration.";
            mastery2 = "The restraints can blind and gag, inflict pain, and be animated to tease and force orgasms.";
            mastery3 = "The restraints can halt any spellcasting by painfully constricting the target.";
            mastery4 = "The restraints count as extensions of yourself for fulfilling Paths of Pleasure at any range.";
            spells.Add(new Spell { Name = name, Element = e.Shadow, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true, keyWords3, mastery3, keyWords4, mastery4, true)
                , IsLustMagic = true
            });
            
            name = "Cloak of Night";
            keyWords1 = "◆ Self";
            keyWords2 = "◆◆ Self";
            keyWords3 = "◆◆◆ Self";
            keyWords4 = "◆◆◆◆ Self";
            mastery1 = "You blend into the background and become very hard to see, especially while not moving.";
            mastery2 = "Any sound you make is muffled, in addition to you being hidden from sight.";
            mastery3 = "You are fully invisible, although observers may still guess your location if you disturb them or their surroundings.";
            mastery4 = "You may pass through solid objects with effort, but not remain inside them for long.";
            spells.Add(new Spell { Name = name, Element = e.Shadow, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Shadow Twin";
            keyWords1 = "◆ Summon, Permanent";
            keyWords2 = "◆◆ Summon, Permanent";
            keyWords3 = "◆◆◆ Summon, Permanent";
            keyWords4 = "◆◆◆◆ Summon, Permanent";
            mastery1 = "You summon a mass of solid shadows that vaguely resemble you and can follow orders. You can only have one shadow twin at a time.";
            mastery2 = "Your shadow twin can mimic your appearance almost exactly, and wield weapons with skill.";
            mastery3 = "Your twin may cast your known spells using your mana, needing an extra mana per spell.";
            mastery4 = "Permanent mana spent on creating a twin can be used by it every day to cast spells.";
            spells.Add(new Spell { Name = name, Element = e.Shadow, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
            });
            
            name = "Sinful Slumber";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target";
            keyWords3 = "◆◆◆ Target";
            keyWords4 = "◆◆◆◆ Target";
            mastery1 = "Fill the mind of a sleeping target at any know location with erotic dreams that leave them energized or fatigued upon waking next day.";
            mastery2 = "Cause the target to also feel fear, arousal, or both when seeing you in person the next day.";
            mastery3 = "Meditate to enter a sleeper's mind, converse with them, and shape their dreams first hand.";
            mastery4 = "Leave subtle yet lasting changes to a target's waking personality with every dream sent.";
            spells.Add(new Spell { Name = name, Element = e.Shadow, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, true, keyWords3, mastery3, keyWords4, mastery4, true)
                , IsLustMagic = true
            });

            //Esoteric
            spells.Add(new Spell { Name = "", Element = e.Esoteric, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Fear ◆ –––", Element = e.Esoteric, Mastery = 5 });

            name = "Phantasmal Horror";
            keyWords1 = "◆ Target";
            keyWords2 = "◆◆ Target";
            keyWords3 = "◆◆◆ Target";
            keyWords4 = "◆◆◆◆ Area";
            mastery1 = "Conjure fearful phantasms only the target can see. Decide if they flee or freeze in terror.";
            mastery2 = "The visions are convincing enough to cause phantom sensations and even inflict injuries.";
            mastery3 = "Merging the phantasms into your own visage, you cause the target to obey you out of fear.";
            mastery4 = "You can terrify and command many at once.";
            spells.Add(new Spell { Name = name, Element = e.Esoteric, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
                , EsotericElement = Spell.Esoteric.Fear
            });

            spells.Add(new Spell { Name = "", Element = e.Esoteric, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Choir ◆ –––", Element = e.Esoteric, Mastery = 5 });

            name = "Arcane Chorus";
            keyWords1 = "◆ Self, Instant";
            keyWords2 = "◆◆ Self, Instant";
            keyWords3 = "◆◆◆ Self, Instant";
            keyWords4 = "◆◆◆◆ Self, Instant";
            mastery1 = "Cast your next spell as a Grand Ritual, with assistance from up to two others. Mana spent beyond the spell's base cost will boost potency.";
            mastery2 = "Excess mana can also be spent to increase duration, target numbers, area, or range.";
            mastery3 = "The ritual no longer increases casting time.";
            mastery4 = "Your ritual may have ten more participants, and more than one spell aspect can be improved.";
            spells.Add(new Spell { Name = name, Element = e.Esoteric, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
                , EsotericElement = Spell.Esoteric.Choir
            });

            spells.Add(new Spell { Name = "", Element = e.Esoteric, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Battle ◆ –––", Element = e.Esoteric, Mastery = 5 });

            name = "Soulfire Lance";
            keyWords1 = "◆ Self, Daylong, Expendable";
            keyWords2 = "◆◆ Self, Daylong, Expendable";
            keyWords3 = "◆◆◆ Self, Daylong, Expendable";
            keyWords4 = "◆◆◆◆ Self, Daylong, Expendable";
            mastery1 = "You conjure a deadly soulfire lance, which you can project a short distance at will to strike down nearby enemies. The lance will expire if you cast any spell besides Ward.";
            mastery2 = "You may cast the base Ward spell together with conjuring the lance for no extra mana.";
            mastery3 = "You lance also disorients anyone it strikes.";
            mastery4 = "Your lance will make short work of enemy wards, and can be extended farther in battle.";
            spells.Add(new Spell { Name = name, Element = e.Esoteric, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
                , EsotericElement = Spell.Esoteric.Battle
            });

            spells.Add(new Spell { Name = "", Element = e.Esoteric, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Blood ◆ –––", Element = e.Esoteric, Mastery = 5 });

            name = "Awaken the Blood";
            keyWords1 = "◆ Self, Instant";
            keyWords2 = "◆◆ Self, Daylong";
            keyWords3 = "◆◆◆ Self, Daylong";
            keyWords4 = "◆◆◆◆ Self, Item, Instant";
            mastery1 = "Convert vitality to mana. Lost vitality must be healed naturally, or with Drain the Lifeblood.";
            mastery2 = "Dismiss fatigue and maintain peak alertness.";
            mastery3 = "Sacrifice vitality to hasten each spell you cast.";
            mastery4 = "Set aside vitality in a unique crystal for use at a later time, which counts as natural healing.";
            spells.Add(new Spell { Name = name, Element = e.Esoteric, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
                , EsotericElement = Spell.Esoteric.Blood
            });

            spells.Add(new Spell { Name = "", Element = e.Esoteric, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Duality ◆ –––", Element = e.Esoteric, Mastery = 5 });

            name = "Decadent Passion";
            keyWords1 = "◆ Self, Permanent";
            keyWords2 = "◆◆ Self, Permanent";
            keyWords3 = "◆◆◆ Self, Permanent";
            keyWords4 = "◆◆◆◆ Self, Permanent";
            mastery1 = "You can substitute men for women in Paths of Pleasure that require a partner, as long as they meet all other requirements.";
            mastery2 = "Your spells are especially potent against men, and your touch brings them great pleasure.";
            mastery3 = "Fulfilling a Path of Pleasure with a man will restore the mana cost of this spell for a day.";
            mastery4 = "Every spell you cast that affected a man has its mana cost lowered by 1, to no less than 0.";
            spells.Add(new Spell { Name = name, Element = e.Esoteric, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
                , EsotericElement = Spell.Esoteric.Rapture
            });

            spells.Add(new Spell { Name = "", Element = e.Esoteric, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Nurture ◆ –––", Element = e.Esoteric, Mastery = 5 });
            
            name = "Precious Gift";
            keyWords1 = "◆ Self, Target, Instant";
            keyWords2 = "◆◆ Self, Target, Instant";
            keyWords3 = "◆◆◆ Self, Target, Instant";
            keyWords4 = "◆◆◆◆ Self, Target, Instant";
            mastery1 = "Your breasts will lactate and produce enough milk to sate a person's hunger for the day.";
            mastery2 = "While the target drinks from your breasts, you can cast a spell that would normally affect only yourself upon that person instead.";
            mastery3 = "The mana cost of your transferred spell is reduced by the cost of Precious Gift.";
            mastery4 = "You can transfer one spell onto two targets at the same time if they partake together.";
            spells.Add(new Spell { Name = name, Element = e.Esoteric, Mastery = 1
                , Description = generateDescription(name, keyWords1, mastery1, keyWords2, mastery2, false, keyWords3, mastery3, keyWords4, mastery4, true)
                , EsotericElement = Spell.Esoteric.Nurture
            });

            //Universal Common
            spells.Add(new Spell { Name = "", Element = e.Universal, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Universal Common –––", Element = e.Universal, Mastery = 5 });

            name = "Sense";
            keyWords1 = "◆ Area, Instant";
            mastery1 = "Sense the balance of elements to detect the presence and nature of magic in the area.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
                , IsKnownToAll = true
            });

            name = "Ward";
            keyWords1 = "◆ Self, Area, Expendable";
            mastery1 = "Create or bolster a shielding ward for yourself or an area that weakens as it blocks attacks.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
                , IsKnownToAll = true
            });

            name = "Conjure";
            keyWords1 = "◆ Self, Expendable";
            mastery1 = "Conjure a handful of elemental energy for an attack, for light, or for some other clever use.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
                , IsKnownToAll = true
            });

            name = "Dismiss";
            keyWords1 = "◆ Target, Instant";
            mastery1 = "Attempt to counter a spell being cast, or to disrupt an existing magical effect.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
                , IsKnownToAll = true
            });

            name = "Shelter";
            keyWords1 = "◆ Target, Daylong";
            mastery1 = "Keep the target clean, dry, and comfortable in the presence of natural weather.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
                , IsKnownToAll = true
            });

            name = "Mark";
            keyWords1 = "◆ Touch, Item, Permanent";
            mastery1 = "Mark a willing person or object with your sigil. The design is uniquely tied to your soul.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
                , IsKnownToAll = true
            });

            //Optional Common
            spells.Add(new Spell { Name = "", Element = e.Universal, Mastery = 5 });
            spells.Add(new Spell { Name = "––– Optional Common –––", Element = e.Universal, Mastery = 5 });

            name = "Trace";
            keyWords1 = "◆ Self";
            mastery1 = "Track the direction and distance of your arcane mark upon a person or object.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
            });

            name = "Imbue";
            keyWords1 = "◆ Self, Expendable";
            mastery1 = "Imbue yourself with a burst of elemental energy to gain a brief benefit for one action.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
            });

            name = "Arouse";
            keyWords1 = "◆ Target";
            mastery1 = "Keep the target aroused with phantom tingles of teasing pleasure.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1, "", "", true)
                , IsLustMagic = true
            });            

            name = "Call";
            keyWords1 = "◆ Summon, Daylong";
            mastery1 = "Call for a soul bound elemental spirit that can cast Lift and Conjure to serve you for a time.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
            });

            name = "Augur";
            keyWords1 = "◆ Self";
            mastery1 = "Ask a question and receive a relevant yet cryptic sign or message from the Beyond.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
            });

            name = "Heighten";
            keyWords1 = "◆ Touch, Item";
            mastery1 = "Amplify any sensations a mundane object will deliver when used upon naked flesh.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1, "", "", true)
                , IsLustMagic = true
            });
                       
            name = "Push";
            keyWords1 = "◆ Target, Instant";
            mastery1 = "Give the target a sudden forceful shove, or attempt to briefly pin them to the ground.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
            });
            
            name = "Lift";
            keyWords1 = "◆ Self, Item";
            mastery1 = "Move an item with steady spectral force, or make yourself hover about at a walking pace.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
            });
            
            name = "Subdue";
            keyWords1 = "◆ Target";
            mastery1 = "The target will feel an urge to submit and obey, especially to your sexual demands.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1, "", "", true)
                , IsLustMagic = true
            });
            
            name = "Mend";
            keyWords1 = "◆ Touch, Item";
            mastery1 = "Join, patch, polish, bend, sharpen, straighten, or make some other minor repair to an item.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
            });
            
            name = "Flare";
            keyWords1 = "◆ Area, Instant";
            mastery1 = "Unlease an elemental display that lights up the area that disorients those caught within.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1)
            });

            name = "Ravish";
            keyWords1 = "◆ Touch, Instant";
            mastery1 = "Drain 3 mana, plus 3 per overcast rank, from a target at peak pleasure. Gain one third of it.";
            spells.Add(new Spell { Name = name, Element = e.Universal, Mastery = 0
                , Description = generateDescription(name, keyWords1, mastery1, "", "", true)
                , IsLustMagic = true
            });
            
            return spells;
        }

        public static CompanionCollection CreateCompanionList()
        {
            CompanionCollection companions = new CompanionCollection();

            string name = "";
            c.Devotion devotion = c.Devotion.None;
            c.Magic arcanePower = c.Magic.Mundane;
            c.Faction faction = c.Faction.Unaligned;
            c.Subfaction subfaction = c.Subfaction.None;
            c.Guild guildAllegiance = c.Guild.None;
            
            c.Might mightAptitude = c.Might.Untrained;
            c.Intrigue intrigueAptitude = c.Intrigue.Untrained;
            c.Lust lustAptitude = c.Lust.Untrained;
            string notes = ""; //companion ability description

            /*
            bool isLustWitch = false;
            bool isUnaligned = false;
            bool isJoyfulMaiden = false;
            bool isPlayerCreated = false;

            bool isLoverWithAllegiance = false;
            bool isDiscountedSlaveManual = false;
            */

            companions.Add(new c("---Ministry of Harmony---", c.Faction.Ministry));

            //Gillian
            name = "Gillian";
            devotion = c.Devotion.Ally;
            arcanePower = c.Magic.Talent;
            faction = c.Faction.Ministry;
            subfaction = c.Subfaction.None;
            guildAllegiance = c.Guild.None;
            mightAptitude = c.Might.Untrained;
            intrigueAptitude = c.Intrigue.Focus;
            lustAptitude = c.Lust.Trained;
            notes = ""; //companion ability description

            companions.Add(new c { Name = name, DevotionLevel = devotion, ArcanePower = arcanePower
                , CompanionFaction = faction, CompanionSubfaction = subfaction, GuildAllegiance = guildAllegiance
                , MightAptitude = mightAptitude, IntrigueAptitude = intrigueAptitude, LustAptitude = lustAptitude
                , Notes = notes});

            name = "Lover Test";
            devotion = c.Devotion.Lover;
            c test = new c {
                Name = name, DevotionLevel = devotion, ArcanePower = arcanePower
                , CompanionFaction = faction, CompanionSubfaction = subfaction, GuildAllegiance = guildAllegiance
                , MightAptitude = mightAptitude, IntrigueAptitude = intrigueAptitude, LustAptitude = lustAptitude
                , Notes = "test"};
            test.IsCostModifiedByPlayer = true;
            test.ModifiedControlCost = 2;

            companions.Add(test);
            companions.Add(new c());
            companions.Add(new c("---Church of the Sun---", c.Faction.Church));

            return companions;
        }
    }
}